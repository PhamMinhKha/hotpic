(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var ECMAScript = Package.ecmascript.ECMAScript;
var fetch = Package.fetch.fetch;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var debug, schema, public, strict, getUser, chunkSize, protected, collection, permissions, cacheControl, downloadRoute, onAfterUpload, onAfterRemove, disableUpload, onBeforeRemove, integrityCheck, collectionName, onBeforeUpload, namingFunction, responseHeaders, disableDownload, allowedOrigins, allowClientCode, downloadCallback, onInitiateUpload, interceptRequest, interceptDownload, continueUploadTTL, parentDirPermissions, allowQueryStringCookies, _preCollection, _preCollectionName, FilesCollection;

var require = meteorInstall({"node_modules":{"meteor":{"ostrio:files":{"server.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/server.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  FilesCollection: () => FilesCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let fetch;
module.link("meteor/fetch", {
  fetch(v) {
    fetch = v;
  }

}, 1);
let WebApp;
module.link("meteor/webapp", {
  WebApp(v) {
    WebApp = v;
  }

}, 2);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Random;
module.link("meteor/random", {
  Random(v) {
    Random = v;
  }

}, 4);
let Cookies;
module.link("meteor/ostrio:cookies", {
  Cookies(v) {
    Cookies = v;
  }

}, 5);
let check, Match;
module.link("meteor/check", {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 6);
let WriteStream;
module.link("./write-stream.js", {
  default(v) {
    WriteStream = v;
  }

}, 7);
let FilesCollectionCore;
module.link("./core.js", {
  default(v) {
    FilesCollectionCore = v;
  }

}, 8);
let fixJSONParse, fixJSONStringify, helpers;
module.link("./lib.js", {
  fixJSONParse(v) {
    fixJSONParse = v;
  },

  fixJSONStringify(v) {
    fixJSONStringify = v;
  },

  helpers(v) {
    helpers = v;
  }

}, 9);
let AbortController;
module.link("abort-controller", {
  default(v) {
    AbortController = v;
  }

}, 10);
let fs;
module.link("fs-extra", {
  default(v) {
    fs = v;
  }

}, 11);
let nodeQs;
module.link("querystring", {
  default(v) {
    nodeQs = v;
  }

}, 12);
let nodePath;
module.link("path", {
  default(v) {
    nodePath = v;
  }

}, 13);

/*
 * @const {Object} bound  - Meteor.bindEnvironment (Fiber wrapper)
 * @const {Function} NOOP - No Operation function, placeholder for required callbacks
 */
const bound = Meteor.bindEnvironment(callback => callback());

const NOOP = () => {};
/*
 * @locus Anywhere
 * @class FilesCollection
 * @param config           {Object}   - [Both]   Configuration object with next properties:
 * @param config.debug     {Boolean}  - [Both]   Turn on/of debugging and extra logging
 * @param config.schema    {Object}   - [Both]   Collection Schema
 * @param config.public    {Boolean}  - [Both]   Store files in folder accessible for proxy servers, for limits, and more - read docs
 * @param config.strict    {Boolean}  - [Server] Strict mode for partial content, if is `true` server will return `416` response code, when `range` is not specified, otherwise server return `206`
 * @param config.protected {Function} - [Server] If `true` - files will be served only to authorized users, if `function()` - you're able to check visitor's permissions in your own way function's context has:
 *  - `request`
 *  - `response`
 *  - `user()`
 *  - `userId`
 * @param config.chunkSize      {Number}  - [Both] Upload chunk size, default: 524288 bytes (0,5 Mb)
 * @param config.permissions    {Number}  - [Server] Permissions which will be set to uploaded files (octal), like: `511` or `0o755`. Default: 0644
 * @param config.parentDirPermissions {Number}  - [Server] Permissions which will be set to parent directory of uploaded files (octal), like: `611` or `0o777`. Default: 0755
 * @param config.storagePath    {String|Function}  - [Server] Storage path on file system
 * @param config.cacheControl   {String}  - [Server] Default `Cache-Control` header
 * @param config.responseHeaders {Object|Function} - [Server] Custom response headers, if function is passed, must return Object
 * @param config.throttle       {Number}  - [Server] DEPRECATED bps throttle threshold
 * @param config.downloadRoute  {String}  - [Both]   Server Route used to retrieve files
 * @param config.collection     {Mongo.Collection} - [Both] Mongo Collection Instance
 * @param config.collectionName {String}  - [Both]   Collection name
 * @param config.namingFunction {Function}- [Both]   Function which returns `String`
 * @param config.integrityCheck {Boolean} - [Server] Check file's integrity before serving to users
 * @param config.onAfterUpload  {Function}- [Server] Called right after file is ready on FS. Use to transfer file somewhere else, or do other thing with file directly
 * @param config.onAfterRemove  {Function} - [Server] Called right after file is removed. Removed objects is passed to callback
 * @param config.continueUploadTTL {Number} - [Server] Time in seconds, during upload may be continued, default 3 hours (10800 seconds)
 * @param config.onBeforeUpload {Function}- [Both]   Function which executes on server after receiving each chunk and on client right before beginning upload. Function context is `File` - so you are able to check for extension, mime-type, size and etc.:
 *  - return `true` to continue
 *  - return `false` or `String` to abort upload
 * @param config.getUser        {Function} - [Server] Replace default way of recognizing user, usefull when you want to auth user based on custom cookie (or other way). arguments {http: {request: {...}, response: {...}}}, need to return {userId: String, user: Function}
 * @param config.onInitiateUpload {Function} - [Server] Function which executes on server right before upload is begin and right after `onBeforeUpload` hook. This hook is fully asynchronous.
 * @param config.onBeforeRemove {Function} - [Server] Executes before removing file on server, so you can check permissions. Return `true` to allow action and `false` to deny.
 * @param config.allowClientCode  {Boolean}  - [Both]   Allow to run `remove` from client
 * @param config.downloadCallback {Function} - [Server] Callback triggered each time file is requested, return truthy value to continue download, or falsy to abort
  * @param config.interceptRequest {Function} - [Server] Intercept incoming HTTP request, so you can whatever you want, no checks or preprocessing, arguments {http: {request: {...}, response: {...}}, params: {...}}
 * @param config.interceptDownload {Function} - [Server] Intercept download request, so you can serve file from third-party resource, arguments {http: {request: {...}, response: {...}}, fileRef: {...}}
 * @param config.disableUpload {Boolean} - Disable file upload, useful for server only solutions
 * @param config.disableDownload {Boolean} - Disable file download (serving), useful for file management only solutions
 * @param config.allowedOrigins  {Regex|Boolean}  - [Server]   Regex of Origins that are allowed CORS access or `false` to disable completely. Defaults to `/^http:\/\/localhost:12[0-9]{3}$/` for allowing Meteor-Cordova builds access
 * @param config.allowQueryStringCookies {Boolean} - Allow passing Cookies in a query string (in URL). Primary should be used only in Cordova environment. Note: this option will be used only on Cordova. Default: `false`
 * @param config._preCollection  {Mongo.Collection} - [Server] Mongo preCollection Instance
 * @param config._preCollectionName {String}  - [Server]  preCollection name
 * @summary Create new instance of FilesCollection
 */


class FilesCollection extends FilesCollectionCore {
  constructor(config) {
    super();
    let storagePath;

    if (config) {
      ({
        storagePath,
        debug: this.debug,
        schema: this.schema,
        public: this.public,
        strict: this.strict,
        getUser: this.getUser,
        chunkSize: this.chunkSize,
        protected: this.protected,
        collection: this.collection,
        permissions: this.permissions,
        cacheControl: this.cacheControl,
        downloadRoute: this.downloadRoute,
        onAfterUpload: this.onAfterUpload,
        onAfterRemove: this.onAfterRemove,
        disableUpload: this.disableUpload,
        onBeforeRemove: this.onBeforeRemove,
        integrityCheck: this.integrityCheck,
        collectionName: this.collectionName,
        onBeforeUpload: this.onBeforeUpload,
        namingFunction: this.namingFunction,
        responseHeaders: this.responseHeaders,
        disableDownload: this.disableDownload,
        allowedOrigins: this.allowedOrigins,
        allowClientCode: this.allowClientCode,
        downloadCallback: this.downloadCallback,
        onInitiateUpload: this.onInitiateUpload,
        interceptRequest: this.interceptRequest,
        interceptDownload: this.interceptDownload,
        continueUploadTTL: this.continueUploadTTL,
        parentDirPermissions: this.parentDirPermissions,
        allowQueryStringCookies: this.allowQueryStringCookies,
        _preCollection: this._preCollection,
        _preCollectionName: this._preCollectionName
      } = config);
    }

    const self = this;

    if (!helpers.isBoolean(this.debug)) {
      this.debug = false;
    }

    if (!helpers.isBoolean(this.public)) {
      this.public = false;
    }

    if (!this.protected) {
      this.protected = false;
    }

    if (!this.chunkSize) {
      this.chunkSize = 1024 * 512;
    }

    this.chunkSize = Math.floor(this.chunkSize / 8) * 8;

    if (!helpers.isString(this.collectionName) && !this.collection) {
      this.collectionName = 'MeteorUploadFiles';
    }

    if (!this.collection) {
      this.collection = new Mongo.Collection(this.collectionName);
    } else {
      this.collectionName = this.collection._name;
    }

    this.collection.filesCollection = this;
    check(this.collectionName, String);

    if (this.public && !this.downloadRoute) {
      throw new Meteor.Error(500, "[FilesCollection.".concat(this.collectionName, "]: \"downloadRoute\" must be precisely provided on \"public\" collections! Note: \"downloadRoute\" must be equal or be inside of your web/proxy-server (relative) root."));
    }

    if (!helpers.isString(this.downloadRoute)) {
      this.downloadRoute = '/cdn/storage';
    }

    this.downloadRoute = this.downloadRoute.replace(/\/$/, '');

    if (!helpers.isFunction(this.namingFunction)) {
      this.namingFunction = false;
    }

    if (!helpers.isFunction(this.onBeforeUpload)) {
      this.onBeforeUpload = false;
    }

    if (!helpers.isFunction(this.getUser)) {
      this.getUser = false;
    }

    if (!helpers.isBoolean(this.allowClientCode)) {
      this.allowClientCode = true;
    }

    if (!helpers.isFunction(this.onInitiateUpload)) {
      this.onInitiateUpload = false;
    }

    if (!helpers.isFunction(this.interceptRequest)) {
      this.interceptRequest = false;
    }

    if (!helpers.isFunction(this.interceptDownload)) {
      this.interceptDownload = false;
    }

    if (!helpers.isBoolean(this.strict)) {
      this.strict = true;
    }

    if (!helpers.isBoolean(this.allowQueryStringCookies)) {
      this.allowQueryStringCookies = false;
    }

    if (!helpers.isNumber(this.permissions)) {
      this.permissions = parseInt('644', 8);
    }

    if (!helpers.isNumber(this.parentDirPermissions)) {
      this.parentDirPermissions = parseInt('755', 8);
    }

    if (!helpers.isString(this.cacheControl)) {
      this.cacheControl = 'public, max-age=31536000, s-maxage=31536000';
    }

    if (!helpers.isFunction(this.onAfterUpload)) {
      this.onAfterUpload = false;
    }

    if (!helpers.isBoolean(this.disableUpload)) {
      this.disableUpload = false;
    }

    if (!helpers.isFunction(this.onAfterRemove)) {
      this.onAfterRemove = false;
    }

    if (!helpers.isFunction(this.onBeforeRemove)) {
      this.onBeforeRemove = false;
    }

    if (!helpers.isBoolean(this.integrityCheck)) {
      this.integrityCheck = true;
    }

    if (!helpers.isBoolean(this.disableDownload)) {
      this.disableDownload = false;
    }

    if (!helpers.isBoolean(this.allowedOrigins) || this.allowedOrigins === true) {
      this.allowedOrigins = /^http:\/\/localhost:12[0-9]{3}$/;
    }

    if (!helpers.isObject(this._currentUploads)) {
      this._currentUploads = {};
    }

    if (!helpers.isFunction(this.downloadCallback)) {
      this.downloadCallback = false;
    }

    if (!helpers.isNumber(this.continueUploadTTL)) {
      this.continueUploadTTL = 10800;
    }

    if (!helpers.isFunction(this.responseHeaders)) {
      this.responseHeaders = (responseCode, fileRef, versionRef) => {
        const headers = {};

        switch (responseCode) {
          case '206':
            headers.Pragma = 'private';
            headers['Transfer-Encoding'] = 'chunked';
            break;

          case '400':
            headers['Cache-Control'] = 'no-cache';
            break;

          case '416':
            headers['Content-Range'] = "bytes */".concat(versionRef.size);
            break;

          default:
            break;
        }

        headers.Connection = 'keep-alive';
        headers['Content-Type'] = versionRef.type || 'application/octet-stream';
        headers['Accept-Ranges'] = 'bytes';
        return headers;
      };
    }

    if (this.public && !storagePath) {
      throw new Meteor.Error(500, "[FilesCollection.".concat(this.collectionName, "] \"storagePath\" must be set on \"public\" collections! Note: \"storagePath\" must be equal on be inside of your web/proxy-server (absolute) root."));
    }

    if (!storagePath) {
      storagePath = function () {
        return "assets".concat(nodePath.sep, "app").concat(nodePath.sep, "uploads").concat(nodePath.sep).concat(self.collectionName);
      };
    }

    if (helpers.isString(storagePath)) {
      this.storagePath = () => storagePath;
    } else {
      this.storagePath = function () {
        let sp = storagePath.apply(self, arguments);

        if (!helpers.isString(sp)) {
          throw new Meteor.Error(400, "[FilesCollection.".concat(self.collectionName, "] \"storagePath\" function must return a String!"));
        }

        sp = sp.replace(/\/$/, '');
        return nodePath.normalize(sp);
      };
    }

    this._debug('[FilesCollection.storagePath] Set to:', this.storagePath({}));

    fs.mkdirs(this.storagePath({}), {
      mode: this.parentDirPermissions
    }, error => {
      if (error) {
        throw new Meteor.Error(401, "[FilesCollection.".concat(self.collectionName, "] Path \"").concat(this.storagePath({}), "\" is not writable! ").concat(error));
      }
    });
    check(this.strict, Boolean);
    check(this.permissions, Number);
    check(this.storagePath, Function);
    check(this.cacheControl, String);
    check(this.onAfterRemove, Match.OneOf(false, Function));
    check(this.onAfterUpload, Match.OneOf(false, Function));
    check(this.disableUpload, Boolean);
    check(this.integrityCheck, Boolean);
    check(this.onBeforeRemove, Match.OneOf(false, Function));
    check(this.disableDownload, Boolean);
    check(this.downloadCallback, Match.OneOf(false, Function));
    check(this.interceptRequest, Match.OneOf(false, Function));
    check(this.interceptDownload, Match.OneOf(false, Function));
    check(this.continueUploadTTL, Number);
    check(this.responseHeaders, Match.OneOf(Object, Function));
    check(this.allowQueryStringCookies, Boolean);
    new Cookies({
      allowQueryStringCookies: this.allowQueryStringCookies,
      allowedCordovaOrigins: this.allowedOrigins
    });

    if (!this.disableUpload) {
      if (!helpers.isString(this._preCollectionName) && !this._preCollection) {
        this._preCollectionName = "__pre_".concat(this.collectionName);
      }

      if (!this._preCollection) {
        this._preCollection = new Mongo.Collection(this._preCollectionName);
      } else {
        this._preCollectionName = this._preCollection._name;
      }

      check(this._preCollectionName, String);

      this._preCollection._ensureIndex({
        createdAt: 1
      }, {
        expireAfterSeconds: this.continueUploadTTL,
        background: true
      });

      const _preCollectionCursor = this._preCollection.find({}, {
        fields: {
          _id: 1,
          isFinished: 1
        }
      });

      _preCollectionCursor.observe({
        changed(doc) {
          if (doc.isFinished) {
            self._debug("[FilesCollection] [_preCollectionCursor.observe] [changed]: ".concat(doc._id));

            self._preCollection.remove({
              _id: doc._id
            }, NOOP);
          }
        },

        removed(doc) {
          // Free memory after upload is done
          // Or if upload is unfinished
          self._debug("[FilesCollection] [_preCollectionCursor.observe] [removed]: ".concat(doc._id));

          if (helpers.isObject(self._currentUploads[doc._id])) {
            self._currentUploads[doc._id].stop();

            self._currentUploads[doc._id].end(); // We can be unlucky to run into a race condition where another server removed this document before the change of `isFinished` is registered on this server.
            // Therefore it's better to double-check with the main collection if the file is referenced there. Issue: https://github.com/VeliovGroup/Meteor-Files/issues/672


            if (!doc.isFinished && self.collection.find({
              _id: doc._id
            }).count() === 0) {
              self._debug("[FilesCollection] [_preCollectionCursor.observe] [removeUnfinishedUpload]: ".concat(doc._id));

              self._currentUploads[doc._id].abort();
            }

            delete self._currentUploads[doc._id];
          }
        }

      });

      this._createStream = (_id, path, opts) => {
        this._currentUploads[_id] = new WriteStream(path, opts.fileLength, opts, this.permissions);
      }; // This little function allows to continue upload
      // even after server is restarted (*not on dev-stage*)


      this._continueUpload = _id => {
        if (this._currentUploads[_id] && this._currentUploads[_id].file) {
          if (!this._currentUploads[_id].aborted && !this._currentUploads[_id].ended) {
            return this._currentUploads[_id].file;
          }

          this._createStream(_id, this._currentUploads[_id].file.file.path, this._currentUploads[_id].file);

          return this._currentUploads[_id].file;
        }

        const contUpld = this._preCollection.findOne({
          _id
        });

        if (contUpld) {
          this._createStream(_id, contUpld.file.path, contUpld);

          return this._currentUploads[_id].file;
        }

        return false;
      };
    }

    if (!this.schema) {
      this.schema = FilesCollectionCore.schema;
    }

    check(this.debug, Boolean);
    check(this.schema, Object);
    check(this.public, Boolean);
    check(this.getUser, Match.OneOf(false, Function));
    check(this.protected, Match.OneOf(Boolean, Function));
    check(this.chunkSize, Number);
    check(this.downloadRoute, String);
    check(this.namingFunction, Match.OneOf(false, Function));
    check(this.onBeforeUpload, Match.OneOf(false, Function));
    check(this.onInitiateUpload, Match.OneOf(false, Function));
    check(this.allowClientCode, Boolean);

    if (this.public && this.protected) {
      throw new Meteor.Error(500, "[FilesCollection.".concat(this.collectionName, "]: Files can not be public and protected at the same time!"));
    }

    this._checkAccess = http => {
      if (this.protected) {
        let result;

        const {
          user,
          userId
        } = this._getUser(http);

        if (helpers.isFunction(this.protected)) {
          let fileRef;

          if (helpers.isObject(http.params) && http.params._id) {
            fileRef = this.collection.findOne(http.params._id);
          }

          result = http ? this.protected.call(Object.assign(http, {
            user,
            userId
          }), fileRef || null) : this.protected.call({
            user,
            userId
          }, fileRef || null);
        } else {
          result = !!userId;
        }

        if (http && result === true || !http) {
          return true;
        }

        const rc = helpers.isNumber(result) ? result : 401;

        this._debug('[FilesCollection._checkAccess] WARN: Access denied!');

        if (http) {
          const text = 'Access denied!';

          if (!http.response.headersSent) {
            http.response.writeHead(rc, {
              'Content-Type': 'text/plain',
              'Content-Length': text.length
            });
          }

          if (!http.response.finished) {
            http.response.end(text);
          }
        }

        return false;
      }

      return true;
    };

    this._methodNames = {
      _Abort: "_FilesCollectionAbort_".concat(this.collectionName),
      _Write: "_FilesCollectionWrite_".concat(this.collectionName),
      _Start: "_FilesCollectionStart_".concat(this.collectionName),
      _Remove: "_FilesCollectionRemove_".concat(this.collectionName)
    };
    this.on('_handleUpload', this._handleUpload);
    this.on('_finishUpload', this._finishUpload);
    this._handleUploadSync = Meteor.wrapAsync(this._handleUpload.bind(this));

    if (this.disableUpload && this.disableDownload) {
      return;
    }

    WebApp.connectHandlers.use((httpReq, httpResp, next) => {
      if (this.allowedOrigins && httpReq._parsedUrl.path.includes("".concat(this.downloadRoute, "/")) && !httpResp.headersSent) {
        if (this.allowedOrigins.test(httpReq.headers.origin)) {
          httpResp.setHeader('Access-Control-Allow-Credentials', 'true');
          httpResp.setHeader('Access-Control-Allow-Origin', httpReq.headers.origin);
        }

        if (httpReq.method === 'OPTIONS') {
          httpResp.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
          httpResp.setHeader('Access-Control-Allow-Headers', 'Range, Content-Type, x-mtok, x-start, x-chunkid, x-fileid, x-eof');
          httpResp.setHeader('Access-Control-Expose-Headers', 'Accept-Ranges, Content-Encoding, Content-Length, Content-Range');
          httpResp.setHeader('Allow', 'GET, POST, OPTIONS');
          httpResp.writeHead(200);
          httpResp.end();
          return;
        }
      }

      if (!this.disableUpload && httpReq._parsedUrl.path.includes("".concat(this.downloadRoute, "/").concat(this.collectionName, "/__upload"))) {
        if (httpReq.method !== 'POST') {
          next();
          return;
        }

        const handleError = _error => {
          let error = _error;
          console.warn('[FilesCollection] [Upload] [HTTP] Exception:', error);
          console.trace();

          if (!httpResp.headersSent) {
            httpResp.writeHead(500);
          }

          if (!httpResp.finished) {
            if (helpers.isObject(error) && helpers.isFunction(error.toString)) {
              error = error.toString();
            }

            if (!helpers.isString(error)) {
              error = 'Unexpected error!';
            }

            httpResp.end(JSON.stringify({
              error
            }));
          }
        };

        let body = '';

        const handleData = () => {
          try {
            let opts;
            let result;

            let user = this._getUser({
              request: httpReq,
              response: httpResp
            });

            if (httpReq.headers['x-start'] !== '1') {
              // CHUNK UPLOAD SCENARIO:
              opts = {
                fileId: httpReq.headers['x-fileid']
              };

              if (httpReq.headers['x-eof'] === '1') {
                opts.eof = true;
              } else {
                opts.binData = Buffer.from(body, 'base64');
                opts.chunkId = parseInt(httpReq.headers['x-chunkid']);
              }

              const _continueUpload = this._continueUpload(opts.fileId);

              if (!_continueUpload) {
                throw new Meteor.Error(408, 'Can\'t continue upload, session expired. Start upload again.');
              }

              ({
                result,
                opts
              } = this._prepareUpload(Object.assign(opts, _continueUpload), user.userId, 'HTTP'));

              if (opts.eof) {
                // FINISH UPLOAD SCENARIO:
                this._handleUpload(result, opts, _error => {
                  let error = _error;

                  if (error) {
                    if (!httpResp.headersSent) {
                      httpResp.writeHead(500);
                    }

                    if (!httpResp.finished) {
                      if (helpers.isObject(error) && helpers.isFunction(error.toString)) {
                        error = error.toString();
                      }

                      if (!helpers.isString(error)) {
                        error = 'Unexpected error!';
                      }

                      httpResp.end(JSON.stringify({
                        error
                      }));
                    }
                  }

                  if (!httpResp.headersSent) {
                    httpResp.writeHead(200);
                  }

                  if (helpers.isObject(result.file) && result.file.meta) {
                    result.file.meta = fixJSONStringify(result.file.meta);
                  }

                  if (!httpResp.finished) {
                    httpResp.end(JSON.stringify(result));
                  }
                });

                return;
              }

              this.emit('_handleUpload', result, opts, NOOP);

              if (!httpResp.headersSent) {
                httpResp.writeHead(204);
              }

              if (!httpResp.finished) {
                httpResp.end();
              }
            } else {
              // START SCENARIO:
              try {
                opts = JSON.parse(body);
              } catch (jsonErr) {
                console.error('Can\'t parse incoming JSON from Client on [.insert() | upload], something went wrong!', jsonErr);
                opts = {
                  file: {}
                };
              }

              if (!helpers.isObject(opts.file)) {
                opts.file = {};
              }

              this._debug("[FilesCollection] [File Start HTTP] ".concat(opts.file.name || '[no-name]', " - ").concat(opts.fileId));

              if (helpers.isObject(opts.file) && opts.file.meta) {
                opts.file.meta = fixJSONParse(opts.file.meta);
              }

              opts.___s = true;
              ({
                result
              } = this._prepareUpload(helpers.clone(opts), user.userId, 'HTTP Start Method'));

              if (this.collection.findOne(result._id)) {
                throw new Meteor.Error(400, 'Can\'t start upload, data substitution detected!');
              }

              opts._id = opts.fileId;
              opts.createdAt = new Date();
              opts.maxLength = opts.fileLength;

              this._preCollection.insert(helpers.omit(opts, '___s'));

              this._createStream(result._id, result.path, helpers.omit(opts, '___s'));

              if (opts.returnMeta) {
                if (!httpResp.headersSent) {
                  httpResp.writeHead(200);
                }

                if (!httpResp.finished) {
                  httpResp.end(JSON.stringify({
                    uploadRoute: "".concat(this.downloadRoute, "/").concat(this.collectionName, "/__upload"),
                    file: result
                  }));
                }
              } else {
                if (!httpResp.headersSent) {
                  httpResp.writeHead(204);
                }

                if (!httpResp.finished) {
                  httpResp.end();
                }
              }
            }
          } catch (httpRespErr) {
            handleError(httpRespErr);
          }
        };

        httpReq.setTimeout(20000, handleError);

        if (typeof httpReq.body === 'object' && Object.keys(httpReq.body).length !== 0) {
          body = JSON.stringify(httpReq.body);
          handleData();
        } else {
          httpReq.on('data', data => bound(() => {
            body += data;
          }));
          httpReq.on('end', () => bound(() => {
            handleData();
          }));
        }

        return;
      }

      if (!this.disableDownload) {
        let uri;

        if (!this.public) {
          if (httpReq._parsedUrl.path.includes("".concat(this.downloadRoute, "/").concat(this.collectionName))) {
            uri = httpReq._parsedUrl.path.replace("".concat(this.downloadRoute, "/").concat(this.collectionName), '');

            if (uri.indexOf('/') === 0) {
              uri = uri.substring(1);
            }

            const uris = uri.split('/');

            if (uris.length === 3) {
              const params = {
                _id: uris[0],
                query: httpReq._parsedUrl.query ? nodeQs.parse(httpReq._parsedUrl.query) : {},
                name: uris[2].split('?')[0],
                version: uris[1]
              };
              const http = {
                request: httpReq,
                response: httpResp,
                params
              };

              if (this.interceptRequest && helpers.isFunction(this.interceptRequest) && this.interceptRequest(http) === true) {
                return;
              }

              if (this._checkAccess(http)) {
                this.download(http, uris[1], this.collection.findOne(uris[0]));
              }
            } else {
              next();
            }
          } else {
            next();
          }
        } else {
          if (httpReq._parsedUrl.path.includes("".concat(this.downloadRoute))) {
            uri = httpReq._parsedUrl.path.replace("".concat(this.downloadRoute), '');

            if (uri.indexOf('/') === 0) {
              uri = uri.substring(1);
            }

            const uris = uri.split('/');
            let _file = uris[uris.length - 1];

            if (_file) {
              let version;

              if (_file.includes('-')) {
                version = _file.split('-')[0];
                _file = _file.split('-')[1].split('?')[0];
              } else {
                version = 'original';
                _file = _file.split('?')[0];
              }

              const params = {
                query: httpReq._parsedUrl.query ? nodeQs.parse(httpReq._parsedUrl.query) : {},
                file: _file,
                _id: _file.split('.')[0],
                version,
                name: _file
              };
              const http = {
                request: httpReq,
                response: httpResp,
                params
              };

              if (this.interceptRequest && helpers.isFunction(this.interceptRequest) && this.interceptRequest(http) === true) {
                return;
              }

              this.download(http, version, this.collection.findOne(params._id));
            } else {
              next();
            }
          } else {
            next();
          }
        }

        return;
      }

      next();
    });

    if (!this.disableUpload) {
      const _methods = {}; // Method used to remove file
      // from Client side

      _methods[this._methodNames._Remove] = function (selector) {
        check(selector, Match.OneOf(String, Object));

        self._debug("[FilesCollection] [Unlink Method] [.remove(".concat(selector, ")]"));

        if (self.allowClientCode) {
          if (self.onBeforeRemove && helpers.isFunction(self.onBeforeRemove)) {
            const userId = this.userId;
            const userFuncs = {
              userId: this.userId,

              user() {
                if (Meteor.users) {
                  return Meteor.users.findOne(userId);
                }

                return null;
              }

            };

            if (!self.onBeforeRemove.call(userFuncs, self.find(selector) || null)) {
              throw new Meteor.Error(403, '[FilesCollection] [remove] Not permitted!');
            }
          }

          const cursor = self.find(selector);

          if (cursor.count() > 0) {
            self.remove(selector);
            return true;
          }

          throw new Meteor.Error(404, 'Cursor is empty, no files is removed');
        } else {
          throw new Meteor.Error(401, '[FilesCollection] [remove] Run code from client is not allowed!');
        }
      }; // Method used to receive "first byte" of upload
      // and all file's meta-data, so
      // it won't be transferred with every chunk
      // Basically it prepares everything
      // So user can pause/disconnect and
      // continue upload later, during `continueUploadTTL`


      _methods[this._methodNames._Start] = function (opts, returnMeta) {
        check(opts, {
          file: Object,
          fileId: String,
          FSName: Match.Optional(String),
          chunkSize: Number,
          fileLength: Number
        });
        check(returnMeta, Match.Optional(Boolean));

        self._debug("[FilesCollection] [File Start Method] ".concat(opts.file.name, " - ").concat(opts.fileId));

        opts.___s = true;

        const {
          result
        } = self._prepareUpload(helpers.clone(opts), this.userId, 'DDP Start Method');

        if (self.collection.findOne(result._id)) {
          throw new Meteor.Error(400, 'Can\'t start upload, data substitution detected!');
        }

        opts._id = opts.fileId;
        opts.createdAt = new Date();
        opts.maxLength = opts.fileLength;

        try {
          self._preCollection.insert(helpers.omit(opts, '___s'));

          self._createStream(result._id, result.path, helpers.omit(opts, '___s'));
        } catch (e) {
          self._debug("[FilesCollection] [File Start Method] [EXCEPTION:] ".concat(opts.file.name, " - ").concat(opts.fileId), e);

          throw new Meteor.Error(500, 'Can\'t start');
        }

        if (returnMeta) {
          return {
            uploadRoute: "".concat(self.downloadRoute, "/").concat(self.collectionName, "/__upload"),
            file: result
          };
        }

        return true;
      }; // Method used to write file chunks
      // it receives very limited amount of meta-data
      // This method also responsible for EOF


      _methods[this._methodNames._Write] = function (_opts) {
        let opts = _opts;
        let result;
        check(opts, {
          eof: Match.Optional(Boolean),
          fileId: String,
          binData: Match.Optional(String),
          chunkId: Match.Optional(Number)
        });

        if (opts.binData) {
          opts.binData = Buffer.from(opts.binData, 'base64');
        }

        const _continueUpload = self._continueUpload(opts.fileId);

        if (!_continueUpload) {
          throw new Meteor.Error(408, 'Can\'t continue upload, session expired. Start upload again.');
        }

        this.unblock();
        ({
          result,
          opts
        } = self._prepareUpload(Object.assign(opts, _continueUpload), this.userId, 'DDP'));

        if (opts.eof) {
          try {
            return self._handleUploadSync(result, opts);
          } catch (handleUploadErr) {
            self._debug('[FilesCollection] [Write Method] [DDP] Exception:', handleUploadErr);

            throw handleUploadErr;
          }
        } else {
          self.emit('_handleUpload', result, opts, NOOP);
        }

        return true;
      }; // Method used to Abort upload
      // - Freeing memory by ending writableStreams
      // - Removing temporary record from @_preCollection
      // - Removing record from @collection
      // - .unlink()ing chunks from FS


      _methods[this._methodNames._Abort] = function (_id) {
        check(_id, String);

        const _continueUpload = self._continueUpload(_id);

        self._debug("[FilesCollection] [Abort Method]: ".concat(_id, " - ").concat(helpers.isObject(_continueUpload.file) ? _continueUpload.file.path : ''));

        if (self._currentUploads && self._currentUploads[_id]) {
          self._currentUploads[_id].stop();

          self._currentUploads[_id].abort();
        }

        if (_continueUpload) {
          self._preCollection.remove({
            _id
          });

          self.remove({
            _id
          });

          if (helpers.isObject(_continueUpload.file) && _continueUpload.file.path) {
            self.unlink({
              _id,
              path: _continueUpload.file.path
            });
          }
        }

        return true;
      };

      Meteor.methods(_methods);
    }
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name _prepareUpload
   * @summary Internal method. Used to optimize received data and check upload permission
   * @returns {Object}
   */


  _prepareUpload() {
    let opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let userId = arguments.length > 1 ? arguments[1] : undefined;
    let transport = arguments.length > 2 ? arguments[2] : undefined;
    let ctx;

    if (!helpers.isBoolean(opts.eof)) {
      opts.eof = false;
    }

    if (!opts.binData) {
      opts.binData = 'EOF';
    }

    if (!helpers.isNumber(opts.chunkId)) {
      opts.chunkId = -1;
    }

    if (!helpers.isString(opts.FSName)) {
      opts.FSName = opts.fileId;
    }

    this._debug("[FilesCollection] [Upload] [".concat(transport, "] Got #").concat(opts.chunkId, "/").concat(opts.fileLength, " chunks, dst: ").concat(opts.file.name || opts.file.fileName));

    const fileName = this._getFileName(opts.file);

    const {
      extension,
      extensionWithDot
    } = this._getExt(fileName);

    if (!helpers.isObject(opts.file.meta)) {
      opts.file.meta = {};
    }

    let result = opts.file;
    result.name = fileName;
    result.meta = opts.file.meta;
    result.extension = extension;
    result.ext = extension;
    result._id = opts.fileId;
    result.userId = userId || null;
    opts.FSName = opts.FSName.replace(/([^a-z0-9\-\_]+)/gi, '-');
    result.path = "".concat(this.storagePath(result)).concat(nodePath.sep).concat(opts.FSName).concat(extensionWithDot);
    result = Object.assign(result, this._dataToSchema(result));

    if (this.onBeforeUpload && helpers.isFunction(this.onBeforeUpload)) {
      ctx = Object.assign({
        file: opts.file
      }, {
        chunkId: opts.chunkId,
        userId: result.userId,

        user() {
          if (Meteor.users && result.userId) {
            return Meteor.users.findOne(result.userId);
          }

          return null;
        },

        eof: opts.eof
      });
      const isUploadAllowed = this.onBeforeUpload.call(ctx, result);

      if (isUploadAllowed !== true) {
        throw new Meteor.Error(403, helpers.isString(isUploadAllowed) ? isUploadAllowed : '@onBeforeUpload() returned false');
      } else {
        if (opts.___s === true && this.onInitiateUpload && helpers.isFunction(this.onInitiateUpload)) {
          this.onInitiateUpload.call(ctx, result);
        }
      }
    } else if (opts.___s === true && this.onInitiateUpload && helpers.isFunction(this.onInitiateUpload)) {
      ctx = Object.assign({
        file: opts.file
      }, {
        chunkId: opts.chunkId,
        userId: result.userId,

        user() {
          if (Meteor.users && result.userId) {
            return Meteor.users.findOne(result.userId);
          }

          return null;
        },

        eof: opts.eof
      });
      this.onInitiateUpload.call(ctx, result);
    }

    return {
      result,
      opts
    };
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name _finishUpload
   * @summary Internal method. Finish upload, close Writable stream, add record to MongoDB and flush used memory
   * @returns {undefined}
   */


  _finishUpload(result, opts, cb) {
    this._debug("[FilesCollection] [Upload] [finish(ing)Upload] -> ".concat(result.path));

    fs.chmod(result.path, this.permissions, NOOP);
    result.type = this._getMimeType(opts.file);
    result.public = this.public;

    this._updateFileTypes(result);

    this.collection.insert(helpers.clone(result), (colInsert, _id) => {
      if (colInsert) {
        cb && cb(colInsert);

        this._debug('[FilesCollection] [Upload] [_finishUpload] [insert] Error:', colInsert);
      } else {
        this._preCollection.update({
          _id: opts.fileId
        }, {
          $set: {
            isFinished: true
          }
        }, preUpdateError => {
          if (preUpdateError) {
            cb && cb(preUpdateError);

            this._debug('[FilesCollection] [Upload] [_finishUpload] [update] Error:', preUpdateError);
          } else {
            result._id = _id;

            this._debug("[FilesCollection] [Upload] [finish(ed)Upload] -> ".concat(result.path));

            this.onAfterUpload && this.onAfterUpload.call(this, result);
            this.emit('afterUpload', result);
            cb && cb(null, result);
          }
        });
      }
    });
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name _handleUpload
   * @summary Internal method to handle upload process, pipe incoming data to Writable stream
   * @returns {undefined}
   */


  _handleUpload(result, opts, cb) {
    try {
      if (opts.eof) {
        this._currentUploads[result._id].end(() => {
          this.emit('_finishUpload', result, opts, cb);
        });
      } else {
        this._currentUploads[result._id].write(opts.chunkId, opts.binData, cb);
      }
    } catch (e) {
      this._debug('[_handleUpload] [EXCEPTION:]', e);

      cb && cb(e);
    }
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollection
   * @name _getMimeType
   * @param {Object} fileData - File Object
   * @summary Returns file's mime-type
   * @returns {String}
   */


  _getMimeType(fileData) {
    let mime;
    check(fileData, Object);

    if (helpers.isObject(fileData) && fileData.type) {
      mime = fileData.type;
    }

    if (!mime || !helpers.isString(mime)) {
      mime = 'application/octet-stream';
    }

    return mime;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollection
   * @name _getUserId
   * @summary Returns `userId` matching the xmtok token derived from Meteor.server.sessions
   * @returns {String}
   */


  _getUserId(xmtok) {
    if (!xmtok) return null; // throw an error upon an unexpected type of Meteor.server.sessions in order to identify breaking changes

    if (!Meteor.server.sessions instanceof Map || !helpers.isObject(Meteor.server.sessions)) {
      throw new Error('Received incompatible type of Meteor.server.sessions');
    }

    if (Meteor.server.sessions instanceof Map && Meteor.server.sessions.has(xmtok) && helpers.isObject(Meteor.server.sessions.get(xmtok))) {
      // to be used with >= Meteor 1.8.1 where Meteor.server.sessions is a Map
      return Meteor.server.sessions.get(xmtok).userId;
    } else if (helpers.isObject(Meteor.server.sessions) && xmtok in Meteor.server.sessions && helpers.isObject(Meteor.server.sessions[xmtok])) {
      // to be used with < Meteor 1.8.1 where Meteor.server.sessions is an Object
      return Meteor.server.sessions[xmtok].userId;
    }

    return null;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollection
   * @name _getUser
   * @summary Returns object with `userId` and `user()` method which return user's object
   * @returns {Object}
   */


  _getUser() {
    return this.getUser ? this.getUser(...arguments) : this._getUserDefault(...arguments);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollection
   * @name _getUserDefault
   * @summary Default way of recognising user based on 'x_mtok' cookie, can be replaced by 'config.getUser' if defnied. Returns object with `userId` and `user()` method which return user's object
   * @returns {Object}
   */


  _getUserDefault(http) {
    const result = {
      user() {
        return null;
      },

      userId: null
    };

    if (http) {
      let mtok = null;

      if (http.request.headers['x-mtok']) {
        mtok = http.request.headers['x-mtok'];
      } else {
        const cookie = http.request.Cookies;

        if (cookie.has('x_mtok')) {
          mtok = cookie.get('x_mtok');
        }
      }

      if (mtok) {
        const userId = this._getUserId(mtok);

        if (userId) {
          result.user = () => Meteor.users.findOne(userId);

          result.userId = userId;
        }
      }
    }

    return result;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name write
   * @param {Buffer} buffer - Binary File's Buffer
   * @param {Object} opts - Object with file-data
   * @param {String} opts.name - File name, alias: `fileName`
   * @param {String} opts.type - File mime-type
   * @param {Object} opts.meta - File additional meta-data
   * @param {String} opts.userId - UserId, default *null*
   * @param {String} opts.fileId - _id, default *null*
   * @param {Function} callback - function(error, fileObj){...}
   * @param {Boolean} proceedAfterUpload - Proceed onAfterUpload hook
   * @summary Write buffer to FS and add to FilesCollection Collection
   * @returns {FilesCollection} Instance
   */


  write(buffer) {
    let _opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    let _callback = arguments.length > 2 ? arguments[2] : undefined;

    let _proceedAfterUpload = arguments.length > 3 ? arguments[3] : undefined;

    this._debug('[FilesCollection] [write()]');

    let opts = _opts;
    let callback = _callback;
    let proceedAfterUpload = _proceedAfterUpload;

    if (helpers.isFunction(opts)) {
      proceedAfterUpload = callback;
      callback = opts;
      opts = {};
    } else if (helpers.isBoolean(callback)) {
      proceedAfterUpload = callback;
    } else if (helpers.isBoolean(opts)) {
      proceedAfterUpload = opts;
    }

    check(opts, Match.Optional(Object));
    check(callback, Match.Optional(Function));
    check(proceedAfterUpload, Match.Optional(Boolean));
    const fileId = opts.fileId || Random.id();
    const FSName = this.namingFunction ? this.namingFunction(opts) : fileId;
    const fileName = opts.name || opts.fileName ? opts.name || opts.fileName : FSName;

    const {
      extension,
      extensionWithDot
    } = this._getExt(fileName);

    opts.path = "".concat(this.storagePath(opts)).concat(nodePath.sep).concat(FSName).concat(extensionWithDot);
    opts.type = this._getMimeType(opts);

    if (!helpers.isObject(opts.meta)) {
      opts.meta = {};
    }

    if (!helpers.isNumber(opts.size)) {
      opts.size = buffer.length;
    }

    const result = this._dataToSchema({
      name: fileName,
      path: opts.path,
      meta: opts.meta,
      type: opts.type,
      size: opts.size,
      userId: opts.userId,
      extension
    });

    result._id = fileId;
    fs.ensureFile(opts.path, efError => {
      bound(() => {
        if (efError) {
          callback && callback(efError);

          this._debug("[FilesCollection] [write] [ensureFile] [Error:] ".concat(fileName, " -> ").concat(opts.path), efError);
        } else {
          const stream = fs.createWriteStream(opts.path, {
            flags: 'w',
            mode: this.permissions
          });
          stream.end(buffer, streamErr => {
            bound(() => {
              if (streamErr) {
                callback && callback(streamErr);
              } else {
                this.collection.insert(result, (insertErr, _id) => {
                  if (insertErr) {
                    callback && callback(insertErr);

                    this._debug("[FilesCollection] [write] [insert] Error: ".concat(fileName, " -> ").concat(this.collectionName), insertErr);
                  } else {
                    const fileRef = this.collection.findOne(_id);
                    callback && callback(null, fileRef);

                    if (proceedAfterUpload === true) {
                      this.onAfterUpload && this.onAfterUpload.call(this, fileRef);
                      this.emit('afterUpload', fileRef);
                    }

                    this._debug("[FilesCollection] [write]: ".concat(fileName, " -> ").concat(this.collectionName));
                  }
                });
              }
            });
          });
        }
      });
    });
    return this;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name load
   * @param {String} url - URL to file
   * @param {Object} [opts] - Object with file-data
   * @param {Object} opts.headers - HTTP headers to use when requesting the file
   * @param {String} opts.name - File name, alias: `fileName`
   * @param {String} opts.type - File mime-type
   * @param {Object} opts.meta - File additional meta-data
   * @param {String} opts.userId - UserId, default *null*
   * @param {String} opts.fileId - _id, default *null*
   * @param {Number} opts.timeout - Timeout in milliseconds, default: 360000 (6 mins)
   * @param {Function} callback - function(error, fileObj){...}
   * @param {Boolean} [proceedAfterUpload] - Proceed onAfterUpload hook
   * @summary Download file over HTTP, write stream to FS, and add to FilesCollection Collection
   * @returns {FilesCollection} Instance
   */


  load(url) {
    let _opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    let _callback = arguments.length > 2 ? arguments[2] : undefined;

    let _proceedAfterUpload = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;

    this._debug("[FilesCollection] [load(".concat(url, ", ").concat(JSON.stringify(_opts), ", callback)]"));

    let opts = _opts;
    let callback = _callback;
    let proceedAfterUpload = _proceedAfterUpload;

    if (helpers.isFunction(opts)) {
      proceedAfterUpload = callback;
      callback = opts;
      opts = {};
    } else if (helpers.isBoolean(callback)) {
      proceedAfterUpload = callback;
    } else if (helpers.isBoolean(opts)) {
      proceedAfterUpload = opts;
    }

    check(url, String);
    check(opts, Match.Optional(Object));
    check(callback, Match.Optional(Function));
    check(proceedAfterUpload, Match.Optional(Boolean));

    if (!helpers.isObject(opts)) {
      opts = {
        timeout: 360000
      };
    }

    if (!opts.timeout) {
      opts.timeout = 360000;
    }

    const fileId = opts.fileId || Random.id();
    const FSName = this.namingFunction ? this.namingFunction(opts) : fileId;
    const pathParts = url.split('/');
    const fileName = opts.name || opts.fileName ? opts.name || opts.fileName : pathParts[pathParts.length - 1].split('?')[0] || FSName;

    const {
      extension,
      extensionWithDot
    } = this._getExt(fileName);

    opts.path = "".concat(this.storagePath(opts)).concat(nodePath.sep).concat(FSName).concat(extensionWithDot);

    const storeResult = (result, cb) => {
      result._id = fileId;
      this.collection.insert(result, (error, _id) => {
        if (error) {
          cb && cb(error);

          this._debug("[FilesCollection] [load] [insert] Error: ".concat(fileName, " -> ").concat(this.collectionName), error);
        } else {
          const fileRef = this.collection.findOne(_id);
          cb && cb(null, fileRef);

          if (proceedAfterUpload === true) {
            this.onAfterUpload && this.onAfterUpload.call(this, fileRef);
            this.emit('afterUpload', fileRef);
          }

          this._debug("[FilesCollection] [load] [insert] ".concat(fileName, " -> ").concat(this.collectionName));
        }
      });
    };

    fs.ensureFile(opts.path, efError => {
      bound(() => {
        if (efError) {
          callback && callback(efError);

          this._debug("[FilesCollection] [load] [ensureFile] [Error:] ".concat(fileName, " -> ").concat(opts.path), efError);
        } else {
          let isEnded = false;
          let timer = null;
          const wStream = fs.createWriteStream(opts.path, {
            flags: 'w',
            mode: this.permissions,
            autoClose: true,
            emitClose: false
          });

          const onEnd = (_error, response) => {
            if (!isEnded) {
              if (timer) {
                Meteor.clearTimeout(timer);
                timer = null;
              }

              isEnded = true;

              if (response && response.status === 200) {
                this._debug("[FilesCollection] [load] Received: ".concat(url));

                const result = this._dataToSchema({
                  name: fileName,
                  path: opts.path,
                  meta: opts.meta,
                  type: opts.type || response.headers.get('content-type') || this._getMimeType({
                    path: opts.path
                  }),
                  size: opts.size || parseInt(response.headers.get('content-length') || 0),
                  userId: opts.userId,
                  extension
                });

                if (!result.size) {
                  fs.stat(opts.path, (statError, stats) => {
                    bound(() => {
                      if (statError) {
                        callback && callback(statError);
                      } else {
                        result.versions.original.size = result.size = stats.size;
                        storeResult(result, callback);
                      }
                    });
                  });
                } else {
                  storeResult(result, callback);
                }
              } else {
                const error = _error || new Meteor.Error((response === null || response === void 0 ? void 0 : response.status) || 408, (response === null || response === void 0 ? void 0 : response.statusText) || 'Bad response with empty details');

                this._debug("[FilesCollection] [load] [fetch(".concat(url, ")] Error:"), error);

                if (!wStream.destroyed) {
                  wStream.destroy();
                }

                fs.remove(opts.path, removeError => {
                  bound(() => {
                    callback && callback(error);

                    if (removeError) {
                      this._debug("[FilesCollection] [load] [fetch(".concat(url, ")] [fs.remove(").concat(opts.path, ")] removeError:"), removeError);
                    }
                  });
                });
              }
            }
          };

          let resp = void 0;
          wStream.on('error', error => {
            bound(() => {
              onEnd(error);
            });
          });
          wStream.on('close', () => {
            bound(() => {
              onEnd(void 0, resp);
            });
          });
          wStream.on('finish', () => {
            bound(() => {
              onEnd(void 0, resp);
            });
          });
          const controller = new AbortController();
          fetch(url, {
            headers: opts.headers || {},
            signal: controller.signal
          }).then(res => {
            resp = res;
            res.body.on('error', error => {
              bound(() => {
                onEnd(error);
              });
            });
            res.body.pipe(wStream);
          }).catch(fetchError => {
            onEnd(fetchError);
          });

          if (opts.timeout > 0) {
            timer = Meteor.setTimeout(() => {
              onEnd(new Meteor.Error(408, "Request timeout after ".concat(opts.timeout, "ms")));
              controller.abort();
            }, opts.timeout);
          }
        }
      });
    });
    return this;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name addFile
   * @param {String} path          - Path to file
   * @param {String} opts          - [Optional] Object with file-data
   * @param {String} opts.type     - [Optional] File mime-type
   * @param {Object} opts.meta     - [Optional] File additional meta-data
   * @param {String} opts.fileId   - _id, default *null*
   * @param {Object} opts.fileName - [Optional] File name, if not specified file name and extension will be taken from path
   * @param {String} opts.userId   - [Optional] UserId, default *null*
   * @param {Function} callback    - [Optional] function(error, fileObj){...}
   * @param {Boolean} proceedAfterUpload - Proceed onAfterUpload hook
   * @summary Add file from FS to FilesCollection
   * @returns {FilesCollection} Instance
   */


  addFile(path) {
    let _opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    let _callback = arguments.length > 2 ? arguments[2] : undefined;

    let _proceedAfterUpload = arguments.length > 3 ? arguments[3] : undefined;

    this._debug("[FilesCollection] [addFile(".concat(path, ")]"));

    let opts = _opts;
    let callback = _callback;
    let proceedAfterUpload = _proceedAfterUpload;

    if (helpers.isFunction(opts)) {
      proceedAfterUpload = callback;
      callback = opts;
      opts = {};
    } else if (helpers.isBoolean(callback)) {
      proceedAfterUpload = callback;
    } else if (helpers.isBoolean(opts)) {
      proceedAfterUpload = opts;
    }

    if (this.public) {
      throw new Meteor.Error(403, 'Can not run [addFile] on public collection! Just Move file to root of your server, then add record to Collection');
    }

    check(path, String);
    check(opts, Match.Optional(Object));
    check(callback, Match.Optional(Function));
    check(proceedAfterUpload, Match.Optional(Boolean));
    fs.stat(path, (statErr, stats) => bound(() => {
      if (statErr) {
        callback && callback(statErr);
      } else if (stats.isFile()) {
        if (!helpers.isObject(opts)) {
          opts = {};
        }

        opts.path = path;

        if (!opts.fileName) {
          const pathParts = path.split(nodePath.sep);
          opts.fileName = path.split(nodePath.sep)[pathParts.length - 1];
        }

        const {
          extension
        } = this._getExt(opts.fileName);

        if (!helpers.isString(opts.type)) {
          opts.type = this._getMimeType(opts);
        }

        if (!helpers.isObject(opts.meta)) {
          opts.meta = {};
        }

        if (!helpers.isNumber(opts.size)) {
          opts.size = stats.size;
        }

        const result = this._dataToSchema({
          name: opts.fileName,
          path,
          meta: opts.meta,
          type: opts.type,
          size: opts.size,
          userId: opts.userId,
          extension,
          _storagePath: path.replace("".concat(nodePath.sep).concat(opts.fileName), ''),
          fileId: opts.fileId || null
        });

        this.collection.insert(result, (insertErr, _id) => {
          if (insertErr) {
            callback && callback(insertErr);

            this._debug("[FilesCollection] [addFile] [insert] Error: ".concat(result.name, " -> ").concat(this.collectionName), insertErr);
          } else {
            const fileRef = this.collection.findOne(_id);
            callback && callback(null, fileRef);

            if (proceedAfterUpload === true) {
              this.onAfterUpload && this.onAfterUpload.call(this, fileRef);
              this.emit('afterUpload', fileRef);
            }

            this._debug("[FilesCollection] [addFile]: ".concat(result.name, " -> ").concat(this.collectionName));
          }
        });
      } else {
        callback && callback(new Meteor.Error(400, "[FilesCollection] [addFile(".concat(path, ")]: File does not exist")));
      }
    }));
    return this;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollection
   * @name remove
   * @param {String|Object} selector - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)
   * @param {Function} callback - Callback with one `error` argument
   * @summary Remove documents from the collection
   * @returns {FilesCollection} Instance
   */


  remove(selector, callback) {
    this._debug("[FilesCollection] [remove(".concat(JSON.stringify(selector), ")]"));

    if (selector === void 0) {
      return 0;
    }

    check(callback, Match.Optional(Function));
    const files = this.collection.find(selector);

    if (files.count() > 0) {
      files.forEach(file => {
        this.unlink(file);
      });
    } else {
      callback && callback(new Meteor.Error(404, 'Cursor is empty, no files is removed'));
      return this;
    }

    if (this.onAfterRemove) {
      const docs = files.fetch();
      const self = this;
      this.collection.remove(selector, function () {
        callback && callback.apply(this, arguments);
        self.onAfterRemove(docs);
      });
    } else {
      this.collection.remove(selector, callback || NOOP);
    }

    return this;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name deny
   * @param {Object} rules
   * @see  https://docs.meteor.com/api/collections.html#Mongo-Collection-deny
   * @summary link Mongo.Collection deny methods
   * @returns {Mongo.Collection} Instance
   */


  deny(rules) {
    this.collection.deny(rules);
    return this.collection;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name allow
   * @param {Object} rules
   * @see https://docs.meteor.com/api/collections.html#Mongo-Collection-allow
   * @summary link Mongo.Collection allow methods
   * @returns {Mongo.Collection} Instance
   */


  allow(rules) {
    this.collection.allow(rules);
    return this.collection;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name denyClient
   * @see https://docs.meteor.com/api/collections.html#Mongo-Collection-deny
   * @summary Shorthands for Mongo.Collection deny method
   * @returns {Mongo.Collection} Instance
   */


  denyClient() {
    this.collection.deny({
      insert() {
        return true;
      },

      update() {
        return true;
      },

      remove() {
        return true;
      }

    });
    return this.collection;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name allowClient
   * @see https://docs.meteor.com/api/collections.html#Mongo-Collection-allow
   * @summary Shorthands for Mongo.Collection allow method
   * @returns {Mongo.Collection} Instance
   */


  allowClient() {
    this.collection.allow({
      insert() {
        return true;
      },

      update() {
        return true;
      },

      remove() {
        return true;
      }

    });
    return this.collection;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name unlink
   * @param {Object} fileRef - fileObj
   * @param {String} version - [Optional] file's version
   * @param {Function} callback - [Optional] callback function
   * @summary Unlink files and it's versions from FS
   * @returns {FilesCollection} Instance
   */


  unlink(fileRef, version, callback) {
    this._debug("[FilesCollection] [unlink(".concat(fileRef._id, ", ").concat(version, ")]"));

    if (version) {
      if (helpers.isObject(fileRef.versions) && helpers.isObject(fileRef.versions[version]) && fileRef.versions[version].path) {
        fs.unlink(fileRef.versions[version].path, callback || NOOP);
      }
    } else {
      if (helpers.isObject(fileRef.versions)) {
        for (let vKey in fileRef.versions) {
          if (fileRef.versions[vKey] && fileRef.versions[vKey].path) {
            fs.unlink(fileRef.versions[vKey].path, callback || NOOP);
          }
        }
      } else {
        fs.unlink(fileRef.path, callback || NOOP);
      }
    }

    return this;
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name _404
   * @summary Internal method, used to return 404 error
   * @returns {undefined}
   */


  _404(http) {
    this._debug("[FilesCollection] [download(".concat(http.request.originalUrl, ")] [_404] File not found"));

    const text = 'File Not Found :(';

    if (!http.response.headersSent) {
      http.response.writeHead(404, {
        'Content-Type': 'text/plain',
        'Content-Length': text.length
      });
    }

    if (!http.response.finished) {
      http.response.end(text);
    }
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name download
   * @param {Object} http    - Server HTTP object
   * @param {String} version - Requested file version
   * @param {Object} fileRef - Requested file Object
   * @summary Initiates the HTTP response
   * @returns {undefined}
   */


  download(http) {
    let version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'original';
    let fileRef = arguments.length > 2 ? arguments[2] : undefined;
    let vRef;

    this._debug("[FilesCollection] [download(".concat(http.request.originalUrl, ", ").concat(version, ")]"));

    if (fileRef) {
      if (helpers.has(fileRef, 'versions') && helpers.has(fileRef.versions, version)) {
        vRef = fileRef.versions[version];
        vRef._id = fileRef._id;
      } else {
        vRef = fileRef;
      }
    } else {
      vRef = false;
    }

    if (!vRef || !helpers.isObject(vRef)) {
      return this._404(http);
    } else if (fileRef) {
      if (this.downloadCallback) {
        if (!this.downloadCallback.call(Object.assign(http, this._getUser(http)), fileRef)) {
          return this._404(http);
        }
      }

      if (this.interceptDownload && helpers.isFunction(this.interceptDownload) && this.interceptDownload(http, fileRef, version) === true) {
        return void 0;
      }

      fs.stat(vRef.path, (statErr, stats) => bound(() => {
        let responseType;

        if (statErr || !stats.isFile()) {
          return this._404(http);
        }

        if (stats.size !== vRef.size && !this.integrityCheck) {
          vRef.size = stats.size;
        }

        if (stats.size !== vRef.size && this.integrityCheck) {
          responseType = '400';
        }

        return this.serve(http, fileRef, vRef, version, null, responseType || '200');
      }));
      return void 0;
    }

    return this._404(http);
  }
  /*
   * @locus Server
   * @memberOf FilesCollection
   * @name serve
   * @param {Object} http    - Server HTTP object
   * @param {Object} fileRef - Requested file Object
   * @param {Object} vRef    - Requested file version Object
   * @param {String} version - Requested file version
   * @param {stream.Readable|null} readableStream - Readable stream, which serves binary file data
   * @param {String} responseType - Response code
   * @param {Boolean} force200 - Force 200 response code over 206
   * @summary Handle and reply to incoming request
   * @returns {undefined}
   */


  serve(http, fileRef, vRef) {
    let version = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'original';
    let readableStream = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : null;

    let _responseType = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : '200';

    let force200 = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : false;
    let partiral = false;
    let reqRange = false;
    let dispositionType = '';
    let start;
    let end;
    let take;
    let responseType = _responseType;

    if (http.params.query.download && http.params.query.download === 'true') {
      dispositionType = 'attachment; ';
    } else {
      dispositionType = 'inline; ';
    }

    const dispositionName = "filename=\"".concat(encodeURI(vRef.name || fileRef.name).replace(/\,/g, '%2C'), "\"; filename*=UTF-8''").concat(encodeURIComponent(vRef.name || fileRef.name), "; ");
    const dispositionEncoding = 'charset=UTF-8';

    if (!http.response.headersSent) {
      http.response.setHeader('Content-Disposition', dispositionType + dispositionName + dispositionEncoding);
    }

    if (http.request.headers.range && !force200) {
      partiral = true;
      const array = http.request.headers.range.split(/bytes=([0-9]*)-([0-9]*)/);
      start = parseInt(array[1]);
      end = parseInt(array[2]);

      if (isNaN(end)) {
        end = vRef.size - 1;
      }

      take = end - start;
    } else {
      start = 0;
      end = vRef.size - 1;
      take = vRef.size;
    }

    if (partiral || http.params.query.play && http.params.query.play === 'true') {
      reqRange = {
        start,
        end
      };

      if (isNaN(start) && !isNaN(end)) {
        reqRange.start = end - take;
        reqRange.end = end;
      }

      if (!isNaN(start) && isNaN(end)) {
        reqRange.start = start;
        reqRange.end = start + take;
      }

      if (start + take >= vRef.size) {
        reqRange.end = vRef.size - 1;
      }

      if (this.strict && (reqRange.start >= vRef.size - 1 || reqRange.end > vRef.size - 1)) {
        responseType = '416';
      } else {
        responseType = '206';
      }
    } else {
      responseType = '200';
    }

    const streamErrorHandler = error => {
      this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [500]"), error);

      if (!http.response.finished) {
        http.response.end(error.toString());
      }
    };

    const headers = helpers.isFunction(this.responseHeaders) ? this.responseHeaders(responseType, fileRef, vRef, version, http) : this.responseHeaders;

    if (!headers['Cache-Control']) {
      if (!http.response.headersSent) {
        http.response.setHeader('Cache-Control', this.cacheControl);
      }
    }

    for (let key in headers) {
      if (!http.response.headersSent) {
        http.response.setHeader(key, headers[key]);
      }
    }

    const respond = (stream, code) => {
      stream._isEnded = false;

      const closeStreamCb = closeError => {
        if (!closeError) {
          stream._isEnded = true;
        } else {
          this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [respond] [closeStreamCb] Error:"), closeError);
        }
      };

      const closeStream = () => {
        if (!stream._isEnded) {
          if (typeof stream.close === 'function') {
            stream.close(closeStreamCb);
          } else if (typeof stream.end === 'function') {
            stream.end(closeStreamCb);
          } else if (typeof stream.destroy === 'function') {
            stream.destroy('Got to close this stream', closeStreamCb);
          }
        }
      };

      if (!http.response.headersSent && readableStream) {
        http.response.writeHead(code);
      }

      http.response.on('close', closeStream);
      http.request.on('aborted', () => {
        http.request.aborted = true;
        closeStream();
      });
      stream.on('open', () => {
        if (!http.response.headersSent) {
          http.response.writeHead(code);
        }
      }).on('abort', () => {
        closeStream();

        if (!http.response.finished) {
          http.response.end();
        }

        if (!http.request.aborted) {
          http.request.destroy();
        }
      }).on('error', err => {
        closeStream();
        streamErrorHandler(err);
      }).on('end', () => {
        closeStream();

        if (!http.response.finished) {
          http.response.end();
        }
      }).pipe(http.response);
    };

    switch (responseType) {
      case '400':
        this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [400] Content-Length mismatch!"));

        var text = 'Content-Length mismatch!';

        if (!http.response.headersSent) {
          http.response.writeHead(400, {
            'Content-Type': 'text/plain',
            'Content-Length': text.length
          });
        }

        if (!http.response.finished) {
          http.response.end(text);
        }

        break;

      case '404':
        this._404(http);

        break;

      case '416':
        this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [416] Content-Range is not specified!"));

        if (!http.response.headersSent) {
          http.response.writeHead(416);
        }

        if (!http.response.finished) {
          http.response.end();
        }

        break;

      case '206':
        this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [206]"));

        if (!http.response.headersSent) {
          http.response.setHeader('Content-Range', "bytes ".concat(reqRange.start, "-").concat(reqRange.end, "/").concat(vRef.size));
        }

        respond(readableStream || fs.createReadStream(vRef.path, {
          start: reqRange.start,
          end: reqRange.end
        }), 206);
        break;

      default:
        if (!http.response.headersSent) {
          http.response.setHeader('Content-Length', "".concat(vRef.size));
        }

        this._debug("[FilesCollection] [serve(".concat(vRef.path, ", ").concat(version, ")] [200]"));

        respond(readableStream || fs.createReadStream(vRef.path), 200);
        break;
    }
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"core.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/core.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => FilesCollectionCore
});
let EventEmitter;
module.link("eventemitter3", {
  EventEmitter(v) {
    EventEmitter = v;
  }

}, 0);
let check, Match;
module.link("meteor/check", {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 1);
let formatFleURL, helpers;
module.link("./lib.js", {
  formatFleURL(v) {
    formatFleURL = v;
  },

  helpers(v) {
    helpers = v;
  }

}, 2);
let FilesCursor, FileCursor;
module.link("./cursor.js", {
  FilesCursor(v) {
    FilesCursor = v;
  },

  FileCursor(v) {
    FileCursor = v;
  }

}, 3);

class FilesCollectionCore extends EventEmitter {
  constructor() {
    super();
  }

  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _debug
   * @summary Print logs in debug mode
   * @returns {void}
   */
  _debug() {
    if (this.debug) {
      (console.info || console.log || function () {}).apply(void 0, arguments);
    }
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _getFileName
   * @param {Object} fileData - File Object
   * @summary Returns file's name
   * @returns {String}
   */


  _getFileName(fileData) {
    const fileName = fileData.name || fileData.fileName;

    if (helpers.isString(fileName) && fileName.length > 0) {
      return (fileData.name || fileData.fileName).replace(/^\.\.+/, '').replace(/\.{2,}/g, '.').replace(/\//g, '');
    }

    return '';
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _getExt
   * @param {String} FileName - File name
   * @summary Get extension from FileName
   * @returns {Object}
   */


  _getExt(fileName) {
    if (fileName.includes('.')) {
      const extension = (fileName.split('.').pop().split('?')[0] || '').toLowerCase();
      return {
        ext: extension,
        extension,
        extensionWithDot: ".".concat(extension)
      };
    }

    return {
      ext: '',
      extension: '',
      extensionWithDot: ''
    };
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _updateFileTypes
   * @param {Object} data - File data
   * @summary Internal method. Classify file based on 'type' field
   */


  _updateFileTypes(data) {
    data.isVideo = /^video\//i.test(data.type);
    data.isAudio = /^audio\//i.test(data.type);
    data.isImage = /^image\//i.test(data.type);
    data.isText = /^text\//i.test(data.type);
    data.isJSON = /^application\/json$/i.test(data.type);
    data.isPDF = /^application\/(x-)?pdf$/i.test(data.type);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name _dataToSchema
   * @param {Object} data - File data
   * @summary Internal method. Build object in accordance with default schema from File data
   * @returns {Object}
   */


  _dataToSchema(data) {
    const ds = {
      name: data.name,
      extension: data.extension,
      ext: data.extension,
      extensionWithDot: '.' + data.extension,
      path: data.path,
      meta: data.meta,
      type: data.type,
      mime: data.type,
      'mime-type': data.type,
      size: data.size,
      userId: data.userId || null,
      versions: {
        original: {
          path: data.path,
          size: data.size,
          type: data.type,
          extension: data.extension
        }
      },
      _downloadRoute: data._downloadRoute || this.downloadRoute,
      _collectionName: data._collectionName || this.collectionName
    }; //Optional fileId

    if (data.fileId) {
      ds._id = data.fileId;
    }

    this._updateFileTypes(ds);

    ds._storagePath = data._storagePath || this.storagePath(Object.assign({}, data, ds));
    return ds;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name findOne
   * @param {String|Object} selector - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)
   * @param {Object} options - Mongo-Style selector Options (http://docs.meteor.com/api/collections.html#sortspecifiers)
   * @summary Find and return Cursor for matching document Object
   * @returns {FileCursor} Instance
   */


  findOne() {
    let selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let options = arguments.length > 1 ? arguments[1] : undefined;

    this._debug("[FilesCollection] [findOne(".concat(JSON.stringify(selector), ", ").concat(JSON.stringify(options), ")]"));

    check(selector, Match.Optional(Match.OneOf(Object, String, Boolean, Number, null)));
    check(options, Match.Optional(Object));
    const doc = this.collection.findOne(selector, options);

    if (doc) {
      return new FileCursor(doc, this);
    }

    return doc;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name find
   * @param {String|Object} selector - Mongo-Style selector (http://docs.meteor.com/api/collections.html#selectors)
   * @param {Object}        options  - Mongo-Style selector Options (http://docs.meteor.com/api/collections.html#sortspecifiers)
   * @summary Find and return Cursor for matching documents
   * @returns {FilesCursor} Instance
   */


  find() {
    let selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    let options = arguments.length > 1 ? arguments[1] : undefined;

    this._debug("[FilesCollection] [find(".concat(JSON.stringify(selector), ", ").concat(JSON.stringify(options), ")]"));

    check(selector, Match.Optional(Match.OneOf(Object, String, Boolean, Number, null)));
    check(options, Match.Optional(Object));
    return new FilesCursor(selector, options, this);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name update
   * @see http://docs.meteor.com/#/full/update
   * @summary link Mongo.Collection update method
   * @returns {Mongo.Collection} Instance
   */


  update() {
    this.collection.update.apply(this.collection, arguments);
    return this.collection;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCollectionCore
   * @name link
   * @param {Object} fileRef - File reference object
   * @param {String} version - Version of file you would like to request
   * @param {String} URIBase - [Optional] URI base, see - https://github.com/VeliovGroup/Meteor-Files/issues/626
   * @summary Returns downloadable URL
   * @returns {String} Empty string returned in case if file not found in DB
   */


  link(fileRef) {
    let version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'original';
    let URIBase = arguments.length > 2 ? arguments[2] : undefined;

    this._debug("[FilesCollection] [link(".concat(helpers.isObject(fileRef) ? fileRef._id : void 0, ", ").concat(version, ")]"));

    check(fileRef, Object);

    if (!fileRef) {
      return '';
    }

    return formatFleURL(fileRef, version, URIBase);
  }

}

FilesCollectionCore.__helpers = helpers;
FilesCollectionCore.schema = {
  _id: {
    type: String
  },
  size: {
    type: Number
  },
  name: {
    type: String
  },
  type: {
    type: String
  },
  path: {
    type: String
  },
  isVideo: {
    type: Boolean
  },
  isAudio: {
    type: Boolean
  },
  isImage: {
    type: Boolean
  },
  isText: {
    type: Boolean
  },
  isJSON: {
    type: Boolean
  },
  isPDF: {
    type: Boolean
  },
  extension: {
    type: String,
    optional: true
  },
  ext: {
    type: String,
    optional: true
  },
  extensionWithDot: {
    type: String,
    optional: true
  },
  mime: {
    type: String,
    optional: true
  },
  'mime-type': {
    type: String,
    optional: true
  },
  _storagePath: {
    type: String
  },
  _downloadRoute: {
    type: String
  },
  _collectionName: {
    type: String
  },
  public: {
    type: Boolean,
    optional: true
  },
  meta: {
    type: Object,
    blackbox: true,
    optional: true
  },
  userId: {
    type: String,
    optional: true
  },
  updatedAt: {
    type: Date,
    optional: true
  },
  versions: {
    type: Object,
    blackbox: true
  }
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cursor.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/cursor.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  FileCursor: () => FileCursor,
  FilesCursor: () => FilesCursor
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

class FileCursor {
  constructor(_fileRef, _collection) {
    this._fileRef = _fileRef;
    this._collection = _collection;
    Object.assign(this, _fileRef);
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name remove
   * @param callback {Function} - Triggered asynchronously after item is removed or failed to be removed
   * @summary Remove document
   * @returns {FileCursor}
   */


  remove(callback) {
    this._collection._debug('[FilesCollection] [FileCursor] [remove()]');

    if (this._fileRef) {
      this._collection.remove(this._fileRef._id, callback);
    } else {
      callback && callback(new Meteor.Error(404, 'No such file'));
    }

    return this;
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name link
   * @param version {String} - Name of file's subversion
   * @param URIBase {String} - [Optional] URI base, see - https://github.com/VeliovGroup/Meteor-Files/issues/626
   * @summary Returns downloadable URL to File
   * @returns {String}
   */


  link() {
    let version = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'original';
    let URIBase = arguments.length > 1 ? arguments[1] : undefined;

    this._collection._debug("[FilesCollection] [FileCursor] [link(".concat(version, ")]"));

    if (this._fileRef) {
      return this._collection.link(this._fileRef, version, URIBase);
    }

    return '';
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name get
   * @param property {String} - Name of sub-object property
   * @summary Returns current document as a plain Object, if `property` is specified - returns value of sub-object property
   * @returns {Object|mix}
   */


  get(property) {
    this._collection._debug("[FilesCollection] [FileCursor] [get(".concat(property, ")]"));

    if (property) {
      return this._fileRef[property];
    }

    return this._fileRef;
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name fetch
   * @summary Returns document as plain Object in Array
   * @returns {[Object]}
   */


  fetch() {
    this._collection._debug('[FilesCollection] [FileCursor] [fetch()]');

    return [this._fileRef];
  }
  /*
   * @locus Anywhere
   * @memberOf FileCursor
   * @name with
   * @summary Returns reactive version of current FileCursor, useful to use with `{{#with}}...{{/with}}` block template helper
   * @returns {[Object]}
   */


  with() {
    this._collection._debug('[FilesCollection] [FileCursor] [with()]');

    return Object.assign(this, this._collection.collection.findOne(this._fileRef._id));
  }

}

class FilesCursor {
  constructor() {
    let _selector = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    let options = arguments.length > 1 ? arguments[1] : undefined;

    let _collection = arguments.length > 2 ? arguments[2] : undefined;

    this._collection = _collection;
    this._selector = _selector;
    this._current = -1;
    this.cursor = this._collection.collection.find(this._selector, options);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name get
   * @summary Returns all matching document(s) as an Array. Alias of `.fetch()`
   * @returns {[Object]}
   */


  get() {
    this._collection._debug('[FilesCollection] [FilesCursor] [get()]');

    return this.cursor.fetch();
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name hasNext
   * @summary Returns `true` if there is next item available on Cursor
   * @returns {Boolean}
   */


  hasNext() {
    this._collection._debug('[FilesCollection] [FilesCursor] [hasNext()]');

    return this._current < this.cursor.count() - 1;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name next
   * @summary Returns next item on Cursor, if available
   * @returns {Object|undefined}
   */


  next() {
    this._collection._debug('[FilesCollection] [FilesCursor] [next()]');

    this.cursor.fetch()[++this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name hasPrevious
   * @summary Returns `true` if there is previous item available on Cursor
   * @returns {Boolean}
   */


  hasPrevious() {
    this._collection._debug('[FilesCollection] [FilesCursor] [hasPrevious()]');

    return this._current !== -1;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name previous
   * @summary Returns previous item on Cursor, if available
   * @returns {Object|undefined}
   */


  previous() {
    this._collection._debug('[FilesCollection] [FilesCursor] [previous()]');

    this.cursor.fetch()[--this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name fetch
   * @summary Returns all matching document(s) as an Array.
   * @returns {[Object]}
   */


  fetch() {
    this._collection._debug('[FilesCollection] [FilesCursor] [fetch()]');

    return this.cursor.fetch() || [];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name first
   * @summary Returns first item on Cursor, if available
   * @returns {Object|undefined}
   */


  first() {
    this._collection._debug('[FilesCollection] [FilesCursor] [first()]');

    this._current = 0;
    return this.fetch()[this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name last
   * @summary Returns last item on Cursor, if available
   * @returns {Object|undefined}
   */


  last() {
    this._collection._debug('[FilesCollection] [FilesCursor] [last()]');

    this._current = this.count() - 1;
    return this.fetch()[this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name count
   * @summary Returns the number of documents that match a query
   * @returns {Number}
   */


  count() {
    this._collection._debug('[FilesCollection] [FilesCursor] [count()]');

    return this.cursor.count();
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name remove
   * @param callback {Function} - Triggered asynchronously after item is removed or failed to be removed
   * @summary Removes all documents that match a query
   * @returns {FilesCursor}
   */


  remove(callback) {
    this._collection._debug('[FilesCollection] [FilesCursor] [remove()]');

    this._collection.remove(this._selector, callback);

    return this;
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name forEach
   * @param callback {Function} - Function to call. It will be called with three arguments: the `file`, a 0-based index, and cursor itself
   * @param context {Object} - An object which will be the value of `this` inside `callback`
   * @summary Call `callback` once for each matching document, sequentially and synchronously.
   * @returns {undefined}
   */


  forEach(callback) {
    let context = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    this._collection._debug('[FilesCollection] [FilesCursor] [forEach()]');

    this.cursor.forEach(callback, context);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name each
   * @summary Returns an Array of FileCursor made for each document on current cursor
   *          Useful when using in {{#each FilesCursor#each}}...{{/each}} block template helper
   * @returns {[FileCursor]}
   */


  each() {
    return this.map(file => {
      return new FileCursor(file, this._collection);
    });
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name map
   * @param callback {Function} - Function to call. It will be called with three arguments: the `file`, a 0-based index, and cursor itself
   * @param context {Object} - An object which will be the value of `this` inside `callback`
   * @summary Map `callback` over all matching documents. Returns an Array.
   * @returns {Array}
   */


  map(callback) {
    let context = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    this._collection._debug('[FilesCollection] [FilesCursor] [map()]');

    return this.cursor.map(callback, context);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name current
   * @summary Returns current item on Cursor, if available
   * @returns {Object|undefined}
   */


  current() {
    this._collection._debug('[FilesCollection] [FilesCursor] [current()]');

    if (this._current < 0) {
      this._current = 0;
    }

    return this.fetch()[this._current];
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name observe
   * @param callbacks {Object} - Functions to call to deliver the result set as it changes
   * @summary Watch a query. Receive callbacks as the result set changes.
   * @url http://docs.meteor.com/api/collections.html#Mongo-Cursor-observe
   * @returns {Object} - live query handle
   */


  observe(callbacks) {
    this._collection._debug('[FilesCollection] [FilesCursor] [observe()]');

    return this.cursor.observe(callbacks);
  }
  /*
   * @locus Anywhere
   * @memberOf FilesCursor
   * @name observeChanges
   * @param callbacks {Object} - Functions to call to deliver the result set as it changes
   * @summary Watch a query. Receive callbacks as the result set changes. Only the differences between the old and new documents are passed to the callbacks.
   * @url http://docs.meteor.com/api/collections.html#Mongo-Cursor-observeChanges
   * @returns {Object} - live query handle
   */


  observeChanges(callbacks) {
    this._collection._debug('[FilesCollection] [FilesCursor] [observeChanges()]');

    return this.cursor.observeChanges(callbacks);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/lib.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  fixJSONParse: () => fixJSONParse,
  fixJSONStringify: () => fixJSONStringify,
  formatFleURL: () => formatFleURL,
  helpers: () => helpers
});
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 0);
const helpers = {
  isUndefined(obj) {
    return obj === void 0;
  },

  isObject(obj) {
    if (this.isArray(obj) || this.isFunction(obj)) {
      return false;
    }

    return obj === Object(obj);
  },

  isArray(obj) {
    return Array.isArray(obj);
  },

  isBoolean(obj) {
    return obj === true || obj === false || Object.prototype.toString.call(obj) === '[object Boolean]';
  },

  isFunction(obj) {
    return typeof obj === 'function' || false;
  },

  isEmpty(obj) {
    if (this.isDate(obj)) {
      return false;
    }

    if (this.isObject(obj)) {
      return !Object.keys(obj).length;
    }

    if (this.isArray(obj) || this.isString(obj)) {
      return !obj.length;
    }

    return false;
  },

  clone(obj) {
    if (!this.isObject(obj)) return obj;
    return this.isArray(obj) ? obj.slice() : Object.assign({}, obj);
  },

  has(_obj, path) {
    let obj = _obj;

    if (!this.isObject(obj)) {
      return false;
    }

    if (!this.isArray(path)) {
      return this.isObject(obj) && Object.prototype.hasOwnProperty.call(obj, path);
    }

    const length = path.length;

    for (let i = 0; i < length; i++) {
      if (!Object.prototype.hasOwnProperty.call(obj, path[i])) {
        return false;
      }

      obj = obj[path[i]];
    }

    return !!length;
  },

  omit(obj) {
    const clear = Object.assign({}, obj);

    for (var _len = arguments.length, keys = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      keys[_key - 1] = arguments[_key];
    }

    for (let i = keys.length - 1; i >= 0; i--) {
      delete clear[keys[i]];
    }

    return clear;
  },

  now: Date.now,

  throttle(func, wait) {
    let options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    let previous = 0;
    let timeout = null;
    let result;
    const that = this;
    let self;
    let args;

    const later = () => {
      previous = options.leading === false ? 0 : that.now();
      timeout = null;
      result = func.apply(self, args);

      if (!timeout) {
        self = args = null;
      }
    };

    const throttled = function () {
      const now = that.now();
      if (!previous && options.leading === false) previous = now;
      const remaining = wait - (now - previous);
      self = this;
      args = arguments;

      if (remaining <= 0 || remaining > wait) {
        if (timeout) {
          clearTimeout(timeout);
          timeout = null;
        }

        previous = now;
        result = func.apply(self, args);

        if (!timeout) {
          self = args = null;
        }
      } else if (!timeout && options.trailing !== false) {
        timeout = setTimeout(later, remaining);
      }

      return result;
    };

    throttled.cancel = () => {
      clearTimeout(timeout);
      previous = 0;
      timeout = self = args = null;
    };

    return throttled;
  }

};
const _helpers = ['String', 'Number', 'Date'];

for (let i = 0; i < _helpers.length; i++) {
  helpers['is' + _helpers[i]] = function (obj) {
    return Object.prototype.toString.call(obj) === '[object ' + _helpers[i] + ']';
  };
}
/*
 * @const {Function} fixJSONParse - Fix issue with Date parse
 */


const fixJSONParse = function (obj) {
  for (let key in obj) {
    if (helpers.isString(obj[key]) && obj[key].includes('=--JSON-DATE--=')) {
      obj[key] = obj[key].replace('=--JSON-DATE--=', '');
      obj[key] = new Date(parseInt(obj[key]));
    } else if (helpers.isObject(obj[key])) {
      obj[key] = fixJSONParse(obj[key]);
    } else if (helpers.isArray(obj[key])) {
      let v;

      for (let i = 0; i < obj[key].length; i++) {
        v = obj[key][i];

        if (helpers.isObject(v)) {
          obj[key][i] = fixJSONParse(v);
        } else if (helpers.isString(v) && v.includes('=--JSON-DATE--=')) {
          v = v.replace('=--JSON-DATE--=', '');
          obj[key][i] = new Date(parseInt(v));
        }
      }
    }
  }

  return obj;
};
/*
 * @const {Function} fixJSONStringify - Fix issue with Date stringify
 */


const fixJSONStringify = function (obj) {
  for (let key in obj) {
    if (helpers.isDate(obj[key])) {
      obj[key] = "=--JSON-DATE--=".concat(+obj[key]);
    } else if (helpers.isObject(obj[key])) {
      obj[key] = fixJSONStringify(obj[key]);
    } else if (helpers.isArray(obj[key])) {
      let v;

      for (let i = 0; i < obj[key].length; i++) {
        v = obj[key][i];

        if (helpers.isObject(v)) {
          obj[key][i] = fixJSONStringify(v);
        } else if (helpers.isDate(v)) {
          obj[key][i] = "=--JSON-DATE--=".concat(+v);
        }
      }
    }
  }

  return obj;
};
/*
 * @locus Anywhere
 * @private
 * @name formatFleURL
 * @param {Object} fileRef - File reference object
 * @param {String} version - [Optional] Version of file you would like build URL for
 * @param {String} URIBase - [Optional] URI base, see - https://github.com/VeliovGroup/Meteor-Files/issues/626
 * @summary Returns formatted URL for file
 * @returns {String} Downloadable link
 */


const formatFleURL = function (fileRef) {
  let version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'original';

  let _URIBase = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : (__meteor_runtime_config__ || {}).ROOT_URL;

  check(fileRef, Object);
  check(version, String);
  let URIBase = _URIBase;

  if (!helpers.isString(URIBase)) {
    URIBase = (__meteor_runtime_config__ || {}).ROOT_URL || '/';
  }

  const _root = URIBase.replace(/\/+$/, '');

  const vRef = fileRef.versions && fileRef.versions[version] || fileRef || {};
  let ext;

  if (helpers.isString(vRef.extension)) {
    ext = ".".concat(vRef.extension.replace(/^\./, ''));
  } else {
    ext = '';
  }

  if (fileRef.public === true) {
    return _root + (version === 'original' ? "".concat(fileRef._downloadRoute, "/").concat(fileRef._id).concat(ext) : "".concat(fileRef._downloadRoute, "/").concat(version, "-").concat(fileRef._id).concat(ext));
  }

  return "".concat(_root).concat(fileRef._downloadRoute, "/").concat(fileRef._collectionName, "/").concat(fileRef._id, "/").concat(version, "/").concat(fileRef._id).concat(ext);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"write-stream.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/ostrio_files/write-stream.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => WriteStream
});
let fs;
module.link("fs-extra", {
  default(v) {
    fs = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let helpers;
module.link("./lib.js", {
  helpers(v) {
    helpers = v;
  }

}, 2);

const NOOP = () => {};
/*
 * @const {Object} bound   - Meteor.bindEnvironment (Fiber wrapper)
 * @const {Object} fdCache - File Descriptors Cache
 */


const bound = Meteor.bindEnvironment(callback => callback());
const fdCache = {};
/*
 * @private
 * @locus Server
 * @class WriteStream
 * @param path        {String} - Path to file on FS
 * @param maxLength   {Number} - Max amount of chunks in stream
 * @param file        {Object} - fileRef Object
 * @param permissions {String} - Permissions which will be set to open descriptor (octal), like: `611` or `0o777`. Default: 0755
 * @summary writableStream wrapper class, makes sure chunks is written in given order. Implementation of queue stream.
 */

class WriteStream {
  constructor(path, maxLength, file, permissions) {
    this.path = path;
    this.maxLength = maxLength;
    this.file = file;
    this.permissions = permissions;

    if (!this.path || !helpers.isString(this.path)) {
      return;
    }

    this.fd = null;
    this.writtenChunks = 0;
    this.ended = false;
    this.aborted = false;

    if (fdCache[this.path] && !fdCache[this.path].ended && !fdCache[this.path].aborted) {
      this.fd = fdCache[this.path].fd;
      this.writtenChunks = fdCache[this.path].writtenChunks;
    } else {
      fs.ensureFile(this.path, efError => {
        bound(() => {
          if (efError) {
            this.abort();
            throw new Meteor.Error(500, '[FilesCollection] [writeStream] [ensureFile] [Error:] ' + efError);
          } else {
            fs.open(this.path, 'r+', this.permissions, (oError, fd) => {
              bound(() => {
                if (oError) {
                  this.abort();
                  throw new Meteor.Error(500, '[FilesCollection] [writeStream] [ensureFile] [open] [Error:] ' + oError);
                } else {
                  this.fd = fd;
                  fdCache[this.path] = this;
                }
              });
            });
          }
        });
      });
    }
  }
  /*
   * @memberOf writeStream
   * @name write
   * @param {Number} num - Chunk position in a stream
   * @param {Buffer} chunk - Buffer (chunk binary data)
   * @param {Function} callback - Callback
   * @summary Write chunk in given order
   * @returns {Boolean} - True if chunk is sent to stream, false if chunk is set into queue
   */


  write(num, chunk, callback) {
    if (!this.aborted && !this.ended) {
      if (this.fd) {
        fs.write(this.fd, chunk, 0, chunk.length, (num - 1) * this.file.chunkSize, (error, written, buffer) => {
          bound(() => {
            callback && callback(error, written, buffer);

            if (error) {
              console.warn('[FilesCollection] [writeStream] [write] [Error:]', error);
              this.abort();
            } else {
              ++this.writtenChunks;
            }
          });
        });
      } else {
        Meteor.setTimeout(() => {
          this.write(num, chunk, callback);
        }, 25);
      }
    }

    return false;
  }
  /*
   * @memberOf writeStream
   * @name end
   * @param {Function} callback - Callback
   * @summary Finishes writing to writableStream, only after all chunks in queue is written
   * @returns {Boolean} - True if stream is fulfilled, false if queue is in progress
   */


  end(callback) {
    if (!this.aborted && !this.ended) {
      if (this.writtenChunks === this.maxLength) {
        fs.close(this.fd, () => {
          bound(() => {
            delete fdCache[this.path];
            this.ended = true;
            callback && callback(void 0, true);
          });
        });
        return true;
      }

      fs.stat(this.path, (error, stat) => {
        bound(() => {
          if (!error && stat) {
            this.writtenChunks = Math.ceil(stat.size / this.file.chunkSize);
          }

          return Meteor.setTimeout(() => {
            this.end(callback);
          }, 25);
        });
      });
    } else {
      callback && callback(void 0, this.ended);
    }

    return false;
  }
  /*
   * @memberOf writeStream
   * @name abort
   * @param {Function} callback - Callback
   * @summary Aborts writing to writableStream, removes created file
   * @returns {Boolean} - True
   */


  abort(callback) {
    this.aborted = true;
    delete fdCache[this.path];
    fs.unlink(this.path, callback || NOOP);
    return true;
  }
  /*
   * @memberOf writeStream
   * @name stop
   * @summary Stop writing to writableStream
   * @returns {Boolean} - True
   */


  stop() {
    this.aborted = true;
    delete fdCache[this.path];
    return true;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"node_modules":{"fs-extra":{"package.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/fs-extra/package.json                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "name": "fs-extra",
  "version": "9.1.0",
  "main": "./lib/index.js"
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/fs-extra/lib/index.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"eventemitter3":{"package.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/eventemitter3/package.json                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "name": "eventemitter3",
  "version": "4.0.7",
  "main": "index.js"
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/eventemitter3/index.js                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"abort-controller":{"package.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/abort-controller/package.json                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "name": "abort-controller",
  "version": "3.0.0",
  "main": "dist/abort-controller"
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dist":{"abort-controller.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/ostrio_files/node_modules/abort-controller/dist/abort-controller.js                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.useNode();
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/ostrio:files/server.js");

/* Exports */
Package._define("ostrio:files", exports, {
  FilesCollection: FilesCollection
});

})();

//# sourceURL=meteor://💻app/packages/ostrio_files.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmZpbGVzL3NlcnZlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmZpbGVzL2NvcmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29zdHJpbzpmaWxlcy9jdXJzb3IuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29zdHJpbzpmaWxlcy9saWIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29zdHJpbzpmaWxlcy93cml0ZS1zdHJlYW0uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiRmlsZXNDb2xsZWN0aW9uIiwiTW9uZ28iLCJsaW5rIiwidiIsImZldGNoIiwiV2ViQXBwIiwiTWV0ZW9yIiwiUmFuZG9tIiwiQ29va2llcyIsImNoZWNrIiwiTWF0Y2giLCJXcml0ZVN0cmVhbSIsImRlZmF1bHQiLCJGaWxlc0NvbGxlY3Rpb25Db3JlIiwiZml4SlNPTlBhcnNlIiwiZml4SlNPTlN0cmluZ2lmeSIsImhlbHBlcnMiLCJBYm9ydENvbnRyb2xsZXIiLCJmcyIsIm5vZGVRcyIsIm5vZGVQYXRoIiwiYm91bmQiLCJiaW5kRW52aXJvbm1lbnQiLCJjYWxsYmFjayIsIk5PT1AiLCJjb25zdHJ1Y3RvciIsImNvbmZpZyIsInN0b3JhZ2VQYXRoIiwiZGVidWciLCJzY2hlbWEiLCJwdWJsaWMiLCJzdHJpY3QiLCJnZXRVc2VyIiwiY2h1bmtTaXplIiwicHJvdGVjdGVkIiwiY29sbGVjdGlvbiIsInBlcm1pc3Npb25zIiwiY2FjaGVDb250cm9sIiwiZG93bmxvYWRSb3V0ZSIsIm9uQWZ0ZXJVcGxvYWQiLCJvbkFmdGVyUmVtb3ZlIiwiZGlzYWJsZVVwbG9hZCIsIm9uQmVmb3JlUmVtb3ZlIiwiaW50ZWdyaXR5Q2hlY2siLCJjb2xsZWN0aW9uTmFtZSIsIm9uQmVmb3JlVXBsb2FkIiwibmFtaW5nRnVuY3Rpb24iLCJyZXNwb25zZUhlYWRlcnMiLCJkaXNhYmxlRG93bmxvYWQiLCJhbGxvd2VkT3JpZ2lucyIsImFsbG93Q2xpZW50Q29kZSIsImRvd25sb2FkQ2FsbGJhY2siLCJvbkluaXRpYXRlVXBsb2FkIiwiaW50ZXJjZXB0UmVxdWVzdCIsImludGVyY2VwdERvd25sb2FkIiwiY29udGludWVVcGxvYWRUVEwiLCJwYXJlbnREaXJQZXJtaXNzaW9ucyIsImFsbG93UXVlcnlTdHJpbmdDb29raWVzIiwiX3ByZUNvbGxlY3Rpb24iLCJfcHJlQ29sbGVjdGlvbk5hbWUiLCJzZWxmIiwiaXNCb29sZWFuIiwiTWF0aCIsImZsb29yIiwiaXNTdHJpbmciLCJDb2xsZWN0aW9uIiwiX25hbWUiLCJmaWxlc0NvbGxlY3Rpb24iLCJTdHJpbmciLCJFcnJvciIsInJlcGxhY2UiLCJpc0Z1bmN0aW9uIiwiaXNOdW1iZXIiLCJwYXJzZUludCIsImlzT2JqZWN0IiwiX2N1cnJlbnRVcGxvYWRzIiwicmVzcG9uc2VDb2RlIiwiZmlsZVJlZiIsInZlcnNpb25SZWYiLCJoZWFkZXJzIiwiUHJhZ21hIiwic2l6ZSIsIkNvbm5lY3Rpb24iLCJ0eXBlIiwic2VwIiwic3AiLCJhcHBseSIsImFyZ3VtZW50cyIsIm5vcm1hbGl6ZSIsIl9kZWJ1ZyIsIm1rZGlycyIsIm1vZGUiLCJlcnJvciIsIkJvb2xlYW4iLCJOdW1iZXIiLCJGdW5jdGlvbiIsIk9uZU9mIiwiT2JqZWN0IiwiYWxsb3dlZENvcmRvdmFPcmlnaW5zIiwiX2Vuc3VyZUluZGV4IiwiY3JlYXRlZEF0IiwiZXhwaXJlQWZ0ZXJTZWNvbmRzIiwiYmFja2dyb3VuZCIsIl9wcmVDb2xsZWN0aW9uQ3Vyc29yIiwiZmluZCIsImZpZWxkcyIsIl9pZCIsImlzRmluaXNoZWQiLCJvYnNlcnZlIiwiY2hhbmdlZCIsImRvYyIsInJlbW92ZSIsInJlbW92ZWQiLCJzdG9wIiwiZW5kIiwiY291bnQiLCJhYm9ydCIsIl9jcmVhdGVTdHJlYW0iLCJwYXRoIiwib3B0cyIsImZpbGVMZW5ndGgiLCJfY29udGludWVVcGxvYWQiLCJmaWxlIiwiYWJvcnRlZCIsImVuZGVkIiwiY29udFVwbGQiLCJmaW5kT25lIiwiX2NoZWNrQWNjZXNzIiwiaHR0cCIsInJlc3VsdCIsInVzZXIiLCJ1c2VySWQiLCJfZ2V0VXNlciIsInBhcmFtcyIsImNhbGwiLCJhc3NpZ24iLCJyYyIsInRleHQiLCJyZXNwb25zZSIsImhlYWRlcnNTZW50Iiwid3JpdGVIZWFkIiwibGVuZ3RoIiwiZmluaXNoZWQiLCJfbWV0aG9kTmFtZXMiLCJfQWJvcnQiLCJfV3JpdGUiLCJfU3RhcnQiLCJfUmVtb3ZlIiwib24iLCJfaGFuZGxlVXBsb2FkIiwiX2ZpbmlzaFVwbG9hZCIsIl9oYW5kbGVVcGxvYWRTeW5jIiwid3JhcEFzeW5jIiwiYmluZCIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsImh0dHBSZXEiLCJodHRwUmVzcCIsIm5leHQiLCJfcGFyc2VkVXJsIiwiaW5jbHVkZXMiLCJ0ZXN0Iiwib3JpZ2luIiwic2V0SGVhZGVyIiwibWV0aG9kIiwiaGFuZGxlRXJyb3IiLCJfZXJyb3IiLCJjb25zb2xlIiwid2FybiIsInRyYWNlIiwidG9TdHJpbmciLCJKU09OIiwic3RyaW5naWZ5IiwiYm9keSIsImhhbmRsZURhdGEiLCJyZXF1ZXN0IiwiZmlsZUlkIiwiZW9mIiwiYmluRGF0YSIsIkJ1ZmZlciIsImZyb20iLCJjaHVua0lkIiwiX3ByZXBhcmVVcGxvYWQiLCJtZXRhIiwiZW1pdCIsInBhcnNlIiwianNvbkVyciIsIm5hbWUiLCJfX19zIiwiY2xvbmUiLCJEYXRlIiwibWF4TGVuZ3RoIiwiaW5zZXJ0Iiwib21pdCIsInJldHVybk1ldGEiLCJ1cGxvYWRSb3V0ZSIsImh0dHBSZXNwRXJyIiwic2V0VGltZW91dCIsImtleXMiLCJkYXRhIiwidXJpIiwiaW5kZXhPZiIsInN1YnN0cmluZyIsInVyaXMiLCJzcGxpdCIsInF1ZXJ5IiwidmVyc2lvbiIsImRvd25sb2FkIiwiX2ZpbGUiLCJfbWV0aG9kcyIsInNlbGVjdG9yIiwidXNlckZ1bmNzIiwidXNlcnMiLCJjdXJzb3IiLCJGU05hbWUiLCJPcHRpb25hbCIsImUiLCJfb3B0cyIsInVuYmxvY2siLCJoYW5kbGVVcGxvYWRFcnIiLCJ1bmxpbmsiLCJtZXRob2RzIiwidHJhbnNwb3J0IiwiY3R4IiwiZmlsZU5hbWUiLCJfZ2V0RmlsZU5hbWUiLCJleHRlbnNpb24iLCJleHRlbnNpb25XaXRoRG90IiwiX2dldEV4dCIsImV4dCIsIl9kYXRhVG9TY2hlbWEiLCJpc1VwbG9hZEFsbG93ZWQiLCJjYiIsImNobW9kIiwiX2dldE1pbWVUeXBlIiwiX3VwZGF0ZUZpbGVUeXBlcyIsImNvbEluc2VydCIsInVwZGF0ZSIsIiRzZXQiLCJwcmVVcGRhdGVFcnJvciIsIndyaXRlIiwiZmlsZURhdGEiLCJtaW1lIiwiX2dldFVzZXJJZCIsInhtdG9rIiwic2VydmVyIiwic2Vzc2lvbnMiLCJNYXAiLCJoYXMiLCJnZXQiLCJfZ2V0VXNlckRlZmF1bHQiLCJtdG9rIiwiY29va2llIiwiYnVmZmVyIiwiX2NhbGxiYWNrIiwiX3Byb2NlZWRBZnRlclVwbG9hZCIsInByb2NlZWRBZnRlclVwbG9hZCIsImlkIiwiZW5zdXJlRmlsZSIsImVmRXJyb3IiLCJzdHJlYW0iLCJjcmVhdGVXcml0ZVN0cmVhbSIsImZsYWdzIiwic3RyZWFtRXJyIiwiaW5zZXJ0RXJyIiwibG9hZCIsInVybCIsInRpbWVvdXQiLCJwYXRoUGFydHMiLCJzdG9yZVJlc3VsdCIsImlzRW5kZWQiLCJ0aW1lciIsIndTdHJlYW0iLCJhdXRvQ2xvc2UiLCJlbWl0Q2xvc2UiLCJvbkVuZCIsImNsZWFyVGltZW91dCIsInN0YXR1cyIsInN0YXQiLCJzdGF0RXJyb3IiLCJzdGF0cyIsInZlcnNpb25zIiwib3JpZ2luYWwiLCJzdGF0dXNUZXh0IiwiZGVzdHJveWVkIiwiZGVzdHJveSIsInJlbW92ZUVycm9yIiwicmVzcCIsImNvbnRyb2xsZXIiLCJzaWduYWwiLCJ0aGVuIiwicmVzIiwicGlwZSIsImNhdGNoIiwiZmV0Y2hFcnJvciIsImFkZEZpbGUiLCJzdGF0RXJyIiwiaXNGaWxlIiwiX3N0b3JhZ2VQYXRoIiwiZmlsZXMiLCJmb3JFYWNoIiwiZG9jcyIsImRlbnkiLCJydWxlcyIsImFsbG93IiwiZGVueUNsaWVudCIsImFsbG93Q2xpZW50IiwidktleSIsIl80MDQiLCJvcmlnaW5hbFVybCIsInZSZWYiLCJyZXNwb25zZVR5cGUiLCJzZXJ2ZSIsInJlYWRhYmxlU3RyZWFtIiwiX3Jlc3BvbnNlVHlwZSIsImZvcmNlMjAwIiwicGFydGlyYWwiLCJyZXFSYW5nZSIsImRpc3Bvc2l0aW9uVHlwZSIsInN0YXJ0IiwidGFrZSIsImRpc3Bvc2l0aW9uTmFtZSIsImVuY29kZVVSSSIsImVuY29kZVVSSUNvbXBvbmVudCIsImRpc3Bvc2l0aW9uRW5jb2RpbmciLCJyYW5nZSIsImFycmF5IiwiaXNOYU4iLCJwbGF5Iiwic3RyZWFtRXJyb3JIYW5kbGVyIiwia2V5IiwicmVzcG9uZCIsImNvZGUiLCJfaXNFbmRlZCIsImNsb3NlU3RyZWFtQ2IiLCJjbG9zZUVycm9yIiwiY2xvc2VTdHJlYW0iLCJjbG9zZSIsImVyciIsImNyZWF0ZVJlYWRTdHJlYW0iLCJFdmVudEVtaXR0ZXIiLCJmb3JtYXRGbGVVUkwiLCJGaWxlc0N1cnNvciIsIkZpbGVDdXJzb3IiLCJpbmZvIiwibG9nIiwicG9wIiwidG9Mb3dlckNhc2UiLCJpc1ZpZGVvIiwiaXNBdWRpbyIsImlzSW1hZ2UiLCJpc1RleHQiLCJpc0pTT04iLCJpc1BERiIsImRzIiwiX2Rvd25sb2FkUm91dGUiLCJfY29sbGVjdGlvbk5hbWUiLCJvcHRpb25zIiwiVVJJQmFzZSIsIl9faGVscGVycyIsIm9wdGlvbmFsIiwiYmxhY2tib3giLCJ1cGRhdGVkQXQiLCJfZmlsZVJlZiIsIl9jb2xsZWN0aW9uIiwicHJvcGVydHkiLCJ3aXRoIiwiX3NlbGVjdG9yIiwiX2N1cnJlbnQiLCJoYXNOZXh0IiwiaGFzUHJldmlvdXMiLCJwcmV2aW91cyIsImZpcnN0IiwibGFzdCIsImNvbnRleHQiLCJlYWNoIiwibWFwIiwiY3VycmVudCIsImNhbGxiYWNrcyIsIm9ic2VydmVDaGFuZ2VzIiwiaXNVbmRlZmluZWQiLCJvYmoiLCJpc0FycmF5IiwiQXJyYXkiLCJwcm90b3R5cGUiLCJpc0VtcHR5IiwiaXNEYXRlIiwic2xpY2UiLCJfb2JqIiwiaGFzT3duUHJvcGVydHkiLCJpIiwiY2xlYXIiLCJub3ciLCJ0aHJvdHRsZSIsImZ1bmMiLCJ3YWl0IiwidGhhdCIsImFyZ3MiLCJsYXRlciIsImxlYWRpbmciLCJ0aHJvdHRsZWQiLCJyZW1haW5pbmciLCJ0cmFpbGluZyIsImNhbmNlbCIsIl9oZWxwZXJzIiwiX1VSSUJhc2UiLCJfX21ldGVvcl9ydW50aW1lX2NvbmZpZ19fIiwiUk9PVF9VUkwiLCJfcm9vdCIsImZkQ2FjaGUiLCJmZCIsIndyaXR0ZW5DaHVua3MiLCJvcGVuIiwib0Vycm9yIiwibnVtIiwiY2h1bmsiLCJ3cml0dGVuIiwiY2VpbCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNDLGlCQUFlLEVBQUMsTUFBSUE7QUFBckIsQ0FBZDtBQUFxRCxJQUFJQyxLQUFKO0FBQVVILE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0QsT0FBSyxDQUFDRSxDQUFELEVBQUc7QUFBQ0YsU0FBSyxHQUFDRSxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlDLEtBQUo7QUFBVU4sTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDRSxPQUFLLENBQUNELENBQUQsRUFBRztBQUFDQyxTQUFLLEdBQUNELENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsTUFBSjtBQUFXUCxNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNHLFFBQU0sQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLFVBQU0sR0FBQ0YsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJRyxNQUFKO0FBQVdSLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0ksUUFBTSxDQUFDSCxDQUFELEVBQUc7QUFBQ0csVUFBTSxHQUFDSCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlJLE1BQUo7QUFBV1QsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDSyxRQUFNLENBQUNKLENBQUQsRUFBRztBQUFDSSxVQUFNLEdBQUNKLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUssT0FBSjtBQUFZVixNQUFNLENBQUNJLElBQVAsQ0FBWSx1QkFBWixFQUFvQztBQUFDTSxTQUFPLENBQUNMLENBQUQsRUFBRztBQUFDSyxXQUFPLEdBQUNMLENBQVI7QUFBVTs7QUFBdEIsQ0FBcEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSU0sS0FBSixFQUFVQyxLQUFWO0FBQWdCWixNQUFNLENBQUNJLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNPLE9BQUssQ0FBQ04sQ0FBRCxFQUFHO0FBQUNNLFNBQUssR0FBQ04sQ0FBTjtBQUFRLEdBQWxCOztBQUFtQk8sT0FBSyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sU0FBSyxHQUFDUCxDQUFOO0FBQVE7O0FBQXBDLENBQTNCLEVBQWlFLENBQWpFO0FBQW9FLElBQUlRLFdBQUo7QUFBZ0JiLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLG1CQUFaLEVBQWdDO0FBQUNVLFNBQU8sQ0FBQ1QsQ0FBRCxFQUFHO0FBQUNRLGVBQVcsR0FBQ1IsQ0FBWjtBQUFjOztBQUExQixDQUFoQyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJVSxtQkFBSjtBQUF3QmYsTUFBTSxDQUFDSSxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDVSxTQUFPLENBQUNULENBQUQsRUFBRztBQUFDVSx1QkFBbUIsR0FBQ1YsQ0FBcEI7QUFBc0I7O0FBQWxDLENBQXhCLEVBQTRELENBQTVEO0FBQStELElBQUlXLFlBQUosRUFBaUJDLGdCQUFqQixFQUFrQ0MsT0FBbEM7QUFBMENsQixNQUFNLENBQUNJLElBQVAsQ0FBWSxVQUFaLEVBQXVCO0FBQUNZLGNBQVksQ0FBQ1gsQ0FBRCxFQUFHO0FBQUNXLGdCQUFZLEdBQUNYLENBQWI7QUFBZSxHQUFoQzs7QUFBaUNZLGtCQUFnQixDQUFDWixDQUFELEVBQUc7QUFBQ1ksb0JBQWdCLEdBQUNaLENBQWpCO0FBQW1CLEdBQXhFOztBQUF5RWEsU0FBTyxDQUFDYixDQUFELEVBQUc7QUFBQ2EsV0FBTyxHQUFDYixDQUFSO0FBQVU7O0FBQTlGLENBQXZCLEVBQXVILENBQXZIO0FBQTBILElBQUljLGVBQUo7QUFBb0JuQixNQUFNLENBQUNJLElBQVAsQ0FBWSxrQkFBWixFQUErQjtBQUFDVSxTQUFPLENBQUNULENBQUQsRUFBRztBQUFDYyxtQkFBZSxHQUFDZCxDQUFoQjtBQUFrQjs7QUFBOUIsQ0FBL0IsRUFBK0QsRUFBL0Q7QUFBbUUsSUFBSWUsRUFBSjtBQUFPcEIsTUFBTSxDQUFDSSxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDVSxTQUFPLENBQUNULENBQUQsRUFBRztBQUFDZSxNQUFFLEdBQUNmLENBQUg7QUFBSzs7QUFBakIsQ0FBdkIsRUFBMEMsRUFBMUM7QUFBOEMsSUFBSWdCLE1BQUo7QUFBV3JCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ1UsU0FBTyxDQUFDVCxDQUFELEVBQUc7QUFBQ2dCLFVBQU0sR0FBQ2hCLENBQVA7QUFBUzs7QUFBckIsQ0FBMUIsRUFBaUQsRUFBakQ7QUFBcUQsSUFBSWlCLFFBQUo7QUFBYXRCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLE1BQVosRUFBbUI7QUFBQ1UsU0FBTyxDQUFDVCxDQUFELEVBQUc7QUFBQ2lCLFlBQVEsR0FBQ2pCLENBQVQ7QUFBVzs7QUFBdkIsQ0FBbkIsRUFBNEMsRUFBNUM7O0FBaUIvaUM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNa0IsS0FBSyxHQUFHZixNQUFNLENBQUNnQixlQUFQLENBQXVCQyxRQUFRLElBQUlBLFFBQVEsRUFBM0MsQ0FBZDs7QUFDQSxNQUFNQyxJQUFJLEdBQUksTUFBTSxDQUFJLENBQXhCO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNPLE1BQU14QixlQUFOLFNBQThCYSxtQkFBOUIsQ0FBa0Q7QUFDdkRZLGFBQVcsQ0FBQ0MsTUFBRCxFQUFTO0FBQ2xCO0FBQ0EsUUFBSUMsV0FBSjs7QUFDQSxRQUFJRCxNQUFKLEVBQVk7QUFDVixPQUFDO0FBQ0NDLG1CQUREO0FBRUNDLGFBQUssRUFBRSxLQUFLQSxLQUZiO0FBR0NDLGNBQU0sRUFBRSxLQUFLQSxNQUhkO0FBSUNDLGNBQU0sRUFBRSxLQUFLQSxNQUpkO0FBS0NDLGNBQU0sRUFBRSxLQUFLQSxNQUxkO0FBTUNDLGVBQU8sRUFBRSxLQUFLQSxPQU5mO0FBT0NDLGlCQUFTLEVBQUUsS0FBS0EsU0FQakI7QUFRQ0MsaUJBQVMsRUFBRSxLQUFLQSxTQVJqQjtBQVNDQyxrQkFBVSxFQUFFLEtBQUtBLFVBVGxCO0FBVUNDLG1CQUFXLEVBQUUsS0FBS0EsV0FWbkI7QUFXQ0Msb0JBQVksRUFBRSxLQUFLQSxZQVhwQjtBQVlDQyxxQkFBYSxFQUFFLEtBQUtBLGFBWnJCO0FBYUNDLHFCQUFhLEVBQUUsS0FBS0EsYUFickI7QUFjQ0MscUJBQWEsRUFBRSxLQUFLQSxhQWRyQjtBQWVDQyxxQkFBYSxFQUFFLEtBQUtBLGFBZnJCO0FBZ0JDQyxzQkFBYyxFQUFFLEtBQUtBLGNBaEJ0QjtBQWlCQ0Msc0JBQWMsRUFBRSxLQUFLQSxjQWpCdEI7QUFrQkNDLHNCQUFjLEVBQUUsS0FBS0EsY0FsQnRCO0FBbUJDQyxzQkFBYyxFQUFFLEtBQUtBLGNBbkJ0QjtBQW9CQ0Msc0JBQWMsRUFBRSxLQUFLQSxjQXBCdEI7QUFxQkNDLHVCQUFlLEVBQUUsS0FBS0EsZUFyQnZCO0FBc0JDQyx1QkFBZSxFQUFFLEtBQUtBLGVBdEJ2QjtBQXVCQ0Msc0JBQWMsRUFBRSxLQUFLQSxjQXZCdEI7QUF3QkNDLHVCQUFlLEVBQUUsS0FBS0EsZUF4QnZCO0FBeUJDQyx3QkFBZ0IsRUFBRSxLQUFLQSxnQkF6QnhCO0FBMEJDQyx3QkFBZ0IsRUFBRSxLQUFLQSxnQkExQnhCO0FBMkJDQyx3QkFBZ0IsRUFBRSxLQUFLQSxnQkEzQnhCO0FBNEJDQyx5QkFBaUIsRUFBRSxLQUFLQSxpQkE1QnpCO0FBNkJDQyx5QkFBaUIsRUFBRSxLQUFLQSxpQkE3QnpCO0FBOEJDQyw0QkFBb0IsRUFBRSxLQUFLQSxvQkE5QjVCO0FBK0JDQywrQkFBdUIsRUFBRSxLQUFLQSx1QkEvQi9CO0FBZ0NDQyxzQkFBYyxFQUFFLEtBQUtBLGNBaEN0QjtBQWlDQ0MsMEJBQWtCLEVBQUUsS0FBS0E7QUFqQzFCLFVBa0NHakMsTUFsQ0o7QUFtQ0Q7O0FBRUQsVUFBTWtDLElBQUksR0FBRyxJQUFiOztBQUVBLFFBQUksQ0FBQzVDLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0IsS0FBS2pDLEtBQXZCLENBQUwsRUFBb0M7QUFDbEMsV0FBS0EsS0FBTCxHQUFhLEtBQWI7QUFDRDs7QUFFRCxRQUFJLENBQUNaLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0IsS0FBSy9CLE1BQXZCLENBQUwsRUFBcUM7QUFDbkMsV0FBS0EsTUFBTCxHQUFjLEtBQWQ7QUFDRDs7QUFFRCxRQUFJLENBQUMsS0FBS0ksU0FBVixFQUFxQjtBQUNuQixXQUFLQSxTQUFMLEdBQWlCLEtBQWpCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDLEtBQUtELFNBQVYsRUFBcUI7QUFDbkIsV0FBS0EsU0FBTCxHQUFpQixPQUFPLEdBQXhCO0FBQ0Q7O0FBRUQsU0FBS0EsU0FBTCxHQUFpQjZCLElBQUksQ0FBQ0MsS0FBTCxDQUFXLEtBQUs5QixTQUFMLEdBQWlCLENBQTVCLElBQWlDLENBQWxEOztBQUVBLFFBQUksQ0FBQ2pCLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUIsS0FBS3BCLGNBQXRCLENBQUQsSUFBMEMsQ0FBQyxLQUFLVCxVQUFwRCxFQUFnRTtBQUM5RCxXQUFLUyxjQUFMLEdBQXNCLG1CQUF0QjtBQUNEOztBQUVELFFBQUksQ0FBQyxLQUFLVCxVQUFWLEVBQXNCO0FBQ3BCLFdBQUtBLFVBQUwsR0FBa0IsSUFBSWxDLEtBQUssQ0FBQ2dFLFVBQVYsQ0FBcUIsS0FBS3JCLGNBQTFCLENBQWxCO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsV0FBS0EsY0FBTCxHQUFzQixLQUFLVCxVQUFMLENBQWdCK0IsS0FBdEM7QUFDRDs7QUFFRCxTQUFLL0IsVUFBTCxDQUFnQmdDLGVBQWhCLEdBQWtDLElBQWxDO0FBQ0ExRCxTQUFLLENBQUMsS0FBS21DLGNBQU4sRUFBc0J3QixNQUF0QixDQUFMOztBQUVBLFFBQUksS0FBS3RDLE1BQUwsSUFBZSxDQUFDLEtBQUtRLGFBQXpCLEVBQXdDO0FBQ3RDLFlBQU0sSUFBSWhDLE1BQU0sQ0FBQytELEtBQVgsQ0FBaUIsR0FBakIsNkJBQTBDLEtBQUt6QixjQUEvQyw2S0FBTjtBQUNEOztBQUVELFFBQUksQ0FBQzVCLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUIsS0FBSzFCLGFBQXRCLENBQUwsRUFBMkM7QUFDekMsV0FBS0EsYUFBTCxHQUFxQixjQUFyQjtBQUNEOztBQUVELFNBQUtBLGFBQUwsR0FBcUIsS0FBS0EsYUFBTCxDQUFtQmdDLE9BQW5CLENBQTJCLEtBQTNCLEVBQWtDLEVBQWxDLENBQXJCOztBQUVBLFFBQUksQ0FBQ3RELE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS3pCLGNBQXhCLENBQUwsRUFBOEM7QUFDNUMsV0FBS0EsY0FBTCxHQUFzQixLQUF0QjtBQUNEOztBQUVELFFBQUksQ0FBQzlCLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBSzFCLGNBQXhCLENBQUwsRUFBOEM7QUFDNUMsV0FBS0EsY0FBTCxHQUFzQixLQUF0QjtBQUNEOztBQUVELFFBQUksQ0FBQzdCLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS3ZDLE9BQXhCLENBQUwsRUFBdUM7QUFDckMsV0FBS0EsT0FBTCxHQUFlLEtBQWY7QUFDRDs7QUFFRCxRQUFJLENBQUNoQixPQUFPLENBQUM2QyxTQUFSLENBQWtCLEtBQUtYLGVBQXZCLENBQUwsRUFBOEM7QUFDNUMsV0FBS0EsZUFBTCxHQUF1QixJQUF2QjtBQUNEOztBQUVELFFBQUksQ0FBQ2xDLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS25CLGdCQUF4QixDQUFMLEVBQWdEO0FBQzlDLFdBQUtBLGdCQUFMLEdBQXdCLEtBQXhCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDcEMsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLbEIsZ0JBQXhCLENBQUwsRUFBZ0Q7QUFDOUMsV0FBS0EsZ0JBQUwsR0FBd0IsS0FBeEI7QUFDRDs7QUFFRCxRQUFJLENBQUNyQyxPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUtqQixpQkFBeEIsQ0FBTCxFQUFpRDtBQUMvQyxXQUFLQSxpQkFBTCxHQUF5QixLQUF6QjtBQUNEOztBQUVELFFBQUksQ0FBQ3RDLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0IsS0FBSzlCLE1BQXZCLENBQUwsRUFBcUM7QUFDbkMsV0FBS0EsTUFBTCxHQUFjLElBQWQ7QUFDRDs7QUFFRCxRQUFJLENBQUNmLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0IsS0FBS0osdUJBQXZCLENBQUwsRUFBc0Q7QUFDcEQsV0FBS0EsdUJBQUwsR0FBK0IsS0FBL0I7QUFDRDs7QUFFRCxRQUFJLENBQUN6QyxPQUFPLENBQUN3RCxRQUFSLENBQWlCLEtBQUtwQyxXQUF0QixDQUFMLEVBQXlDO0FBQ3ZDLFdBQUtBLFdBQUwsR0FBbUJxQyxRQUFRLENBQUMsS0FBRCxFQUFRLENBQVIsQ0FBM0I7QUFDRDs7QUFFRCxRQUFJLENBQUN6RCxPQUFPLENBQUN3RCxRQUFSLENBQWlCLEtBQUtoQixvQkFBdEIsQ0FBTCxFQUFrRDtBQUNoRCxXQUFLQSxvQkFBTCxHQUE0QmlCLFFBQVEsQ0FBQyxLQUFELEVBQVEsQ0FBUixDQUFwQztBQUNEOztBQUVELFFBQUksQ0FBQ3pELE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUIsS0FBSzNCLFlBQXRCLENBQUwsRUFBMEM7QUFDeEMsV0FBS0EsWUFBTCxHQUFvQiw2Q0FBcEI7QUFDRDs7QUFFRCxRQUFJLENBQUNyQixPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUtoQyxhQUF4QixDQUFMLEVBQTZDO0FBQzNDLFdBQUtBLGFBQUwsR0FBcUIsS0FBckI7QUFDRDs7QUFFRCxRQUFJLENBQUN2QixPQUFPLENBQUM2QyxTQUFSLENBQWtCLEtBQUtwQixhQUF2QixDQUFMLEVBQTRDO0FBQzFDLFdBQUtBLGFBQUwsR0FBcUIsS0FBckI7QUFDRDs7QUFFRCxRQUFJLENBQUN6QixPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUsvQixhQUF4QixDQUFMLEVBQTZDO0FBQzNDLFdBQUtBLGFBQUwsR0FBcUIsS0FBckI7QUFDRDs7QUFFRCxRQUFJLENBQUN4QixPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUs3QixjQUF4QixDQUFMLEVBQThDO0FBQzVDLFdBQUtBLGNBQUwsR0FBc0IsS0FBdEI7QUFDRDs7QUFFRCxRQUFJLENBQUMxQixPQUFPLENBQUM2QyxTQUFSLENBQWtCLEtBQUtsQixjQUF2QixDQUFMLEVBQTZDO0FBQzNDLFdBQUtBLGNBQUwsR0FBc0IsSUFBdEI7QUFDRDs7QUFFRCxRQUFJLENBQUMzQixPQUFPLENBQUM2QyxTQUFSLENBQWtCLEtBQUtiLGVBQXZCLENBQUwsRUFBOEM7QUFDNUMsV0FBS0EsZUFBTCxHQUF1QixLQUF2QjtBQUNEOztBQUVELFFBQUksQ0FBQ2hDLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0IsS0FBS1osY0FBdkIsQ0FBRCxJQUEyQyxLQUFLQSxjQUFMLEtBQXdCLElBQXZFLEVBQTZFO0FBQzNFLFdBQUtBLGNBQUwsR0FBc0IsaUNBQXRCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDakMsT0FBTyxDQUFDMEQsUUFBUixDQUFpQixLQUFLQyxlQUF0QixDQUFMLEVBQTZDO0FBQzNDLFdBQUtBLGVBQUwsR0FBdUIsRUFBdkI7QUFDRDs7QUFFRCxRQUFJLENBQUMzRCxPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUtwQixnQkFBeEIsQ0FBTCxFQUFnRDtBQUM5QyxXQUFLQSxnQkFBTCxHQUF3QixLQUF4QjtBQUNEOztBQUVELFFBQUksQ0FBQ25DLE9BQU8sQ0FBQ3dELFFBQVIsQ0FBaUIsS0FBS2pCLGlCQUF0QixDQUFMLEVBQStDO0FBQzdDLFdBQUtBLGlCQUFMLEdBQXlCLEtBQXpCO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDdkMsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLeEIsZUFBeEIsQ0FBTCxFQUErQztBQUM3QyxXQUFLQSxlQUFMLEdBQXVCLENBQUM2QixZQUFELEVBQWVDLE9BQWYsRUFBd0JDLFVBQXhCLEtBQXVDO0FBQzVELGNBQU1DLE9BQU8sR0FBRyxFQUFoQjs7QUFDQSxnQkFBUUgsWUFBUjtBQUNBLGVBQUssS0FBTDtBQUNFRyxtQkFBTyxDQUFDQyxNQUFSLEdBQStCLFNBQS9CO0FBQ0FELG1CQUFPLENBQUMsbUJBQUQsQ0FBUCxHQUErQixTQUEvQjtBQUNBOztBQUNGLGVBQUssS0FBTDtBQUNFQSxtQkFBTyxDQUFDLGVBQUQsQ0FBUCxHQUErQixVQUEvQjtBQUNBOztBQUNGLGVBQUssS0FBTDtBQUNFQSxtQkFBTyxDQUFDLGVBQUQsQ0FBUCxxQkFBMENELFVBQVUsQ0FBQ0csSUFBckQ7QUFDQTs7QUFDRjtBQUNFO0FBWkY7O0FBZUFGLGVBQU8sQ0FBQ0csVUFBUixHQUEyQixZQUEzQjtBQUNBSCxlQUFPLENBQUMsY0FBRCxDQUFQLEdBQTJCRCxVQUFVLENBQUNLLElBQVgsSUFBbUIsMEJBQTlDO0FBQ0FKLGVBQU8sQ0FBQyxlQUFELENBQVAsR0FBMkIsT0FBM0I7QUFDQSxlQUFPQSxPQUFQO0FBQ0QsT0FyQkQ7QUFzQkQ7O0FBRUQsUUFBSSxLQUFLakQsTUFBTCxJQUFlLENBQUNILFdBQXBCLEVBQWlDO0FBQy9CLFlBQU0sSUFBSXJCLE1BQU0sQ0FBQytELEtBQVgsQ0FBaUIsR0FBakIsNkJBQTBDLEtBQUt6QixjQUEvQyx5SkFBTjtBQUNEOztBQUVELFFBQUksQ0FBQ2pCLFdBQUwsRUFBa0I7QUFDaEJBLGlCQUFXLEdBQUcsWUFBWTtBQUN4QiwrQkFBZ0JQLFFBQVEsQ0FBQ2dFLEdBQXpCLGdCQUFrQ2hFLFFBQVEsQ0FBQ2dFLEdBQTNDLG9CQUF3RGhFLFFBQVEsQ0FBQ2dFLEdBQWpFLFNBQXVFeEIsSUFBSSxDQUFDaEIsY0FBNUU7QUFDRCxPQUZEO0FBR0Q7O0FBRUQsUUFBSTVCLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUJyQyxXQUFqQixDQUFKLEVBQW1DO0FBQ2pDLFdBQUtBLFdBQUwsR0FBbUIsTUFBTUEsV0FBekI7QUFDRCxLQUZELE1BRU87QUFDTCxXQUFLQSxXQUFMLEdBQW1CLFlBQVk7QUFDN0IsWUFBSTBELEVBQUUsR0FBRzFELFdBQVcsQ0FBQzJELEtBQVosQ0FBa0IxQixJQUFsQixFQUF3QjJCLFNBQXhCLENBQVQ7O0FBQ0EsWUFBSSxDQUFDdkUsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQnFCLEVBQWpCLENBQUwsRUFBMkI7QUFDekIsZ0JBQU0sSUFBSS9FLE1BQU0sQ0FBQytELEtBQVgsQ0FBaUIsR0FBakIsNkJBQTBDVCxJQUFJLENBQUNoQixjQUEvQyxzREFBTjtBQUNEOztBQUNEeUMsVUFBRSxHQUFHQSxFQUFFLENBQUNmLE9BQUgsQ0FBVyxLQUFYLEVBQWtCLEVBQWxCLENBQUw7QUFDQSxlQUFPbEQsUUFBUSxDQUFDb0UsU0FBVCxDQUFtQkgsRUFBbkIsQ0FBUDtBQUNELE9BUEQ7QUFRRDs7QUFFRCxTQUFLSSxNQUFMLENBQVksdUNBQVosRUFBcUQsS0FBSzlELFdBQUwsQ0FBaUIsRUFBakIsQ0FBckQ7O0FBRUFULE1BQUUsQ0FBQ3dFLE1BQUgsQ0FBVSxLQUFLL0QsV0FBTCxDQUFpQixFQUFqQixDQUFWLEVBQWdDO0FBQUVnRSxVQUFJLEVBQUUsS0FBS25DO0FBQWIsS0FBaEMsRUFBc0VvQyxLQUFELElBQVc7QUFDOUUsVUFBSUEsS0FBSixFQUFXO0FBQ1QsY0FBTSxJQUFJdEYsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQiw2QkFBMENULElBQUksQ0FBQ2hCLGNBQS9DLHNCQUF3RSxLQUFLakIsV0FBTCxDQUFpQixFQUFqQixDQUF4RSxpQ0FBa0hpRSxLQUFsSCxFQUFOO0FBQ0Q7QUFDRixLQUpEO0FBTUFuRixTQUFLLENBQUMsS0FBS3NCLE1BQU4sRUFBYzhELE9BQWQsQ0FBTDtBQUNBcEYsU0FBSyxDQUFDLEtBQUsyQixXQUFOLEVBQW1CMEQsTUFBbkIsQ0FBTDtBQUNBckYsU0FBSyxDQUFDLEtBQUtrQixXQUFOLEVBQW1Cb0UsUUFBbkIsQ0FBTDtBQUNBdEYsU0FBSyxDQUFDLEtBQUs0QixZQUFOLEVBQW9CK0IsTUFBcEIsQ0FBTDtBQUNBM0QsU0FBSyxDQUFDLEtBQUsrQixhQUFOLEVBQXFCOUIsS0FBSyxDQUFDc0YsS0FBTixDQUFZLEtBQVosRUFBbUJELFFBQW5CLENBQXJCLENBQUw7QUFDQXRGLFNBQUssQ0FBQyxLQUFLOEIsYUFBTixFQUFxQjdCLEtBQUssQ0FBQ3NGLEtBQU4sQ0FBWSxLQUFaLEVBQW1CRCxRQUFuQixDQUFyQixDQUFMO0FBQ0F0RixTQUFLLENBQUMsS0FBS2dDLGFBQU4sRUFBcUJvRCxPQUFyQixDQUFMO0FBQ0FwRixTQUFLLENBQUMsS0FBS2tDLGNBQU4sRUFBc0JrRCxPQUF0QixDQUFMO0FBQ0FwRixTQUFLLENBQUMsS0FBS2lDLGNBQU4sRUFBc0JoQyxLQUFLLENBQUNzRixLQUFOLENBQVksS0FBWixFQUFtQkQsUUFBbkIsQ0FBdEIsQ0FBTDtBQUNBdEYsU0FBSyxDQUFDLEtBQUt1QyxlQUFOLEVBQXVCNkMsT0FBdkIsQ0FBTDtBQUNBcEYsU0FBSyxDQUFDLEtBQUswQyxnQkFBTixFQUF3QnpDLEtBQUssQ0FBQ3NGLEtBQU4sQ0FBWSxLQUFaLEVBQW1CRCxRQUFuQixDQUF4QixDQUFMO0FBQ0F0RixTQUFLLENBQUMsS0FBSzRDLGdCQUFOLEVBQXdCM0MsS0FBSyxDQUFDc0YsS0FBTixDQUFZLEtBQVosRUFBbUJELFFBQW5CLENBQXhCLENBQUw7QUFDQXRGLFNBQUssQ0FBQyxLQUFLNkMsaUJBQU4sRUFBeUI1QyxLQUFLLENBQUNzRixLQUFOLENBQVksS0FBWixFQUFtQkQsUUFBbkIsQ0FBekIsQ0FBTDtBQUNBdEYsU0FBSyxDQUFDLEtBQUs4QyxpQkFBTixFQUF5QnVDLE1BQXpCLENBQUw7QUFDQXJGLFNBQUssQ0FBQyxLQUFLc0MsZUFBTixFQUF1QnJDLEtBQUssQ0FBQ3NGLEtBQU4sQ0FBWUMsTUFBWixFQUFvQkYsUUFBcEIsQ0FBdkIsQ0FBTDtBQUNBdEYsU0FBSyxDQUFDLEtBQUtnRCx1QkFBTixFQUErQm9DLE9BQS9CLENBQUw7QUFFQSxRQUFJckYsT0FBSixDQUFZO0FBQ1ZpRCw2QkFBdUIsRUFBRSxLQUFLQSx1QkFEcEI7QUFFVnlDLDJCQUFxQixFQUFFLEtBQUtqRDtBQUZsQixLQUFaOztBQUtBLFFBQUksQ0FBQyxLQUFLUixhQUFWLEVBQXlCO0FBQ3ZCLFVBQUksQ0FBQ3pCLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUIsS0FBS0wsa0JBQXRCLENBQUQsSUFBOEMsQ0FBQyxLQUFLRCxjQUF4RCxFQUF3RTtBQUN0RSxhQUFLQyxrQkFBTCxtQkFBbUMsS0FBS2YsY0FBeEM7QUFDRDs7QUFFRCxVQUFJLENBQUMsS0FBS2MsY0FBVixFQUEwQjtBQUN4QixhQUFLQSxjQUFMLEdBQXNCLElBQUl6RCxLQUFLLENBQUNnRSxVQUFWLENBQXFCLEtBQUtOLGtCQUExQixDQUF0QjtBQUNELE9BRkQsTUFFTztBQUNMLGFBQUtBLGtCQUFMLEdBQTBCLEtBQUtELGNBQUwsQ0FBb0JRLEtBQTlDO0FBQ0Q7O0FBQ0R6RCxXQUFLLENBQUMsS0FBS2tELGtCQUFOLEVBQTBCUyxNQUExQixDQUFMOztBQUVBLFdBQUtWLGNBQUwsQ0FBb0J5QyxZQUFwQixDQUFpQztBQUFFQyxpQkFBUyxFQUFFO0FBQWIsT0FBakMsRUFBbUQ7QUFBRUMsMEJBQWtCLEVBQUUsS0FBSzlDLGlCQUEzQjtBQUE4QytDLGtCQUFVLEVBQUU7QUFBMUQsT0FBbkQ7O0FBQ0EsWUFBTUMsb0JBQW9CLEdBQUcsS0FBSzdDLGNBQUwsQ0FBb0I4QyxJQUFwQixDQUF5QixFQUF6QixFQUE2QjtBQUN4REMsY0FBTSxFQUFFO0FBQ05DLGFBQUcsRUFBRSxDQURDO0FBRU5DLG9CQUFVLEVBQUU7QUFGTjtBQURnRCxPQUE3QixDQUE3Qjs7QUFPQUosMEJBQW9CLENBQUNLLE9BQXJCLENBQTZCO0FBQzNCQyxlQUFPLENBQUNDLEdBQUQsRUFBTTtBQUNYLGNBQUlBLEdBQUcsQ0FBQ0gsVUFBUixFQUFvQjtBQUNsQi9DLGdCQUFJLENBQUM2QixNQUFMLHVFQUEyRXFCLEdBQUcsQ0FBQ0osR0FBL0U7O0FBQ0E5QyxnQkFBSSxDQUFDRixjQUFMLENBQW9CcUQsTUFBcEIsQ0FBMkI7QUFBQ0wsaUJBQUcsRUFBRUksR0FBRyxDQUFDSjtBQUFWLGFBQTNCLEVBQTJDbEYsSUFBM0M7QUFDRDtBQUNGLFNBTjBCOztBQU8zQndGLGVBQU8sQ0FBQ0YsR0FBRCxFQUFNO0FBQ1g7QUFDQTtBQUNBbEQsY0FBSSxDQUFDNkIsTUFBTCx1RUFBMkVxQixHQUFHLENBQUNKLEdBQS9FOztBQUNBLGNBQUkxRixPQUFPLENBQUMwRCxRQUFSLENBQWlCZCxJQUFJLENBQUNlLGVBQUwsQ0FBcUJtQyxHQUFHLENBQUNKLEdBQXpCLENBQWpCLENBQUosRUFBcUQ7QUFDbkQ5QyxnQkFBSSxDQUFDZSxlQUFMLENBQXFCbUMsR0FBRyxDQUFDSixHQUF6QixFQUE4Qk8sSUFBOUI7O0FBQ0FyRCxnQkFBSSxDQUFDZSxlQUFMLENBQXFCbUMsR0FBRyxDQUFDSixHQUF6QixFQUE4QlEsR0FBOUIsR0FGbUQsQ0FJbkQ7QUFDQTs7O0FBQ0EsZ0JBQUksQ0FBQ0osR0FBRyxDQUFDSCxVQUFMLElBQW1CL0MsSUFBSSxDQUFDekIsVUFBTCxDQUFnQnFFLElBQWhCLENBQXFCO0FBQUVFLGlCQUFHLEVBQUVJLEdBQUcsQ0FBQ0o7QUFBWCxhQUFyQixFQUF1Q1MsS0FBdkMsT0FBbUQsQ0FBMUUsRUFBNkU7QUFDM0V2RCxrQkFBSSxDQUFDNkIsTUFBTCxzRkFBMEZxQixHQUFHLENBQUNKLEdBQTlGOztBQUNBOUMsa0JBQUksQ0FBQ2UsZUFBTCxDQUFxQm1DLEdBQUcsQ0FBQ0osR0FBekIsRUFBOEJVLEtBQTlCO0FBQ0Q7O0FBRUQsbUJBQU94RCxJQUFJLENBQUNlLGVBQUwsQ0FBcUJtQyxHQUFHLENBQUNKLEdBQXpCLENBQVA7QUFDRDtBQUNGOztBQXhCMEIsT0FBN0I7O0FBMkJBLFdBQUtXLGFBQUwsR0FBcUIsQ0FBQ1gsR0FBRCxFQUFNWSxJQUFOLEVBQVlDLElBQVosS0FBcUI7QUFDeEMsYUFBSzVDLGVBQUwsQ0FBcUIrQixHQUFyQixJQUE0QixJQUFJL0YsV0FBSixDQUFnQjJHLElBQWhCLEVBQXNCQyxJQUFJLENBQUNDLFVBQTNCLEVBQXVDRCxJQUF2QyxFQUE2QyxLQUFLbkYsV0FBbEQsQ0FBNUI7QUFDRCxPQUZELENBL0N1QixDQW1EdkI7QUFDQTs7O0FBQ0EsV0FBS3FGLGVBQUwsR0FBd0JmLEdBQUQsSUFBUztBQUM5QixZQUFJLEtBQUsvQixlQUFMLENBQXFCK0IsR0FBckIsS0FBNkIsS0FBSy9CLGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQmdCLElBQTNELEVBQWlFO0FBQy9ELGNBQUksQ0FBQyxLQUFLL0MsZUFBTCxDQUFxQitCLEdBQXJCLEVBQTBCaUIsT0FBM0IsSUFBc0MsQ0FBQyxLQUFLaEQsZUFBTCxDQUFxQitCLEdBQXJCLEVBQTBCa0IsS0FBckUsRUFBNEU7QUFDMUUsbUJBQU8sS0FBS2pELGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQmdCLElBQWpDO0FBQ0Q7O0FBQ0QsZUFBS0wsYUFBTCxDQUFtQlgsR0FBbkIsRUFBd0IsS0FBSy9CLGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQmdCLElBQTFCLENBQStCQSxJQUEvQixDQUFvQ0osSUFBNUQsRUFBa0UsS0FBSzNDLGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQmdCLElBQTVGOztBQUNBLGlCQUFPLEtBQUsvQyxlQUFMLENBQXFCK0IsR0FBckIsRUFBMEJnQixJQUFqQztBQUNEOztBQUNELGNBQU1HLFFBQVEsR0FBRyxLQUFLbkUsY0FBTCxDQUFvQm9FLE9BQXBCLENBQTRCO0FBQUNwQjtBQUFELFNBQTVCLENBQWpCOztBQUNBLFlBQUltQixRQUFKLEVBQWM7QUFDWixlQUFLUixhQUFMLENBQW1CWCxHQUFuQixFQUF3Qm1CLFFBQVEsQ0FBQ0gsSUFBVCxDQUFjSixJQUF0QyxFQUE0Q08sUUFBNUM7O0FBQ0EsaUJBQU8sS0FBS2xELGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQmdCLElBQWpDO0FBQ0Q7O0FBQ0QsZUFBTyxLQUFQO0FBQ0QsT0FkRDtBQWVEOztBQUVELFFBQUksQ0FBQyxLQUFLN0YsTUFBVixFQUFrQjtBQUNoQixXQUFLQSxNQUFMLEdBQWNoQixtQkFBbUIsQ0FBQ2dCLE1BQWxDO0FBQ0Q7O0FBRURwQixTQUFLLENBQUMsS0FBS21CLEtBQU4sRUFBYWlFLE9BQWIsQ0FBTDtBQUNBcEYsU0FBSyxDQUFDLEtBQUtvQixNQUFOLEVBQWNvRSxNQUFkLENBQUw7QUFDQXhGLFNBQUssQ0FBQyxLQUFLcUIsTUFBTixFQUFjK0QsT0FBZCxDQUFMO0FBQ0FwRixTQUFLLENBQUMsS0FBS3VCLE9BQU4sRUFBZXRCLEtBQUssQ0FBQ3NGLEtBQU4sQ0FBWSxLQUFaLEVBQW1CRCxRQUFuQixDQUFmLENBQUw7QUFDQXRGLFNBQUssQ0FBQyxLQUFLeUIsU0FBTixFQUFpQnhCLEtBQUssQ0FBQ3NGLEtBQU4sQ0FBWUgsT0FBWixFQUFxQkUsUUFBckIsQ0FBakIsQ0FBTDtBQUNBdEYsU0FBSyxDQUFDLEtBQUt3QixTQUFOLEVBQWlCNkQsTUFBakIsQ0FBTDtBQUNBckYsU0FBSyxDQUFDLEtBQUs2QixhQUFOLEVBQXFCOEIsTUFBckIsQ0FBTDtBQUNBM0QsU0FBSyxDQUFDLEtBQUtxQyxjQUFOLEVBQXNCcEMsS0FBSyxDQUFDc0YsS0FBTixDQUFZLEtBQVosRUFBbUJELFFBQW5CLENBQXRCLENBQUw7QUFDQXRGLFNBQUssQ0FBQyxLQUFLb0MsY0FBTixFQUFzQm5DLEtBQUssQ0FBQ3NGLEtBQU4sQ0FBWSxLQUFaLEVBQW1CRCxRQUFuQixDQUF0QixDQUFMO0FBQ0F0RixTQUFLLENBQUMsS0FBSzJDLGdCQUFOLEVBQXdCMUMsS0FBSyxDQUFDc0YsS0FBTixDQUFZLEtBQVosRUFBbUJELFFBQW5CLENBQXhCLENBQUw7QUFDQXRGLFNBQUssQ0FBQyxLQUFLeUMsZUFBTixFQUF1QjJDLE9BQXZCLENBQUw7O0FBRUEsUUFBSSxLQUFLL0QsTUFBTCxJQUFlLEtBQUtJLFNBQXhCLEVBQW1DO0FBQ2pDLFlBQU0sSUFBSTVCLE1BQU0sQ0FBQytELEtBQVgsQ0FBaUIsR0FBakIsNkJBQTBDLEtBQUt6QixjQUEvQyxnRUFBTjtBQUNEOztBQUVELFNBQUttRixZQUFMLEdBQXFCQyxJQUFELElBQVU7QUFDNUIsVUFBSSxLQUFLOUYsU0FBVCxFQUFvQjtBQUNsQixZQUFJK0YsTUFBSjs7QUFDQSxjQUFNO0FBQUNDLGNBQUQ7QUFBT0M7QUFBUCxZQUFpQixLQUFLQyxRQUFMLENBQWNKLElBQWQsQ0FBdkI7O0FBRUEsWUFBSWhILE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS3JDLFNBQXhCLENBQUosRUFBd0M7QUFDdEMsY0FBSTJDLE9BQUo7O0FBQ0EsY0FBSTdELE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJzRCxJQUFJLENBQUNLLE1BQXRCLEtBQWtDTCxJQUFJLENBQUNLLE1BQUwsQ0FBWTNCLEdBQWxELEVBQXVEO0FBQ3JEN0IsbUJBQU8sR0FBRyxLQUFLMUMsVUFBTCxDQUFnQjJGLE9BQWhCLENBQXdCRSxJQUFJLENBQUNLLE1BQUwsQ0FBWTNCLEdBQXBDLENBQVY7QUFDRDs7QUFFRHVCLGdCQUFNLEdBQUdELElBQUksR0FBRyxLQUFLOUYsU0FBTCxDQUFlb0csSUFBZixDQUFvQnJDLE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBY1AsSUFBZCxFQUFvQjtBQUFDRSxnQkFBRDtBQUFPQztBQUFQLFdBQXBCLENBQXBCLEVBQTBEdEQsT0FBTyxJQUFJLElBQXJFLENBQUgsR0FBaUYsS0FBSzNDLFNBQUwsQ0FBZW9HLElBQWYsQ0FBb0I7QUFBQ0osZ0JBQUQ7QUFBT0M7QUFBUCxXQUFwQixFQUFxQ3RELE9BQU8sSUFBSSxJQUFoRCxDQUE5RjtBQUNELFNBUEQsTUFPTztBQUNMb0QsZ0JBQU0sR0FBRyxDQUFDLENBQUNFLE1BQVg7QUFDRDs7QUFFRCxZQUFLSCxJQUFJLElBQUtDLE1BQU0sS0FBSyxJQUFyQixJQUErQixDQUFDRCxJQUFwQyxFQUEwQztBQUN4QyxpQkFBTyxJQUFQO0FBQ0Q7O0FBRUQsY0FBTVEsRUFBRSxHQUFHeEgsT0FBTyxDQUFDd0QsUUFBUixDQUFpQnlELE1BQWpCLElBQTJCQSxNQUEzQixHQUFvQyxHQUEvQzs7QUFDQSxhQUFLeEMsTUFBTCxDQUFZLHFEQUFaOztBQUNBLFlBQUl1QyxJQUFKLEVBQVU7QUFDUixnQkFBTVMsSUFBSSxHQUFHLGdCQUFiOztBQUNBLGNBQUksQ0FBQ1QsSUFBSSxDQUFDVSxRQUFMLENBQWNDLFdBQW5CLEVBQWdDO0FBQzlCWCxnQkFBSSxDQUFDVSxRQUFMLENBQWNFLFNBQWQsQ0FBd0JKLEVBQXhCLEVBQTRCO0FBQzFCLDhCQUFnQixZQURVO0FBRTFCLGdDQUFrQkMsSUFBSSxDQUFDSTtBQUZHLGFBQTVCO0FBSUQ7O0FBRUQsY0FBSSxDQUFDYixJQUFJLENBQUNVLFFBQUwsQ0FBY0ksUUFBbkIsRUFBNkI7QUFDM0JkLGdCQUFJLENBQUNVLFFBQUwsQ0FBY3hCLEdBQWQsQ0FBa0J1QixJQUFsQjtBQUNEO0FBQ0Y7O0FBRUQsZUFBTyxLQUFQO0FBQ0Q7O0FBQ0QsYUFBTyxJQUFQO0FBQ0QsS0F2Q0Q7O0FBeUNBLFNBQUtNLFlBQUwsR0FBb0I7QUFDbEJDLFlBQU0sa0NBQTJCLEtBQUtwRyxjQUFoQyxDQURZO0FBRWxCcUcsWUFBTSxrQ0FBMkIsS0FBS3JHLGNBQWhDLENBRlk7QUFHbEJzRyxZQUFNLGtDQUEyQixLQUFLdEcsY0FBaEMsQ0FIWTtBQUlsQnVHLGFBQU8sbUNBQTRCLEtBQUt2RyxjQUFqQztBQUpXLEtBQXBCO0FBT0EsU0FBS3dHLEVBQUwsQ0FBUSxlQUFSLEVBQXlCLEtBQUtDLGFBQTlCO0FBQ0EsU0FBS0QsRUFBTCxDQUFRLGVBQVIsRUFBeUIsS0FBS0UsYUFBOUI7QUFDQSxTQUFLQyxpQkFBTCxHQUF5QmpKLE1BQU0sQ0FBQ2tKLFNBQVAsQ0FBaUIsS0FBS0gsYUFBTCxDQUFtQkksSUFBbkIsQ0FBd0IsSUFBeEIsQ0FBakIsQ0FBekI7O0FBRUEsUUFBSSxLQUFLaEgsYUFBTCxJQUFzQixLQUFLTyxlQUEvQixFQUFnRDtBQUM5QztBQUNEOztBQUNEM0MsVUFBTSxDQUFDcUosZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkIsQ0FBQ0MsT0FBRCxFQUFVQyxRQUFWLEVBQW9CQyxJQUFwQixLQUE2QjtBQUN0RCxVQUFJLEtBQUs3RyxjQUFMLElBQXVCMkcsT0FBTyxDQUFDRyxVQUFSLENBQW1CekMsSUFBbkIsQ0FBd0IwQyxRQUF4QixXQUFvQyxLQUFLMUgsYUFBekMsT0FBdkIsSUFBcUYsQ0FBQ3VILFFBQVEsQ0FBQ2xCLFdBQW5HLEVBQWdIO0FBQzlHLFlBQUksS0FBSzFGLGNBQUwsQ0FBb0JnSCxJQUFwQixDQUF5QkwsT0FBTyxDQUFDN0UsT0FBUixDQUFnQm1GLE1BQXpDLENBQUosRUFBc0Q7QUFDcERMLGtCQUFRLENBQUNNLFNBQVQsQ0FBbUIsa0NBQW5CLEVBQXVELE1BQXZEO0FBQ0FOLGtCQUFRLENBQUNNLFNBQVQsQ0FBbUIsNkJBQW5CLEVBQWtEUCxPQUFPLENBQUM3RSxPQUFSLENBQWdCbUYsTUFBbEU7QUFDRDs7QUFFRCxZQUFJTixPQUFPLENBQUNRLE1BQVIsS0FBbUIsU0FBdkIsRUFBa0M7QUFDaENQLGtCQUFRLENBQUNNLFNBQVQsQ0FBbUIsOEJBQW5CLEVBQW1ELG9CQUFuRDtBQUNBTixrQkFBUSxDQUFDTSxTQUFULENBQW1CLDhCQUFuQixFQUFtRCxrRUFBbkQ7QUFDQU4sa0JBQVEsQ0FBQ00sU0FBVCxDQUFtQiwrQkFBbkIsRUFBb0QsZ0VBQXBEO0FBQ0FOLGtCQUFRLENBQUNNLFNBQVQsQ0FBbUIsT0FBbkIsRUFBNEIsb0JBQTVCO0FBQ0FOLGtCQUFRLENBQUNqQixTQUFULENBQW1CLEdBQW5CO0FBQ0FpQixrQkFBUSxDQUFDM0MsR0FBVDtBQUNBO0FBQ0Q7QUFDRjs7QUFFRCxVQUFJLENBQUMsS0FBS3pFLGFBQU4sSUFBdUJtSCxPQUFPLENBQUNHLFVBQVIsQ0FBbUJ6QyxJQUFuQixDQUF3QjBDLFFBQXhCLFdBQW9DLEtBQUsxSCxhQUF6QyxjQUEwRCxLQUFLTSxjQUEvRCxlQUEzQixFQUFzSDtBQUNwSCxZQUFJZ0gsT0FBTyxDQUFDUSxNQUFSLEtBQW1CLE1BQXZCLEVBQStCO0FBQzdCTixjQUFJO0FBQ0o7QUFDRDs7QUFFRCxjQUFNTyxXQUFXLEdBQUlDLE1BQUQsSUFBWTtBQUM5QixjQUFJMUUsS0FBSyxHQUFHMEUsTUFBWjtBQUNBQyxpQkFBTyxDQUFDQyxJQUFSLENBQWEsOENBQWIsRUFBNkQ1RSxLQUE3RDtBQUNBMkUsaUJBQU8sQ0FBQ0UsS0FBUjs7QUFFQSxjQUFJLENBQUNaLFFBQVEsQ0FBQ2xCLFdBQWQsRUFBMkI7QUFDekJrQixvQkFBUSxDQUFDakIsU0FBVCxDQUFtQixHQUFuQjtBQUNEOztBQUVELGNBQUksQ0FBQ2lCLFFBQVEsQ0FBQ2YsUUFBZCxFQUF3QjtBQUN0QixnQkFBSTlILE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJrQixLQUFqQixLQUEyQjVFLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUJxQixLQUFLLENBQUM4RSxRQUF6QixDQUEvQixFQUFtRTtBQUNqRTlFLG1CQUFLLEdBQUdBLEtBQUssQ0FBQzhFLFFBQU4sRUFBUjtBQUNEOztBQUVELGdCQUFJLENBQUMxSixPQUFPLENBQUNnRCxRQUFSLENBQWlCNEIsS0FBakIsQ0FBTCxFQUE4QjtBQUM1QkEsbUJBQUssR0FBRyxtQkFBUjtBQUNEOztBQUVEaUUsb0JBQVEsQ0FBQzNDLEdBQVQsQ0FBYXlELElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQUVoRjtBQUFGLGFBQWYsQ0FBYjtBQUNEO0FBQ0YsU0FwQkQ7O0FBc0JBLFlBQUlpRixJQUFJLEdBQUcsRUFBWDs7QUFDQSxjQUFNQyxVQUFVLEdBQUcsTUFBTTtBQUN2QixjQUFJO0FBQ0YsZ0JBQUl2RCxJQUFKO0FBQ0EsZ0JBQUlVLE1BQUo7O0FBQ0EsZ0JBQUlDLElBQUksR0FBRyxLQUFLRSxRQUFMLENBQWM7QUFBQzJDLHFCQUFPLEVBQUVuQixPQUFWO0FBQW1CbEIsc0JBQVEsRUFBRW1CO0FBQTdCLGFBQWQsQ0FBWDs7QUFFQSxnQkFBSUQsT0FBTyxDQUFDN0UsT0FBUixDQUFnQixTQUFoQixNQUErQixHQUFuQyxFQUF3QztBQUN0QztBQUNBd0Msa0JBQUksR0FBRztBQUNMeUQsc0JBQU0sRUFBRXBCLE9BQU8sQ0FBQzdFLE9BQVIsQ0FBZ0IsVUFBaEI7QUFESCxlQUFQOztBQUlBLGtCQUFJNkUsT0FBTyxDQUFDN0UsT0FBUixDQUFnQixPQUFoQixNQUE2QixHQUFqQyxFQUFzQztBQUNwQ3dDLG9CQUFJLENBQUMwRCxHQUFMLEdBQVcsSUFBWDtBQUNELGVBRkQsTUFFTztBQUNMMUQsb0JBQUksQ0FBQzJELE9BQUwsR0FBZUMsTUFBTSxDQUFDQyxJQUFQLENBQVlQLElBQVosRUFBa0IsUUFBbEIsQ0FBZjtBQUNBdEQsb0JBQUksQ0FBQzhELE9BQUwsR0FBZTVHLFFBQVEsQ0FBQ21GLE9BQU8sQ0FBQzdFLE9BQVIsQ0FBZ0IsV0FBaEIsQ0FBRCxDQUF2QjtBQUNEOztBQUVELG9CQUFNMEMsZUFBZSxHQUFHLEtBQUtBLGVBQUwsQ0FBcUJGLElBQUksQ0FBQ3lELE1BQTFCLENBQXhCOztBQUNBLGtCQUFJLENBQUN2RCxlQUFMLEVBQXNCO0FBQ3BCLHNCQUFNLElBQUluSCxNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLDhEQUF0QixDQUFOO0FBQ0Q7O0FBRUQsZUFBQztBQUFDNEQsc0JBQUQ7QUFBU1Y7QUFBVCxrQkFBa0IsS0FBSytELGNBQUwsQ0FBb0JyRixNQUFNLENBQUNzQyxNQUFQLENBQWNoQixJQUFkLEVBQW9CRSxlQUFwQixDQUFwQixFQUEwRFMsSUFBSSxDQUFDQyxNQUEvRCxFQUF1RSxNQUF2RSxDQUFuQjs7QUFFQSxrQkFBSVosSUFBSSxDQUFDMEQsR0FBVCxFQUFjO0FBQ1o7QUFDQSxxQkFBSzVCLGFBQUwsQ0FBbUJwQixNQUFuQixFQUEyQlYsSUFBM0IsRUFBa0MrQyxNQUFELElBQVk7QUFDM0Msc0JBQUkxRSxLQUFLLEdBQUcwRSxNQUFaOztBQUNBLHNCQUFJMUUsS0FBSixFQUFXO0FBQ1Qsd0JBQUksQ0FBQ2lFLFFBQVEsQ0FBQ2xCLFdBQWQsRUFBMkI7QUFDekJrQiw4QkFBUSxDQUFDakIsU0FBVCxDQUFtQixHQUFuQjtBQUNEOztBQUVELHdCQUFJLENBQUNpQixRQUFRLENBQUNmLFFBQWQsRUFBd0I7QUFDdEIsMEJBQUk5SCxPQUFPLENBQUMwRCxRQUFSLENBQWlCa0IsS0FBakIsS0FBMkI1RSxPQUFPLENBQUN1RCxVQUFSLENBQW1CcUIsS0FBSyxDQUFDOEUsUUFBekIsQ0FBL0IsRUFBbUU7QUFDakU5RSw2QkFBSyxHQUFHQSxLQUFLLENBQUM4RSxRQUFOLEVBQVI7QUFDRDs7QUFFRCwwQkFBSSxDQUFDMUosT0FBTyxDQUFDZ0QsUUFBUixDQUFpQjRCLEtBQWpCLENBQUwsRUFBOEI7QUFDNUJBLDZCQUFLLEdBQUcsbUJBQVI7QUFDRDs7QUFFRGlFLDhCQUFRLENBQUMzQyxHQUFULENBQWF5RCxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUFFaEY7QUFBRix1QkFBZixDQUFiO0FBQ0Q7QUFDRjs7QUFFRCxzQkFBSSxDQUFDaUUsUUFBUSxDQUFDbEIsV0FBZCxFQUEyQjtBQUN6QmtCLDRCQUFRLENBQUNqQixTQUFULENBQW1CLEdBQW5CO0FBQ0Q7O0FBRUQsc0JBQUk1SCxPQUFPLENBQUMwRCxRQUFSLENBQWlCdUQsTUFBTSxDQUFDUCxJQUF4QixLQUFpQ08sTUFBTSxDQUFDUCxJQUFQLENBQVk2RCxJQUFqRCxFQUF1RDtBQUNyRHRELDBCQUFNLENBQUNQLElBQVAsQ0FBWTZELElBQVosR0FBbUJ4SyxnQkFBZ0IsQ0FBQ2tILE1BQU0sQ0FBQ1AsSUFBUCxDQUFZNkQsSUFBYixDQUFuQztBQUNEOztBQUVELHNCQUFJLENBQUMxQixRQUFRLENBQUNmLFFBQWQsRUFBd0I7QUFDdEJlLDRCQUFRLENBQUMzQyxHQUFULENBQWF5RCxJQUFJLENBQUNDLFNBQUwsQ0FBZTNDLE1BQWYsQ0FBYjtBQUNEO0FBQ0YsaUJBL0JEOztBQWdDQTtBQUNEOztBQUVELG1CQUFLdUQsSUFBTCxDQUFVLGVBQVYsRUFBMkJ2RCxNQUEzQixFQUFtQ1YsSUFBbkMsRUFBeUMvRixJQUF6Qzs7QUFFQSxrQkFBSSxDQUFDcUksUUFBUSxDQUFDbEIsV0FBZCxFQUEyQjtBQUN6QmtCLHdCQUFRLENBQUNqQixTQUFULENBQW1CLEdBQW5CO0FBQ0Q7O0FBQ0Qsa0JBQUksQ0FBQ2lCLFFBQVEsQ0FBQ2YsUUFBZCxFQUF3QjtBQUN0QmUsd0JBQVEsQ0FBQzNDLEdBQVQ7QUFDRDtBQUNGLGFBakVELE1BaUVPO0FBQ0w7QUFDQSxrQkFBSTtBQUNGSyxvQkFBSSxHQUFHb0QsSUFBSSxDQUFDYyxLQUFMLENBQVdaLElBQVgsQ0FBUDtBQUNELGVBRkQsQ0FFRSxPQUFPYSxPQUFQLEVBQWdCO0FBQ2hCbkIsdUJBQU8sQ0FBQzNFLEtBQVIsQ0FBYyx1RkFBZCxFQUF1RzhGLE9BQXZHO0FBQ0FuRSxvQkFBSSxHQUFHO0FBQUNHLHNCQUFJLEVBQUU7QUFBUCxpQkFBUDtBQUNEOztBQUVELGtCQUFJLENBQUMxRyxPQUFPLENBQUMwRCxRQUFSLENBQWlCNkMsSUFBSSxDQUFDRyxJQUF0QixDQUFMLEVBQWtDO0FBQ2hDSCxvQkFBSSxDQUFDRyxJQUFMLEdBQVksRUFBWjtBQUNEOztBQUVELG1CQUFLakMsTUFBTCwrQ0FBbUQ4QixJQUFJLENBQUNHLElBQUwsQ0FBVWlFLElBQVYsSUFBa0IsV0FBckUsZ0JBQXNGcEUsSUFBSSxDQUFDeUQsTUFBM0Y7O0FBQ0Esa0JBQUloSyxPQUFPLENBQUMwRCxRQUFSLENBQWlCNkMsSUFBSSxDQUFDRyxJQUF0QixLQUErQkgsSUFBSSxDQUFDRyxJQUFMLENBQVU2RCxJQUE3QyxFQUFtRDtBQUNqRGhFLG9CQUFJLENBQUNHLElBQUwsQ0FBVTZELElBQVYsR0FBaUJ6SyxZQUFZLENBQUN5RyxJQUFJLENBQUNHLElBQUwsQ0FBVTZELElBQVgsQ0FBN0I7QUFDRDs7QUFFRGhFLGtCQUFJLENBQUNxRSxJQUFMLEdBQVksSUFBWjtBQUNBLGVBQUM7QUFBQzNEO0FBQUQsa0JBQVcsS0FBS3FELGNBQUwsQ0FBb0J0SyxPQUFPLENBQUM2SyxLQUFSLENBQWN0RSxJQUFkLENBQXBCLEVBQXlDVyxJQUFJLENBQUNDLE1BQTlDLEVBQXNELG1CQUF0RCxDQUFaOztBQUVBLGtCQUFJLEtBQUtoRyxVQUFMLENBQWdCMkYsT0FBaEIsQ0FBd0JHLE1BQU0sQ0FBQ3ZCLEdBQS9CLENBQUosRUFBeUM7QUFDdkMsc0JBQU0sSUFBSXBHLE1BQU0sQ0FBQytELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0Isa0RBQXRCLENBQU47QUFDRDs7QUFFRGtELGtCQUFJLENBQUNiLEdBQUwsR0FBV2EsSUFBSSxDQUFDeUQsTUFBaEI7QUFDQXpELGtCQUFJLENBQUNuQixTQUFMLEdBQWlCLElBQUkwRixJQUFKLEVBQWpCO0FBQ0F2RSxrQkFBSSxDQUFDd0UsU0FBTCxHQUFpQnhFLElBQUksQ0FBQ0MsVUFBdEI7O0FBQ0EsbUJBQUs5RCxjQUFMLENBQW9Cc0ksTUFBcEIsQ0FBMkJoTCxPQUFPLENBQUNpTCxJQUFSLENBQWExRSxJQUFiLEVBQW1CLE1BQW5CLENBQTNCOztBQUNBLG1CQUFLRixhQUFMLENBQW1CWSxNQUFNLENBQUN2QixHQUExQixFQUErQnVCLE1BQU0sQ0FBQ1gsSUFBdEMsRUFBNEN0RyxPQUFPLENBQUNpTCxJQUFSLENBQWExRSxJQUFiLEVBQW1CLE1BQW5CLENBQTVDOztBQUVBLGtCQUFJQSxJQUFJLENBQUMyRSxVQUFULEVBQXFCO0FBQ25CLG9CQUFJLENBQUNyQyxRQUFRLENBQUNsQixXQUFkLEVBQTJCO0FBQ3pCa0IsMEJBQVEsQ0FBQ2pCLFNBQVQsQ0FBbUIsR0FBbkI7QUFDRDs7QUFFRCxvQkFBSSxDQUFDaUIsUUFBUSxDQUFDZixRQUFkLEVBQXdCO0FBQ3RCZSwwQkFBUSxDQUFDM0MsR0FBVCxDQUFheUQsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDMUJ1QiwrQkFBVyxZQUFLLEtBQUs3SixhQUFWLGNBQTJCLEtBQUtNLGNBQWhDLGNBRGU7QUFFMUI4RSx3QkFBSSxFQUFFTztBQUZvQixtQkFBZixDQUFiO0FBSUQ7QUFDRixlQVhELE1BV087QUFDTCxvQkFBSSxDQUFDNEIsUUFBUSxDQUFDbEIsV0FBZCxFQUEyQjtBQUN6QmtCLDBCQUFRLENBQUNqQixTQUFULENBQW1CLEdBQW5CO0FBQ0Q7O0FBRUQsb0JBQUksQ0FBQ2lCLFFBQVEsQ0FBQ2YsUUFBZCxFQUF3QjtBQUN0QmUsMEJBQVEsQ0FBQzNDLEdBQVQ7QUFDRDtBQUNGO0FBQ0Y7QUFDRixXQTFIRCxDQTBIRSxPQUFPa0YsV0FBUCxFQUFvQjtBQUNwQi9CLHVCQUFXLENBQUMrQixXQUFELENBQVg7QUFDRDtBQUNGLFNBOUhEOztBQWdJQXhDLGVBQU8sQ0FBQ3lDLFVBQVIsQ0FBbUIsS0FBbkIsRUFBMEJoQyxXQUExQjs7QUFDQSxZQUFJLE9BQU9ULE9BQU8sQ0FBQ2lCLElBQWYsS0FBd0IsUUFBeEIsSUFBb0M1RSxNQUFNLENBQUNxRyxJQUFQLENBQVkxQyxPQUFPLENBQUNpQixJQUFwQixFQUEwQmhDLE1BQTFCLEtBQXFDLENBQTdFLEVBQWdGO0FBQzlFZ0MsY0FBSSxHQUFHRixJQUFJLENBQUNDLFNBQUwsQ0FBZWhCLE9BQU8sQ0FBQ2lCLElBQXZCLENBQVA7QUFDQUMsb0JBQVU7QUFDWCxTQUhELE1BR087QUFDTGxCLGlCQUFPLENBQUNSLEVBQVIsQ0FBVyxNQUFYLEVBQW9CbUQsSUFBRCxJQUFVbEwsS0FBSyxDQUFDLE1BQU07QUFDdkN3SixnQkFBSSxJQUFJMEIsSUFBUjtBQUNELFdBRmlDLENBQWxDO0FBSUEzQyxpQkFBTyxDQUFDUixFQUFSLENBQVcsS0FBWCxFQUFrQixNQUFNL0gsS0FBSyxDQUFDLE1BQU07QUFDbEN5SixzQkFBVTtBQUNYLFdBRjRCLENBQTdCO0FBR0Q7O0FBQ0Q7QUFDRDs7QUFFRCxVQUFJLENBQUMsS0FBSzlILGVBQVYsRUFBMkI7QUFDekIsWUFBSXdKLEdBQUo7O0FBRUEsWUFBSSxDQUFDLEtBQUsxSyxNQUFWLEVBQWtCO0FBQ2hCLGNBQUk4SCxPQUFPLENBQUNHLFVBQVIsQ0FBbUJ6QyxJQUFuQixDQUF3QjBDLFFBQXhCLFdBQW9DLEtBQUsxSCxhQUF6QyxjQUEwRCxLQUFLTSxjQUEvRCxFQUFKLEVBQXNGO0FBQ3BGNEosZUFBRyxHQUFHNUMsT0FBTyxDQUFDRyxVQUFSLENBQW1CekMsSUFBbkIsQ0FBd0JoRCxPQUF4QixXQUFtQyxLQUFLaEMsYUFBeEMsY0FBeUQsS0FBS00sY0FBOUQsR0FBZ0YsRUFBaEYsQ0FBTjs7QUFDQSxnQkFBSTRKLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLEdBQVosTUFBcUIsQ0FBekIsRUFBNEI7QUFDMUJELGlCQUFHLEdBQUdBLEdBQUcsQ0FBQ0UsU0FBSixDQUFjLENBQWQsQ0FBTjtBQUNEOztBQUVELGtCQUFNQyxJQUFJLEdBQUdILEdBQUcsQ0FBQ0ksS0FBSixDQUFVLEdBQVYsQ0FBYjs7QUFDQSxnQkFBSUQsSUFBSSxDQUFDOUQsTUFBTCxLQUFnQixDQUFwQixFQUF1QjtBQUNyQixvQkFBTVIsTUFBTSxHQUFHO0FBQ2IzQixtQkFBRyxFQUFFaUcsSUFBSSxDQUFDLENBQUQsQ0FESTtBQUViRSxxQkFBSyxFQUFFakQsT0FBTyxDQUFDRyxVQUFSLENBQW1COEMsS0FBbkIsR0FBMkIxTCxNQUFNLENBQUNzSyxLQUFQLENBQWE3QixPQUFPLENBQUNHLFVBQVIsQ0FBbUI4QyxLQUFoQyxDQUEzQixHQUFvRSxFQUY5RDtBQUdibEIsb0JBQUksRUFBRWdCLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUUMsS0FBUixDQUFjLEdBQWQsRUFBbUIsQ0FBbkIsQ0FITztBQUliRSx1QkFBTyxFQUFFSCxJQUFJLENBQUMsQ0FBRDtBQUpBLGVBQWY7QUFPQSxvQkFBTTNFLElBQUksR0FBRztBQUFDK0MsdUJBQU8sRUFBRW5CLE9BQVY7QUFBbUJsQix3QkFBUSxFQUFFbUIsUUFBN0I7QUFBdUN4QjtBQUF2QyxlQUFiOztBQUNBLGtCQUFJLEtBQUtoRixnQkFBTCxJQUF5QnJDLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUIsS0FBS2xCLGdCQUF4QixDQUF6QixJQUFzRSxLQUFLQSxnQkFBTCxDQUFzQjJFLElBQXRCLE1BQWdDLElBQTFHLEVBQWdIO0FBQzlHO0FBQ0Q7O0FBRUQsa0JBQUksS0FBS0QsWUFBTCxDQUFrQkMsSUFBbEIsQ0FBSixFQUE2QjtBQUMzQixxQkFBSytFLFFBQUwsQ0FBYy9FLElBQWQsRUFBb0IyRSxJQUFJLENBQUMsQ0FBRCxDQUF4QixFQUE2QixLQUFLeEssVUFBTCxDQUFnQjJGLE9BQWhCLENBQXdCNkUsSUFBSSxDQUFDLENBQUQsQ0FBNUIsQ0FBN0I7QUFDRDtBQUNGLGFBaEJELE1BZ0JPO0FBQ0w3QyxrQkFBSTtBQUNMO0FBQ0YsV0ExQkQsTUEwQk87QUFDTEEsZ0JBQUk7QUFDTDtBQUNGLFNBOUJELE1BOEJPO0FBQ0wsY0FBSUYsT0FBTyxDQUFDRyxVQUFSLENBQW1CekMsSUFBbkIsQ0FBd0IwQyxRQUF4QixXQUFvQyxLQUFLMUgsYUFBekMsRUFBSixFQUErRDtBQUM3RGtLLGVBQUcsR0FBRzVDLE9BQU8sQ0FBQ0csVUFBUixDQUFtQnpDLElBQW5CLENBQXdCaEQsT0FBeEIsV0FBbUMsS0FBS2hDLGFBQXhDLEdBQXlELEVBQXpELENBQU47O0FBQ0EsZ0JBQUlrSyxHQUFHLENBQUNDLE9BQUosQ0FBWSxHQUFaLE1BQXFCLENBQXpCLEVBQTRCO0FBQzFCRCxpQkFBRyxHQUFHQSxHQUFHLENBQUNFLFNBQUosQ0FBYyxDQUFkLENBQU47QUFDRDs7QUFFRCxrQkFBTUMsSUFBSSxHQUFHSCxHQUFHLENBQUNJLEtBQUosQ0FBVSxHQUFWLENBQWI7QUFDQSxnQkFBSUksS0FBSyxHQUFHTCxJQUFJLENBQUNBLElBQUksQ0FBQzlELE1BQUwsR0FBYyxDQUFmLENBQWhCOztBQUNBLGdCQUFJbUUsS0FBSixFQUFXO0FBQ1Qsa0JBQUlGLE9BQUo7O0FBQ0Esa0JBQUlFLEtBQUssQ0FBQ2hELFFBQU4sQ0FBZSxHQUFmLENBQUosRUFBeUI7QUFDdkI4Qyx1QkFBTyxHQUFHRSxLQUFLLENBQUNKLEtBQU4sQ0FBWSxHQUFaLEVBQWlCLENBQWpCLENBQVY7QUFDQUkscUJBQUssR0FBS0EsS0FBSyxDQUFDSixLQUFOLENBQVksR0FBWixFQUFpQixDQUFqQixFQUFvQkEsS0FBcEIsQ0FBMEIsR0FBMUIsRUFBK0IsQ0FBL0IsQ0FBVjtBQUNELGVBSEQsTUFHTztBQUNMRSx1QkFBTyxHQUFHLFVBQVY7QUFDQUUscUJBQUssR0FBS0EsS0FBSyxDQUFDSixLQUFOLENBQVksR0FBWixFQUFpQixDQUFqQixDQUFWO0FBQ0Q7O0FBRUQsb0JBQU12RSxNQUFNLEdBQUc7QUFDYndFLHFCQUFLLEVBQUVqRCxPQUFPLENBQUNHLFVBQVIsQ0FBbUI4QyxLQUFuQixHQUEyQjFMLE1BQU0sQ0FBQ3NLLEtBQVAsQ0FBYTdCLE9BQU8sQ0FBQ0csVUFBUixDQUFtQjhDLEtBQWhDLENBQTNCLEdBQW9FLEVBRDlEO0FBRWJuRixvQkFBSSxFQUFFc0YsS0FGTztBQUdidEcsbUJBQUcsRUFBRXNHLEtBQUssQ0FBQ0osS0FBTixDQUFZLEdBQVosRUFBaUIsQ0FBakIsQ0FIUTtBQUliRSx1QkFKYTtBQUtibkIsb0JBQUksRUFBRXFCO0FBTE8sZUFBZjtBQU9BLG9CQUFNaEYsSUFBSSxHQUFHO0FBQUMrQyx1QkFBTyxFQUFFbkIsT0FBVjtBQUFtQmxCLHdCQUFRLEVBQUVtQixRQUE3QjtBQUF1Q3hCO0FBQXZDLGVBQWI7O0FBQ0Esa0JBQUksS0FBS2hGLGdCQUFMLElBQXlCckMsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLbEIsZ0JBQXhCLENBQXpCLElBQXNFLEtBQUtBLGdCQUFMLENBQXNCMkUsSUFBdEIsTUFBZ0MsSUFBMUcsRUFBZ0g7QUFDOUc7QUFDRDs7QUFDRCxtQkFBSytFLFFBQUwsQ0FBYy9FLElBQWQsRUFBb0I4RSxPQUFwQixFQUE2QixLQUFLM0ssVUFBTCxDQUFnQjJGLE9BQWhCLENBQXdCTyxNQUFNLENBQUMzQixHQUEvQixDQUE3QjtBQUNELGFBdEJELE1Bc0JPO0FBQ0xvRCxrQkFBSTtBQUNMO0FBQ0YsV0FqQ0QsTUFpQ087QUFDTEEsZ0JBQUk7QUFDTDtBQUNGOztBQUNEO0FBQ0Q7O0FBQ0RBLFVBQUk7QUFDTCxLQXpRRDs7QUEyUUEsUUFBSSxDQUFDLEtBQUtySCxhQUFWLEVBQXlCO0FBQ3ZCLFlBQU13SyxRQUFRLEdBQUcsRUFBakIsQ0FEdUIsQ0FHdkI7QUFDQTs7QUFDQUEsY0FBUSxDQUFDLEtBQUtsRSxZQUFMLENBQWtCSSxPQUFuQixDQUFSLEdBQXNDLFVBQVUrRCxRQUFWLEVBQW9CO0FBQ3hEek0sYUFBSyxDQUFDeU0sUUFBRCxFQUFXeE0sS0FBSyxDQUFDc0YsS0FBTixDQUFZNUIsTUFBWixFQUFvQjZCLE1BQXBCLENBQVgsQ0FBTDs7QUFDQXJDLFlBQUksQ0FBQzZCLE1BQUwsc0RBQTBEeUgsUUFBMUQ7O0FBRUEsWUFBSXRKLElBQUksQ0FBQ1YsZUFBVCxFQUEwQjtBQUN4QixjQUFJVSxJQUFJLENBQUNsQixjQUFMLElBQXVCMUIsT0FBTyxDQUFDdUQsVUFBUixDQUFtQlgsSUFBSSxDQUFDbEIsY0FBeEIsQ0FBM0IsRUFBb0U7QUFDbEUsa0JBQU15RixNQUFNLEdBQUcsS0FBS0EsTUFBcEI7QUFDQSxrQkFBTWdGLFNBQVMsR0FBRztBQUNoQmhGLG9CQUFNLEVBQUUsS0FBS0EsTUFERzs7QUFFaEJELGtCQUFJLEdBQUc7QUFDTCxvQkFBSTVILE1BQU0sQ0FBQzhNLEtBQVgsRUFBa0I7QUFDaEIseUJBQU85TSxNQUFNLENBQUM4TSxLQUFQLENBQWF0RixPQUFiLENBQXFCSyxNQUFyQixDQUFQO0FBQ0Q7O0FBQ0QsdUJBQU8sSUFBUDtBQUNEOztBQVBlLGFBQWxCOztBQVVBLGdCQUFJLENBQUN2RSxJQUFJLENBQUNsQixjQUFMLENBQW9CNEYsSUFBcEIsQ0FBeUI2RSxTQUF6QixFQUFxQ3ZKLElBQUksQ0FBQzRDLElBQUwsQ0FBVTBHLFFBQVYsS0FBdUIsSUFBNUQsQ0FBTCxFQUF5RTtBQUN2RSxvQkFBTSxJQUFJNU0sTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQiwyQ0FBdEIsQ0FBTjtBQUNEO0FBQ0Y7O0FBRUQsZ0JBQU1nSixNQUFNLEdBQUd6SixJQUFJLENBQUM0QyxJQUFMLENBQVUwRyxRQUFWLENBQWY7O0FBQ0EsY0FBSUcsTUFBTSxDQUFDbEcsS0FBUCxLQUFpQixDQUFyQixFQUF3QjtBQUN0QnZELGdCQUFJLENBQUNtRCxNQUFMLENBQVltRyxRQUFaO0FBQ0EsbUJBQU8sSUFBUDtBQUNEOztBQUNELGdCQUFNLElBQUk1TSxNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLHNDQUF0QixDQUFOO0FBQ0QsU0F4QkQsTUF3Qk87QUFDTCxnQkFBTSxJQUFJL0QsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixpRUFBdEIsQ0FBTjtBQUNEO0FBQ0YsT0EvQkQsQ0FMdUIsQ0F1Q3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E0SSxjQUFRLENBQUMsS0FBS2xFLFlBQUwsQ0FBa0JHLE1BQW5CLENBQVIsR0FBcUMsVUFBVTNCLElBQVYsRUFBZ0IyRSxVQUFoQixFQUE0QjtBQUMvRHpMLGFBQUssQ0FBQzhHLElBQUQsRUFBTztBQUNWRyxjQUFJLEVBQUV6QixNQURJO0FBRVYrRSxnQkFBTSxFQUFFNUcsTUFGRTtBQUdWa0osZ0JBQU0sRUFBRTVNLEtBQUssQ0FBQzZNLFFBQU4sQ0FBZW5KLE1BQWYsQ0FIRTtBQUlWbkMsbUJBQVMsRUFBRTZELE1BSkQ7QUFLVjBCLG9CQUFVLEVBQUUxQjtBQUxGLFNBQVAsQ0FBTDtBQVFBckYsYUFBSyxDQUFDeUwsVUFBRCxFQUFheEwsS0FBSyxDQUFDNk0sUUFBTixDQUFlMUgsT0FBZixDQUFiLENBQUw7O0FBRUFqQyxZQUFJLENBQUM2QixNQUFMLGlEQUFxRDhCLElBQUksQ0FBQ0csSUFBTCxDQUFVaUUsSUFBL0QsZ0JBQXlFcEUsSUFBSSxDQUFDeUQsTUFBOUU7O0FBQ0F6RCxZQUFJLENBQUNxRSxJQUFMLEdBQVksSUFBWjs7QUFDQSxjQUFNO0FBQUUzRDtBQUFGLFlBQWFyRSxJQUFJLENBQUMwSCxjQUFMLENBQW9CdEssT0FBTyxDQUFDNkssS0FBUixDQUFjdEUsSUFBZCxDQUFwQixFQUF5QyxLQUFLWSxNQUE5QyxFQUFzRCxrQkFBdEQsQ0FBbkI7O0FBRUEsWUFBSXZFLElBQUksQ0FBQ3pCLFVBQUwsQ0FBZ0IyRixPQUFoQixDQUF3QkcsTUFBTSxDQUFDdkIsR0FBL0IsQ0FBSixFQUF5QztBQUN2QyxnQkFBTSxJQUFJcEcsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixrREFBdEIsQ0FBTjtBQUNEOztBQUVEa0QsWUFBSSxDQUFDYixHQUFMLEdBQWlCYSxJQUFJLENBQUN5RCxNQUF0QjtBQUNBekQsWUFBSSxDQUFDbkIsU0FBTCxHQUFpQixJQUFJMEYsSUFBSixFQUFqQjtBQUNBdkUsWUFBSSxDQUFDd0UsU0FBTCxHQUFpQnhFLElBQUksQ0FBQ0MsVUFBdEI7O0FBQ0EsWUFBSTtBQUNGNUQsY0FBSSxDQUFDRixjQUFMLENBQW9Cc0ksTUFBcEIsQ0FBMkJoTCxPQUFPLENBQUNpTCxJQUFSLENBQWExRSxJQUFiLEVBQW1CLE1BQW5CLENBQTNCOztBQUNBM0QsY0FBSSxDQUFDeUQsYUFBTCxDQUFtQlksTUFBTSxDQUFDdkIsR0FBMUIsRUFBK0J1QixNQUFNLENBQUNYLElBQXRDLEVBQTRDdEcsT0FBTyxDQUFDaUwsSUFBUixDQUFhMUUsSUFBYixFQUFtQixNQUFuQixDQUE1QztBQUNELFNBSEQsQ0FHRSxPQUFPaUcsQ0FBUCxFQUFVO0FBQ1Y1SixjQUFJLENBQUM2QixNQUFMLDhEQUFrRThCLElBQUksQ0FBQ0csSUFBTCxDQUFVaUUsSUFBNUUsZ0JBQXNGcEUsSUFBSSxDQUFDeUQsTUFBM0YsR0FBcUd3QyxDQUFyRzs7QUFDQSxnQkFBTSxJQUFJbE4sTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixjQUF0QixDQUFOO0FBQ0Q7O0FBRUQsWUFBSTZILFVBQUosRUFBZ0I7QUFDZCxpQkFBTztBQUNMQyx1QkFBVyxZQUFLdkksSUFBSSxDQUFDdEIsYUFBVixjQUEyQnNCLElBQUksQ0FBQ2hCLGNBQWhDLGNBRE47QUFFTDhFLGdCQUFJLEVBQUVPO0FBRkQsV0FBUDtBQUlEOztBQUNELGVBQU8sSUFBUDtBQUNELE9BckNELENBN0N1QixDQXFGdkI7QUFDQTtBQUNBOzs7QUFDQWdGLGNBQVEsQ0FBQyxLQUFLbEUsWUFBTCxDQUFrQkUsTUFBbkIsQ0FBUixHQUFxQyxVQUFVd0UsS0FBVixFQUFpQjtBQUNwRCxZQUFJbEcsSUFBSSxHQUFHa0csS0FBWDtBQUNBLFlBQUl4RixNQUFKO0FBQ0F4SCxhQUFLLENBQUM4RyxJQUFELEVBQU87QUFDVjBELGFBQUcsRUFBRXZLLEtBQUssQ0FBQzZNLFFBQU4sQ0FBZTFILE9BQWYsQ0FESztBQUVWbUYsZ0JBQU0sRUFBRTVHLE1BRkU7QUFHVjhHLGlCQUFPLEVBQUV4SyxLQUFLLENBQUM2TSxRQUFOLENBQWVuSixNQUFmLENBSEM7QUFJVmlILGlCQUFPLEVBQUUzSyxLQUFLLENBQUM2TSxRQUFOLENBQWV6SCxNQUFmO0FBSkMsU0FBUCxDQUFMOztBQU9BLFlBQUl5QixJQUFJLENBQUMyRCxPQUFULEVBQWtCO0FBQ2hCM0QsY0FBSSxDQUFDMkQsT0FBTCxHQUFlQyxNQUFNLENBQUNDLElBQVAsQ0FBWTdELElBQUksQ0FBQzJELE9BQWpCLEVBQTBCLFFBQTFCLENBQWY7QUFDRDs7QUFFRCxjQUFNekQsZUFBZSxHQUFHN0QsSUFBSSxDQUFDNkQsZUFBTCxDQUFxQkYsSUFBSSxDQUFDeUQsTUFBMUIsQ0FBeEI7O0FBQ0EsWUFBSSxDQUFDdkQsZUFBTCxFQUFzQjtBQUNwQixnQkFBTSxJQUFJbkgsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQiw4REFBdEIsQ0FBTjtBQUNEOztBQUVELGFBQUtxSixPQUFMO0FBQ0EsU0FBQztBQUFDekYsZ0JBQUQ7QUFBU1Y7QUFBVCxZQUFpQjNELElBQUksQ0FBQzBILGNBQUwsQ0FBb0JyRixNQUFNLENBQUNzQyxNQUFQLENBQWNoQixJQUFkLEVBQW9CRSxlQUFwQixDQUFwQixFQUEwRCxLQUFLVSxNQUEvRCxFQUF1RSxLQUF2RSxDQUFsQjs7QUFFQSxZQUFJWixJQUFJLENBQUMwRCxHQUFULEVBQWM7QUFDWixjQUFJO0FBQ0YsbUJBQU9ySCxJQUFJLENBQUMyRixpQkFBTCxDQUF1QnRCLE1BQXZCLEVBQStCVixJQUEvQixDQUFQO0FBQ0QsV0FGRCxDQUVFLE9BQU9vRyxlQUFQLEVBQXdCO0FBQ3hCL0osZ0JBQUksQ0FBQzZCLE1BQUwsQ0FBWSxtREFBWixFQUFpRWtJLGVBQWpFOztBQUNBLGtCQUFNQSxlQUFOO0FBQ0Q7QUFDRixTQVBELE1BT087QUFDTC9KLGNBQUksQ0FBQzRILElBQUwsQ0FBVSxlQUFWLEVBQTJCdkQsTUFBM0IsRUFBbUNWLElBQW5DLEVBQXlDL0YsSUFBekM7QUFDRDs7QUFDRCxlQUFPLElBQVA7QUFDRCxPQWpDRCxDQXhGdUIsQ0EySHZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBeUwsY0FBUSxDQUFDLEtBQUtsRSxZQUFMLENBQWtCQyxNQUFuQixDQUFSLEdBQXFDLFVBQVV0QyxHQUFWLEVBQWU7QUFDbERqRyxhQUFLLENBQUNpRyxHQUFELEVBQU10QyxNQUFOLENBQUw7O0FBRUEsY0FBTXFELGVBQWUsR0FBRzdELElBQUksQ0FBQzZELGVBQUwsQ0FBcUJmLEdBQXJCLENBQXhCOztBQUNBOUMsWUFBSSxDQUFDNkIsTUFBTCw2Q0FBaURpQixHQUFqRCxnQkFBMkQxRixPQUFPLENBQUMwRCxRQUFSLENBQWlCK0MsZUFBZSxDQUFDQyxJQUFqQyxJQUF5Q0QsZUFBZSxDQUFDQyxJQUFoQixDQUFxQkosSUFBOUQsR0FBcUUsRUFBaEk7O0FBRUEsWUFBSTFELElBQUksQ0FBQ2UsZUFBTCxJQUF3QmYsSUFBSSxDQUFDZSxlQUFMLENBQXFCK0IsR0FBckIsQ0FBNUIsRUFBdUQ7QUFDckQ5QyxjQUFJLENBQUNlLGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQk8sSUFBMUI7O0FBQ0FyRCxjQUFJLENBQUNlLGVBQUwsQ0FBcUIrQixHQUFyQixFQUEwQlUsS0FBMUI7QUFDRDs7QUFFRCxZQUFJSyxlQUFKLEVBQXFCO0FBQ25CN0QsY0FBSSxDQUFDRixjQUFMLENBQW9CcUQsTUFBcEIsQ0FBMkI7QUFBQ0w7QUFBRCxXQUEzQjs7QUFDQTlDLGNBQUksQ0FBQ21ELE1BQUwsQ0FBWTtBQUFDTDtBQUFELFdBQVo7O0FBQ0EsY0FBSTFGLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUIrQyxlQUFlLENBQUNDLElBQWpDLEtBQTBDRCxlQUFlLENBQUNDLElBQWhCLENBQXFCSixJQUFuRSxFQUF5RTtBQUN2RTFELGdCQUFJLENBQUNnSyxNQUFMLENBQVk7QUFBQ2xILGlCQUFEO0FBQU1ZLGtCQUFJLEVBQUVHLGVBQWUsQ0FBQ0MsSUFBaEIsQ0FBcUJKO0FBQWpDLGFBQVo7QUFDRDtBQUNGOztBQUNELGVBQU8sSUFBUDtBQUNELE9BbkJEOztBQXFCQWhILFlBQU0sQ0FBQ3VOLE9BQVAsQ0FBZVosUUFBZjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UzQixnQkFBYyxHQUErQjtBQUFBLFFBQTlCL0QsSUFBOEIsdUVBQXZCLEVBQXVCO0FBQUEsUUFBbkJZLE1BQW1CO0FBQUEsUUFBWDJGLFNBQVc7QUFDM0MsUUFBSUMsR0FBSjs7QUFDQSxRQUFJLENBQUMvTSxPQUFPLENBQUM2QyxTQUFSLENBQWtCMEQsSUFBSSxDQUFDMEQsR0FBdkIsQ0FBTCxFQUFrQztBQUNoQzFELFVBQUksQ0FBQzBELEdBQUwsR0FBVyxLQUFYO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDMUQsSUFBSSxDQUFDMkQsT0FBVixFQUFtQjtBQUNqQjNELFVBQUksQ0FBQzJELE9BQUwsR0FBZSxLQUFmO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDbEssT0FBTyxDQUFDd0QsUUFBUixDQUFpQitDLElBQUksQ0FBQzhELE9BQXRCLENBQUwsRUFBcUM7QUFDbkM5RCxVQUFJLENBQUM4RCxPQUFMLEdBQWUsQ0FBQyxDQUFoQjtBQUNEOztBQUVELFFBQUksQ0FBQ3JLLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUJ1RCxJQUFJLENBQUMrRixNQUF0QixDQUFMLEVBQW9DO0FBQ2xDL0YsVUFBSSxDQUFDK0YsTUFBTCxHQUFjL0YsSUFBSSxDQUFDeUQsTUFBbkI7QUFDRDs7QUFFRCxTQUFLdkYsTUFBTCx1Q0FBMkNxSSxTQUEzQyxvQkFBOER2RyxJQUFJLENBQUM4RCxPQUFuRSxjQUE4RTlELElBQUksQ0FBQ0MsVUFBbkYsMkJBQThHRCxJQUFJLENBQUNHLElBQUwsQ0FBVWlFLElBQVYsSUFBa0JwRSxJQUFJLENBQUNHLElBQUwsQ0FBVXNHLFFBQTFJOztBQUVBLFVBQU1BLFFBQVEsR0FBRyxLQUFLQyxZQUFMLENBQWtCMUcsSUFBSSxDQUFDRyxJQUF2QixDQUFqQjs7QUFDQSxVQUFNO0FBQUN3RyxlQUFEO0FBQVlDO0FBQVosUUFBZ0MsS0FBS0MsT0FBTCxDQUFhSixRQUFiLENBQXRDOztBQUVBLFFBQUksQ0FBQ2hOLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUI2QyxJQUFJLENBQUNHLElBQUwsQ0FBVTZELElBQTNCLENBQUwsRUFBdUM7QUFDckNoRSxVQUFJLENBQUNHLElBQUwsQ0FBVTZELElBQVYsR0FBaUIsRUFBakI7QUFDRDs7QUFFRCxRQUFJdEQsTUFBTSxHQUFTVixJQUFJLENBQUNHLElBQXhCO0FBQ0FPLFVBQU0sQ0FBQzBELElBQVAsR0FBbUJxQyxRQUFuQjtBQUNBL0YsVUFBTSxDQUFDc0QsSUFBUCxHQUFtQmhFLElBQUksQ0FBQ0csSUFBTCxDQUFVNkQsSUFBN0I7QUFDQXRELFVBQU0sQ0FBQ2lHLFNBQVAsR0FBbUJBLFNBQW5CO0FBQ0FqRyxVQUFNLENBQUNvRyxHQUFQLEdBQW1CSCxTQUFuQjtBQUNBakcsVUFBTSxDQUFDdkIsR0FBUCxHQUFtQmEsSUFBSSxDQUFDeUQsTUFBeEI7QUFDQS9DLFVBQU0sQ0FBQ0UsTUFBUCxHQUFtQkEsTUFBTSxJQUFJLElBQTdCO0FBQ0FaLFFBQUksQ0FBQytGLE1BQUwsR0FBbUIvRixJQUFJLENBQUMrRixNQUFMLENBQVloSixPQUFaLENBQW9CLG9CQUFwQixFQUEwQyxHQUExQyxDQUFuQjtBQUNBMkQsVUFBTSxDQUFDWCxJQUFQLGFBQXNCLEtBQUszRixXQUFMLENBQWlCc0csTUFBakIsQ0FBdEIsU0FBaUQ3RyxRQUFRLENBQUNnRSxHQUExRCxTQUFnRW1DLElBQUksQ0FBQytGLE1BQXJFLFNBQThFYSxnQkFBOUU7QUFDQWxHLFVBQU0sR0FBYWhDLE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBY04sTUFBZCxFQUFzQixLQUFLcUcsYUFBTCxDQUFtQnJHLE1BQW5CLENBQXRCLENBQW5COztBQUVBLFFBQUksS0FBS3BGLGNBQUwsSUFBdUI3QixPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUsxQixjQUF4QixDQUEzQixFQUFvRTtBQUNsRWtMLFNBQUcsR0FBRzlILE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBYztBQUNsQmIsWUFBSSxFQUFFSCxJQUFJLENBQUNHO0FBRE8sT0FBZCxFQUVIO0FBQ0QyRCxlQUFPLEVBQUU5RCxJQUFJLENBQUM4RCxPQURiO0FBRURsRCxjQUFNLEVBQUVGLE1BQU0sQ0FBQ0UsTUFGZDs7QUFHREQsWUFBSSxHQUFHO0FBQ0wsY0FBSTVILE1BQU0sQ0FBQzhNLEtBQVAsSUFBZ0JuRixNQUFNLENBQUNFLE1BQTNCLEVBQW1DO0FBQ2pDLG1CQUFPN0gsTUFBTSxDQUFDOE0sS0FBUCxDQUFhdEYsT0FBYixDQUFxQkcsTUFBTSxDQUFDRSxNQUE1QixDQUFQO0FBQ0Q7O0FBQ0QsaUJBQU8sSUFBUDtBQUNELFNBUkE7O0FBU0Q4QyxXQUFHLEVBQUUxRCxJQUFJLENBQUMwRDtBQVRULE9BRkcsQ0FBTjtBQWFBLFlBQU1zRCxlQUFlLEdBQUcsS0FBSzFMLGNBQUwsQ0FBb0J5RixJQUFwQixDQUF5QnlGLEdBQXpCLEVBQThCOUYsTUFBOUIsQ0FBeEI7O0FBRUEsVUFBSXNHLGVBQWUsS0FBSyxJQUF4QixFQUE4QjtBQUM1QixjQUFNLElBQUlqTyxNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCckQsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQnVLLGVBQWpCLElBQW9DQSxlQUFwQyxHQUFzRCxrQ0FBNUUsQ0FBTjtBQUNELE9BRkQsTUFFTztBQUNMLFlBQUtoSCxJQUFJLENBQUNxRSxJQUFMLEtBQWMsSUFBZixJQUF3QixLQUFLeEksZ0JBQTdCLElBQWlEcEMsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLbkIsZ0JBQXhCLENBQXJELEVBQWdHO0FBQzlGLGVBQUtBLGdCQUFMLENBQXNCa0YsSUFBdEIsQ0FBMkJ5RixHQUEzQixFQUFnQzlGLE1BQWhDO0FBQ0Q7QUFDRjtBQUNGLEtBdkJELE1BdUJPLElBQUtWLElBQUksQ0FBQ3FFLElBQUwsS0FBYyxJQUFmLElBQXdCLEtBQUt4SSxnQkFBN0IsSUFBaURwQyxPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUtuQixnQkFBeEIsQ0FBckQsRUFBZ0c7QUFDckcySyxTQUFHLEdBQUc5SCxNQUFNLENBQUNzQyxNQUFQLENBQWM7QUFDbEJiLFlBQUksRUFBRUgsSUFBSSxDQUFDRztBQURPLE9BQWQsRUFFSDtBQUNEMkQsZUFBTyxFQUFFOUQsSUFBSSxDQUFDOEQsT0FEYjtBQUVEbEQsY0FBTSxFQUFFRixNQUFNLENBQUNFLE1BRmQ7O0FBR0RELFlBQUksR0FBRztBQUNMLGNBQUk1SCxNQUFNLENBQUM4TSxLQUFQLElBQWdCbkYsTUFBTSxDQUFDRSxNQUEzQixFQUFtQztBQUNqQyxtQkFBTzdILE1BQU0sQ0FBQzhNLEtBQVAsQ0FBYXRGLE9BQWIsQ0FBcUJHLE1BQU0sQ0FBQ0UsTUFBNUIsQ0FBUDtBQUNEOztBQUNELGlCQUFPLElBQVA7QUFDRCxTQVJBOztBQVNEOEMsV0FBRyxFQUFFMUQsSUFBSSxDQUFDMEQ7QUFUVCxPQUZHLENBQU47QUFhQSxXQUFLN0gsZ0JBQUwsQ0FBc0JrRixJQUF0QixDQUEyQnlGLEdBQTNCLEVBQWdDOUYsTUFBaEM7QUFDRDs7QUFFRCxXQUFPO0FBQUNBLFlBQUQ7QUFBU1Y7QUFBVCxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UrQixlQUFhLENBQUNyQixNQUFELEVBQVNWLElBQVQsRUFBZWlILEVBQWYsRUFBbUI7QUFDOUIsU0FBSy9JLE1BQUwsNkRBQWlFd0MsTUFBTSxDQUFDWCxJQUF4RTs7QUFDQXBHLE1BQUUsQ0FBQ3VOLEtBQUgsQ0FBU3hHLE1BQU0sQ0FBQ1gsSUFBaEIsRUFBc0IsS0FBS2xGLFdBQTNCLEVBQXdDWixJQUF4QztBQUNBeUcsVUFBTSxDQUFDOUMsSUFBUCxHQUFnQixLQUFLdUosWUFBTCxDQUFrQm5ILElBQUksQ0FBQ0csSUFBdkIsQ0FBaEI7QUFDQU8sVUFBTSxDQUFDbkcsTUFBUCxHQUFnQixLQUFLQSxNQUFyQjs7QUFDQSxTQUFLNk0sZ0JBQUwsQ0FBc0IxRyxNQUF0Qjs7QUFFQSxTQUFLOUYsVUFBTCxDQUFnQjZKLE1BQWhCLENBQXVCaEwsT0FBTyxDQUFDNkssS0FBUixDQUFjNUQsTUFBZCxDQUF2QixFQUE4QyxDQUFDMkcsU0FBRCxFQUFZbEksR0FBWixLQUFvQjtBQUNoRSxVQUFJa0ksU0FBSixFQUFlO0FBQ2JKLFVBQUUsSUFBSUEsRUFBRSxDQUFDSSxTQUFELENBQVI7O0FBQ0EsYUFBS25KLE1BQUwsQ0FBWSw0REFBWixFQUEwRW1KLFNBQTFFO0FBQ0QsT0FIRCxNQUdPO0FBQ0wsYUFBS2xMLGNBQUwsQ0FBb0JtTCxNQUFwQixDQUEyQjtBQUFDbkksYUFBRyxFQUFFYSxJQUFJLENBQUN5RDtBQUFYLFNBQTNCLEVBQStDO0FBQUM4RCxjQUFJLEVBQUU7QUFBQ25JLHNCQUFVLEVBQUU7QUFBYjtBQUFQLFNBQS9DLEVBQTRFb0ksY0FBRCxJQUFvQjtBQUM3RixjQUFJQSxjQUFKLEVBQW9CO0FBQ2xCUCxjQUFFLElBQUlBLEVBQUUsQ0FBQ08sY0FBRCxDQUFSOztBQUNBLGlCQUFLdEosTUFBTCxDQUFZLDREQUFaLEVBQTBFc0osY0FBMUU7QUFDRCxXQUhELE1BR087QUFDTDlHLGtCQUFNLENBQUN2QixHQUFQLEdBQWFBLEdBQWI7O0FBQ0EsaUJBQUtqQixNQUFMLDREQUFnRXdDLE1BQU0sQ0FBQ1gsSUFBdkU7O0FBQ0EsaUJBQUsvRSxhQUFMLElBQXNCLEtBQUtBLGFBQUwsQ0FBbUIrRixJQUFuQixDQUF3QixJQUF4QixFQUE4QkwsTUFBOUIsQ0FBdEI7QUFDQSxpQkFBS3VELElBQUwsQ0FBVSxhQUFWLEVBQXlCdkQsTUFBekI7QUFDQXVHLGNBQUUsSUFBSUEsRUFBRSxDQUFDLElBQUQsRUFBT3ZHLE1BQVAsQ0FBUjtBQUNEO0FBQ0YsU0FYRDtBQVlEO0FBQ0YsS0FsQkQ7QUFtQkQ7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VvQixlQUFhLENBQUNwQixNQUFELEVBQVNWLElBQVQsRUFBZWlILEVBQWYsRUFBbUI7QUFDOUIsUUFBSTtBQUNGLFVBQUlqSCxJQUFJLENBQUMwRCxHQUFULEVBQWM7QUFDWixhQUFLdEcsZUFBTCxDQUFxQnNELE1BQU0sQ0FBQ3ZCLEdBQTVCLEVBQWlDUSxHQUFqQyxDQUFxQyxNQUFNO0FBQ3pDLGVBQUtzRSxJQUFMLENBQVUsZUFBVixFQUEyQnZELE1BQTNCLEVBQW1DVixJQUFuQyxFQUF5Q2lILEVBQXpDO0FBQ0QsU0FGRDtBQUdELE9BSkQsTUFJTztBQUNMLGFBQUs3SixlQUFMLENBQXFCc0QsTUFBTSxDQUFDdkIsR0FBNUIsRUFBaUNzSSxLQUFqQyxDQUF1Q3pILElBQUksQ0FBQzhELE9BQTVDLEVBQXFEOUQsSUFBSSxDQUFDMkQsT0FBMUQsRUFBbUVzRCxFQUFuRTtBQUNEO0FBQ0YsS0FSRCxDQVFFLE9BQU9oQixDQUFQLEVBQVU7QUFDVixXQUFLL0gsTUFBTCxDQUFZLDhCQUFaLEVBQTRDK0gsQ0FBNUM7O0FBQ0FnQixRQUFFLElBQUlBLEVBQUUsQ0FBQ2hCLENBQUQsQ0FBUjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRWtCLGNBQVksQ0FBQ08sUUFBRCxFQUFXO0FBQ3JCLFFBQUlDLElBQUo7QUFDQXpPLFNBQUssQ0FBQ3dPLFFBQUQsRUFBV2hKLE1BQVgsQ0FBTDs7QUFDQSxRQUFJakYsT0FBTyxDQUFDMEQsUUFBUixDQUFpQnVLLFFBQWpCLEtBQThCQSxRQUFRLENBQUM5SixJQUEzQyxFQUFpRDtBQUMvQytKLFVBQUksR0FBR0QsUUFBUSxDQUFDOUosSUFBaEI7QUFDRDs7QUFFRCxRQUFJLENBQUMrSixJQUFELElBQVMsQ0FBQ2xPLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUJrTCxJQUFqQixDQUFkLEVBQXNDO0FBQ3BDQSxVQUFJLEdBQUcsMEJBQVA7QUFDRDs7QUFDRCxXQUFPQSxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VDLFlBQVUsQ0FBQ0MsS0FBRCxFQUFRO0FBQ2hCLFFBQUksQ0FBQ0EsS0FBTCxFQUFZLE9BQU8sSUFBUCxDQURJLENBR2hCOztBQUNBLFFBQUksQ0FBQzlPLE1BQU0sQ0FBQytPLE1BQVAsQ0FBY0MsUUFBZixZQUFtQ0MsR0FBbkMsSUFBMEMsQ0FBQ3ZPLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJwRSxNQUFNLENBQUMrTyxNQUFQLENBQWNDLFFBQS9CLENBQS9DLEVBQXlGO0FBQ3ZGLFlBQU0sSUFBSWpMLEtBQUosQ0FBVSxzREFBVixDQUFOO0FBQ0Q7O0FBRUQsUUFBSS9ELE1BQU0sQ0FBQytPLE1BQVAsQ0FBY0MsUUFBZCxZQUFrQ0MsR0FBbEMsSUFBeUNqUCxNQUFNLENBQUMrTyxNQUFQLENBQWNDLFFBQWQsQ0FBdUJFLEdBQXZCLENBQTJCSixLQUEzQixDQUF6QyxJQUE4RXBPLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJwRSxNQUFNLENBQUMrTyxNQUFQLENBQWNDLFFBQWQsQ0FBdUJHLEdBQXZCLENBQTJCTCxLQUEzQixDQUFqQixDQUFsRixFQUF1STtBQUNySTtBQUNBLGFBQU85TyxNQUFNLENBQUMrTyxNQUFQLENBQWNDLFFBQWQsQ0FBdUJHLEdBQXZCLENBQTJCTCxLQUEzQixFQUFrQ2pILE1BQXpDO0FBQ0QsS0FIRCxNQUdPLElBQUluSCxPQUFPLENBQUMwRCxRQUFSLENBQWlCcEUsTUFBTSxDQUFDK08sTUFBUCxDQUFjQyxRQUEvQixLQUE0Q0YsS0FBSyxJQUFJOU8sTUFBTSxDQUFDK08sTUFBUCxDQUFjQyxRQUFuRSxJQUErRXRPLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJwRSxNQUFNLENBQUMrTyxNQUFQLENBQWNDLFFBQWQsQ0FBdUJGLEtBQXZCLENBQWpCLENBQW5GLEVBQW9JO0FBQ3pJO0FBQ0EsYUFBTzlPLE1BQU0sQ0FBQytPLE1BQVAsQ0FBY0MsUUFBZCxDQUF1QkYsS0FBdkIsRUFBOEJqSCxNQUFyQztBQUNEOztBQUVELFdBQU8sSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFQyxVQUFRLEdBQUc7QUFDVCxXQUFPLEtBQUtwRyxPQUFMLEdBQ0wsS0FBS0EsT0FBTCxDQUFhLEdBQUd1RCxTQUFoQixDQURLLEdBQ3dCLEtBQUttSyxlQUFMLENBQXFCLEdBQUduSyxTQUF4QixDQUQvQjtBQUVEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFbUssaUJBQWUsQ0FBQzFILElBQUQsRUFBTztBQUNwQixVQUFNQyxNQUFNLEdBQUc7QUFDYkMsVUFBSSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWMsT0FEVjs7QUFFYkMsWUFBTSxFQUFFO0FBRkssS0FBZjs7QUFLQSxRQUFJSCxJQUFKLEVBQVU7QUFDUixVQUFJMkgsSUFBSSxHQUFHLElBQVg7O0FBQ0EsVUFBSTNILElBQUksQ0FBQytDLE9BQUwsQ0FBYWhHLE9BQWIsQ0FBcUIsUUFBckIsQ0FBSixFQUFvQztBQUNsQzRLLFlBQUksR0FBRzNILElBQUksQ0FBQytDLE9BQUwsQ0FBYWhHLE9BQWIsQ0FBcUIsUUFBckIsQ0FBUDtBQUNELE9BRkQsTUFFTztBQUNMLGNBQU02SyxNQUFNLEdBQUc1SCxJQUFJLENBQUMrQyxPQUFMLENBQWF2SyxPQUE1Qjs7QUFDQSxZQUFJb1AsTUFBTSxDQUFDSixHQUFQLENBQVcsUUFBWCxDQUFKLEVBQTBCO0FBQ3hCRyxjQUFJLEdBQUdDLE1BQU0sQ0FBQ0gsR0FBUCxDQUFXLFFBQVgsQ0FBUDtBQUNEO0FBQ0Y7O0FBRUQsVUFBSUUsSUFBSixFQUFVO0FBQ1IsY0FBTXhILE1BQU0sR0FBRyxLQUFLZ0gsVUFBTCxDQUFnQlEsSUFBaEIsQ0FBZjs7QUFFQSxZQUFJeEgsTUFBSixFQUFZO0FBQ1ZGLGdCQUFNLENBQUNDLElBQVAsR0FBZ0IsTUFBTTVILE1BQU0sQ0FBQzhNLEtBQVAsQ0FBYXRGLE9BQWIsQ0FBcUJLLE1BQXJCLENBQXRCOztBQUNBRixnQkFBTSxDQUFDRSxNQUFQLEdBQWdCQSxNQUFoQjtBQUNEO0FBQ0Y7QUFDRjs7QUFFRCxXQUFPRixNQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UrRyxPQUFLLENBQUNhLE1BQUQsRUFBcUQ7QUFBQSxRQUE1Q3BDLEtBQTRDLHVFQUFwQyxFQUFvQzs7QUFBQSxRQUFoQ3FDLFNBQWdDOztBQUFBLFFBQXJCQyxtQkFBcUI7O0FBQ3hELFNBQUt0SyxNQUFMLENBQVksNkJBQVo7O0FBQ0EsUUFBSThCLElBQUksR0FBR2tHLEtBQVg7QUFDQSxRQUFJbE0sUUFBUSxHQUFHdU8sU0FBZjtBQUNBLFFBQUlFLGtCQUFrQixHQUFHRCxtQkFBekI7O0FBRUEsUUFBSS9PLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUJnRCxJQUFuQixDQUFKLEVBQThCO0FBQzVCeUksd0JBQWtCLEdBQUd6TyxRQUFyQjtBQUNBQSxjQUFRLEdBQUdnRyxJQUFYO0FBQ0FBLFVBQUksR0FBTyxFQUFYO0FBQ0QsS0FKRCxNQUlPLElBQUl2RyxPQUFPLENBQUM2QyxTQUFSLENBQWtCdEMsUUFBbEIsQ0FBSixFQUFpQztBQUN0Q3lPLHdCQUFrQixHQUFHek8sUUFBckI7QUFDRCxLQUZNLE1BRUEsSUFBSVAsT0FBTyxDQUFDNkMsU0FBUixDQUFrQjBELElBQWxCLENBQUosRUFBNkI7QUFDbEN5SSx3QkFBa0IsR0FBR3pJLElBQXJCO0FBQ0Q7O0FBRUQ5RyxTQUFLLENBQUM4RyxJQUFELEVBQU83RyxLQUFLLENBQUM2TSxRQUFOLENBQWV0SCxNQUFmLENBQVAsQ0FBTDtBQUNBeEYsU0FBSyxDQUFDYyxRQUFELEVBQVdiLEtBQUssQ0FBQzZNLFFBQU4sQ0FBZXhILFFBQWYsQ0FBWCxDQUFMO0FBQ0F0RixTQUFLLENBQUN1UCxrQkFBRCxFQUFxQnRQLEtBQUssQ0FBQzZNLFFBQU4sQ0FBZTFILE9BQWYsQ0FBckIsQ0FBTDtBQUVBLFVBQU1tRixNQUFNLEdBQUt6RCxJQUFJLENBQUN5RCxNQUFMLElBQWV6SyxNQUFNLENBQUMwUCxFQUFQLEVBQWhDO0FBQ0EsVUFBTTNDLE1BQU0sR0FBSyxLQUFLeEssY0FBTCxHQUFzQixLQUFLQSxjQUFMLENBQW9CeUUsSUFBcEIsQ0FBdEIsR0FBa0R5RCxNQUFuRTtBQUNBLFVBQU1nRCxRQUFRLEdBQUl6RyxJQUFJLENBQUNvRSxJQUFMLElBQWFwRSxJQUFJLENBQUN5RyxRQUFuQixHQUFnQ3pHLElBQUksQ0FBQ29FLElBQUwsSUFBYXBFLElBQUksQ0FBQ3lHLFFBQWxELEdBQThEVixNQUEvRTs7QUFFQSxVQUFNO0FBQUNZLGVBQUQ7QUFBWUM7QUFBWixRQUFnQyxLQUFLQyxPQUFMLENBQWFKLFFBQWIsQ0FBdEM7O0FBRUF6RyxRQUFJLENBQUNELElBQUwsYUFBZSxLQUFLM0YsV0FBTCxDQUFpQjRGLElBQWpCLENBQWYsU0FBd0NuRyxRQUFRLENBQUNnRSxHQUFqRCxTQUF1RGtJLE1BQXZELFNBQWdFYSxnQkFBaEU7QUFDQTVHLFFBQUksQ0FBQ3BDLElBQUwsR0FBWSxLQUFLdUosWUFBTCxDQUFrQm5ILElBQWxCLENBQVo7O0FBQ0EsUUFBSSxDQUFDdkcsT0FBTyxDQUFDMEQsUUFBUixDQUFpQjZDLElBQUksQ0FBQ2dFLElBQXRCLENBQUwsRUFBa0M7QUFDaENoRSxVQUFJLENBQUNnRSxJQUFMLEdBQVksRUFBWjtBQUNEOztBQUVELFFBQUksQ0FBQ3ZLLE9BQU8sQ0FBQ3dELFFBQVIsQ0FBaUIrQyxJQUFJLENBQUN0QyxJQUF0QixDQUFMLEVBQWtDO0FBQ2hDc0MsVUFBSSxDQUFDdEMsSUFBTCxHQUFZNEssTUFBTSxDQUFDaEgsTUFBbkI7QUFDRDs7QUFFRCxVQUFNWixNQUFNLEdBQUcsS0FBS3FHLGFBQUwsQ0FBbUI7QUFDaEMzQyxVQUFJLEVBQUVxQyxRQUQwQjtBQUVoQzFHLFVBQUksRUFBRUMsSUFBSSxDQUFDRCxJQUZxQjtBQUdoQ2lFLFVBQUksRUFBRWhFLElBQUksQ0FBQ2dFLElBSHFCO0FBSWhDcEcsVUFBSSxFQUFFb0MsSUFBSSxDQUFDcEMsSUFKcUI7QUFLaENGLFVBQUksRUFBRXNDLElBQUksQ0FBQ3RDLElBTHFCO0FBTWhDa0QsWUFBTSxFQUFFWixJQUFJLENBQUNZLE1BTm1CO0FBT2hDK0Y7QUFQZ0MsS0FBbkIsQ0FBZjs7QUFVQWpHLFVBQU0sQ0FBQ3ZCLEdBQVAsR0FBYXNFLE1BQWI7QUFFQTlKLE1BQUUsQ0FBQ2dQLFVBQUgsQ0FBYzNJLElBQUksQ0FBQ0QsSUFBbkIsRUFBMEI2SSxPQUFELElBQWE7QUFDcEM5TyxXQUFLLENBQUMsTUFBTTtBQUNWLFlBQUk4TyxPQUFKLEVBQWE7QUFDWDVPLGtCQUFRLElBQUlBLFFBQVEsQ0FBQzRPLE9BQUQsQ0FBcEI7O0FBQ0EsZUFBSzFLLE1BQUwsMkRBQStEdUksUUFBL0QsaUJBQThFekcsSUFBSSxDQUFDRCxJQUFuRixHQUEyRjZJLE9BQTNGO0FBQ0QsU0FIRCxNQUdPO0FBQ0wsZ0JBQU1DLE1BQU0sR0FBR2xQLEVBQUUsQ0FBQ21QLGlCQUFILENBQXFCOUksSUFBSSxDQUFDRCxJQUExQixFQUFnQztBQUFDZ0osaUJBQUssRUFBRSxHQUFSO0FBQWEzSyxnQkFBSSxFQUFFLEtBQUt2RDtBQUF4QixXQUFoQyxDQUFmO0FBQ0FnTyxnQkFBTSxDQUFDbEosR0FBUCxDQUFXMkksTUFBWCxFQUFvQlUsU0FBRCxJQUFlO0FBQ2hDbFAsaUJBQUssQ0FBQyxNQUFNO0FBQ1Ysa0JBQUlrUCxTQUFKLEVBQWU7QUFDYmhQLHdCQUFRLElBQUlBLFFBQVEsQ0FBQ2dQLFNBQUQsQ0FBcEI7QUFDRCxlQUZELE1BRU87QUFDTCxxQkFBS3BPLFVBQUwsQ0FBZ0I2SixNQUFoQixDQUF1Qi9ELE1BQXZCLEVBQStCLENBQUN1SSxTQUFELEVBQVk5SixHQUFaLEtBQW9CO0FBQ2pELHNCQUFJOEosU0FBSixFQUFlO0FBQ2JqUCw0QkFBUSxJQUFJQSxRQUFRLENBQUNpUCxTQUFELENBQXBCOztBQUNBLHlCQUFLL0ssTUFBTCxxREFBeUR1SSxRQUF6RCxpQkFBd0UsS0FBS3BMLGNBQTdFLEdBQStGNE4sU0FBL0Y7QUFDRCxtQkFIRCxNQUdPO0FBQ0wsMEJBQU0zTCxPQUFPLEdBQUcsS0FBSzFDLFVBQUwsQ0FBZ0IyRixPQUFoQixDQUF3QnBCLEdBQXhCLENBQWhCO0FBQ0FuRiw0QkFBUSxJQUFJQSxRQUFRLENBQUMsSUFBRCxFQUFPc0QsT0FBUCxDQUFwQjs7QUFDQSx3QkFBSW1MLGtCQUFrQixLQUFLLElBQTNCLEVBQWlDO0FBQy9CLDJCQUFLek4sYUFBTCxJQUFzQixLQUFLQSxhQUFMLENBQW1CK0YsSUFBbkIsQ0FBd0IsSUFBeEIsRUFBOEJ6RCxPQUE5QixDQUF0QjtBQUNBLDJCQUFLMkcsSUFBTCxDQUFVLGFBQVYsRUFBeUIzRyxPQUF6QjtBQUNEOztBQUNELHlCQUFLWSxNQUFMLHNDQUEwQ3VJLFFBQTFDLGlCQUF5RCxLQUFLcEwsY0FBOUQ7QUFDRDtBQUNGLGlCQWJEO0FBY0Q7QUFDRixhQW5CSSxDQUFMO0FBb0JELFdBckJEO0FBc0JEO0FBQ0YsT0E3QkksQ0FBTDtBQThCRCxLQS9CRDtBQWdDQSxXQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0U2TixNQUFJLENBQUNDLEdBQUQsRUFBMEQ7QUFBQSxRQUFwRGpELEtBQW9ELHVFQUE1QyxFQUE0Qzs7QUFBQSxRQUF4Q3FDLFNBQXdDOztBQUFBLFFBQTdCQyxtQkFBNkIsdUVBQVAsS0FBTzs7QUFDNUQsU0FBS3RLLE1BQUwsbUNBQXVDaUwsR0FBdkMsZUFBK0MvRixJQUFJLENBQUNDLFNBQUwsQ0FBZTZDLEtBQWYsQ0FBL0M7O0FBQ0EsUUFBSWxHLElBQUksR0FBR2tHLEtBQVg7QUFDQSxRQUFJbE0sUUFBUSxHQUFHdU8sU0FBZjtBQUNBLFFBQUlFLGtCQUFrQixHQUFHRCxtQkFBekI7O0FBRUEsUUFBSS9PLE9BQU8sQ0FBQ3VELFVBQVIsQ0FBbUJnRCxJQUFuQixDQUFKLEVBQThCO0FBQzVCeUksd0JBQWtCLEdBQUd6TyxRQUFyQjtBQUNBQSxjQUFRLEdBQUdnRyxJQUFYO0FBQ0FBLFVBQUksR0FBRyxFQUFQO0FBQ0QsS0FKRCxNQUlPLElBQUl2RyxPQUFPLENBQUM2QyxTQUFSLENBQWtCdEMsUUFBbEIsQ0FBSixFQUFpQztBQUN0Q3lPLHdCQUFrQixHQUFHek8sUUFBckI7QUFDRCxLQUZNLE1BRUEsSUFBSVAsT0FBTyxDQUFDNkMsU0FBUixDQUFrQjBELElBQWxCLENBQUosRUFBNkI7QUFDbEN5SSx3QkFBa0IsR0FBR3pJLElBQXJCO0FBQ0Q7O0FBRUQ5RyxTQUFLLENBQUNpUSxHQUFELEVBQU10TSxNQUFOLENBQUw7QUFDQTNELFNBQUssQ0FBQzhHLElBQUQsRUFBTzdHLEtBQUssQ0FBQzZNLFFBQU4sQ0FBZXRILE1BQWYsQ0FBUCxDQUFMO0FBQ0F4RixTQUFLLENBQUNjLFFBQUQsRUFBV2IsS0FBSyxDQUFDNk0sUUFBTixDQUFleEgsUUFBZixDQUFYLENBQUw7QUFDQXRGLFNBQUssQ0FBQ3VQLGtCQUFELEVBQXFCdFAsS0FBSyxDQUFDNk0sUUFBTixDQUFlMUgsT0FBZixDQUFyQixDQUFMOztBQUVBLFFBQUksQ0FBQzdFLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUI2QyxJQUFqQixDQUFMLEVBQTZCO0FBQzNCQSxVQUFJLEdBQUc7QUFDTG9KLGVBQU8sRUFBRTtBQURKLE9BQVA7QUFHRDs7QUFFRCxRQUFJLENBQUNwSixJQUFJLENBQUNvSixPQUFWLEVBQW1CO0FBQ2pCcEosVUFBSSxDQUFDb0osT0FBTCxHQUFlLE1BQWY7QUFDRDs7QUFFRCxVQUFNM0YsTUFBTSxHQUFHekQsSUFBSSxDQUFDeUQsTUFBTCxJQUFlekssTUFBTSxDQUFDMFAsRUFBUCxFQUE5QjtBQUNBLFVBQU0zQyxNQUFNLEdBQUcsS0FBS3hLLGNBQUwsR0FBc0IsS0FBS0EsY0FBTCxDQUFvQnlFLElBQXBCLENBQXRCLEdBQWtEeUQsTUFBakU7QUFDQSxVQUFNNEYsU0FBUyxHQUFHRixHQUFHLENBQUM5RCxLQUFKLENBQVUsR0FBVixDQUFsQjtBQUNBLFVBQU1vQixRQUFRLEdBQUl6RyxJQUFJLENBQUNvRSxJQUFMLElBQWFwRSxJQUFJLENBQUN5RyxRQUFuQixHQUFnQ3pHLElBQUksQ0FBQ29FLElBQUwsSUFBYXBFLElBQUksQ0FBQ3lHLFFBQWxELEdBQThENEMsU0FBUyxDQUFDQSxTQUFTLENBQUMvSCxNQUFWLEdBQW1CLENBQXBCLENBQVQsQ0FBZ0MrRCxLQUFoQyxDQUFzQyxHQUF0QyxFQUEyQyxDQUEzQyxLQUFpRFUsTUFBaEk7O0FBRUEsVUFBTTtBQUFDWSxlQUFEO0FBQVlDO0FBQVosUUFBZ0MsS0FBS0MsT0FBTCxDQUFhSixRQUFiLENBQXRDOztBQUNBekcsUUFBSSxDQUFDRCxJQUFMLGFBQWdCLEtBQUszRixXQUFMLENBQWlCNEYsSUFBakIsQ0FBaEIsU0FBeUNuRyxRQUFRLENBQUNnRSxHQUFsRCxTQUF3RGtJLE1BQXhELFNBQWlFYSxnQkFBakU7O0FBRUEsVUFBTTBDLFdBQVcsR0FBRyxDQUFDNUksTUFBRCxFQUFTdUcsRUFBVCxLQUFnQjtBQUNsQ3ZHLFlBQU0sQ0FBQ3ZCLEdBQVAsR0FBYXNFLE1BQWI7QUFFQSxXQUFLN0ksVUFBTCxDQUFnQjZKLE1BQWhCLENBQXVCL0QsTUFBdkIsRUFBK0IsQ0FBQ3JDLEtBQUQsRUFBUWMsR0FBUixLQUFnQjtBQUM3QyxZQUFJZCxLQUFKLEVBQVc7QUFDVDRJLFlBQUUsSUFBSUEsRUFBRSxDQUFDNUksS0FBRCxDQUFSOztBQUNBLGVBQUtILE1BQUwsb0RBQXdEdUksUUFBeEQsaUJBQXVFLEtBQUtwTCxjQUE1RSxHQUE4RmdELEtBQTlGO0FBQ0QsU0FIRCxNQUdPO0FBQ0wsZ0JBQU1mLE9BQU8sR0FBRyxLQUFLMUMsVUFBTCxDQUFnQjJGLE9BQWhCLENBQXdCcEIsR0FBeEIsQ0FBaEI7QUFDQThILFlBQUUsSUFBSUEsRUFBRSxDQUFDLElBQUQsRUFBTzNKLE9BQVAsQ0FBUjs7QUFDQSxjQUFJbUwsa0JBQWtCLEtBQUssSUFBM0IsRUFBaUM7QUFDL0IsaUJBQUt6TixhQUFMLElBQXNCLEtBQUtBLGFBQUwsQ0FBbUIrRixJQUFuQixDQUF3QixJQUF4QixFQUE4QnpELE9BQTlCLENBQXRCO0FBQ0EsaUJBQUsyRyxJQUFMLENBQVUsYUFBVixFQUF5QjNHLE9BQXpCO0FBQ0Q7O0FBQ0QsZUFBS1ksTUFBTCw2Q0FBaUR1SSxRQUFqRCxpQkFBZ0UsS0FBS3BMLGNBQXJFO0FBQ0Q7QUFDRixPQWJEO0FBY0QsS0FqQkQ7O0FBbUJBMUIsTUFBRSxDQUFDZ1AsVUFBSCxDQUFjM0ksSUFBSSxDQUFDRCxJQUFuQixFQUEwQjZJLE9BQUQsSUFBYTtBQUNwQzlPLFdBQUssQ0FBQyxNQUFNO0FBQ1YsWUFBSThPLE9BQUosRUFBYTtBQUNYNU8sa0JBQVEsSUFBSUEsUUFBUSxDQUFDNE8sT0FBRCxDQUFwQjs7QUFDQSxlQUFLMUssTUFBTCwwREFBOER1SSxRQUE5RCxpQkFBNkV6RyxJQUFJLENBQUNELElBQWxGLEdBQTBGNkksT0FBMUY7QUFDRCxTQUhELE1BR087QUFDTCxjQUFJVyxPQUFPLEdBQUcsS0FBZDtBQUNBLGNBQUlDLEtBQUssR0FBRyxJQUFaO0FBQ0EsZ0JBQU1DLE9BQU8sR0FBRzlQLEVBQUUsQ0FBQ21QLGlCQUFILENBQXFCOUksSUFBSSxDQUFDRCxJQUExQixFQUFnQztBQUFDZ0osaUJBQUssRUFBRSxHQUFSO0FBQWEzSyxnQkFBSSxFQUFFLEtBQUt2RCxXQUF4QjtBQUFxQzZPLHFCQUFTLEVBQUUsSUFBaEQ7QUFBc0RDLHFCQUFTLEVBQUU7QUFBakUsV0FBaEMsQ0FBaEI7O0FBQ0EsZ0JBQU1DLEtBQUssR0FBRyxDQUFDN0csTUFBRCxFQUFTNUIsUUFBVCxLQUFzQjtBQUNsQyxnQkFBSSxDQUFDb0ksT0FBTCxFQUFjO0FBQ1osa0JBQUlDLEtBQUosRUFBVztBQUNUelEsc0JBQU0sQ0FBQzhRLFlBQVAsQ0FBb0JMLEtBQXBCO0FBQ0FBLHFCQUFLLEdBQUcsSUFBUjtBQUNEOztBQUVERCxxQkFBTyxHQUFHLElBQVY7O0FBQ0Esa0JBQUlwSSxRQUFRLElBQUlBLFFBQVEsQ0FBQzJJLE1BQVQsS0FBb0IsR0FBcEMsRUFBeUM7QUFDdkMscUJBQUs1TCxNQUFMLDhDQUFrRGlMLEdBQWxEOztBQUNBLHNCQUFNekksTUFBTSxHQUFHLEtBQUtxRyxhQUFMLENBQW1CO0FBQ2hDM0Msc0JBQUksRUFBRXFDLFFBRDBCO0FBRWhDMUcsc0JBQUksRUFBRUMsSUFBSSxDQUFDRCxJQUZxQjtBQUdoQ2lFLHNCQUFJLEVBQUVoRSxJQUFJLENBQUNnRSxJQUhxQjtBQUloQ3BHLHNCQUFJLEVBQUVvQyxJQUFJLENBQUNwQyxJQUFMLElBQWF1RCxRQUFRLENBQUMzRCxPQUFULENBQWlCMEssR0FBakIsQ0FBcUIsY0FBckIsQ0FBYixJQUFxRCxLQUFLZixZQUFMLENBQWtCO0FBQUNwSCx3QkFBSSxFQUFFQyxJQUFJLENBQUNEO0FBQVosbUJBQWxCLENBSjNCO0FBS2hDckMsc0JBQUksRUFBRXNDLElBQUksQ0FBQ3RDLElBQUwsSUFBYVIsUUFBUSxDQUFDaUUsUUFBUSxDQUFDM0QsT0FBVCxDQUFpQjBLLEdBQWpCLENBQXFCLGdCQUFyQixLQUEwQyxDQUEzQyxDQUxLO0FBTWhDdEgsd0JBQU0sRUFBRVosSUFBSSxDQUFDWSxNQU5tQjtBQU9oQytGO0FBUGdDLGlCQUFuQixDQUFmOztBQVVBLG9CQUFJLENBQUNqRyxNQUFNLENBQUNoRCxJQUFaLEVBQWtCO0FBQ2hCL0Qsb0JBQUUsQ0FBQ29RLElBQUgsQ0FBUS9KLElBQUksQ0FBQ0QsSUFBYixFQUFtQixDQUFDaUssU0FBRCxFQUFZQyxLQUFaLEtBQXNCO0FBQ3ZDblEseUJBQUssQ0FBQyxNQUFNO0FBQ1YsMEJBQUlrUSxTQUFKLEVBQWU7QUFDYmhRLGdDQUFRLElBQUlBLFFBQVEsQ0FBQ2dRLFNBQUQsQ0FBcEI7QUFDRCx1QkFGRCxNQUVPO0FBQ0x0Siw4QkFBTSxDQUFDd0osUUFBUCxDQUFnQkMsUUFBaEIsQ0FBeUJ6TSxJQUF6QixHQUFpQ2dELE1BQU0sQ0FBQ2hELElBQVAsR0FBY3VNLEtBQUssQ0FBQ3ZNLElBQXJEO0FBQ0E0TCxtQ0FBVyxDQUFDNUksTUFBRCxFQUFTMUcsUUFBVCxDQUFYO0FBQ0Q7QUFDRixxQkFQSSxDQUFMO0FBUUQsbUJBVEQ7QUFVRCxpQkFYRCxNQVdPO0FBQ0xzUCw2QkFBVyxDQUFDNUksTUFBRCxFQUFTMUcsUUFBVCxDQUFYO0FBQ0Q7QUFDRixlQTFCRCxNQTBCTztBQUNMLHNCQUFNcUUsS0FBSyxHQUFHMEUsTUFBTSxJQUFJLElBQUloSyxNQUFNLENBQUMrRCxLQUFYLENBQWlCLENBQUFxRSxRQUFRLFNBQVIsSUFBQUEsUUFBUSxXQUFSLFlBQUFBLFFBQVEsQ0FBRTJJLE1BQVYsS0FBb0IsR0FBckMsRUFBMEMsQ0FBQTNJLFFBQVEsU0FBUixJQUFBQSxRQUFRLFdBQVIsWUFBQUEsUUFBUSxDQUFFaUosVUFBVixLQUF3QixpQ0FBbEUsQ0FBeEI7O0FBQ0EscUJBQUtsTSxNQUFMLDJDQUErQ2lMLEdBQS9DLGdCQUErRDlLLEtBQS9EOztBQUVBLG9CQUFJLENBQUNvTCxPQUFPLENBQUNZLFNBQWIsRUFBd0I7QUFDdEJaLHlCQUFPLENBQUNhLE9BQVI7QUFDRDs7QUFFRDNRLGtCQUFFLENBQUM2RixNQUFILENBQVVRLElBQUksQ0FBQ0QsSUFBZixFQUFzQndLLFdBQUQsSUFBaUI7QUFDcEN6USx1QkFBSyxDQUFDLE1BQU07QUFDVkUsNEJBQVEsSUFBSUEsUUFBUSxDQUFDcUUsS0FBRCxDQUFwQjs7QUFDQSx3QkFBSWtNLFdBQUosRUFBaUI7QUFDZiwyQkFBS3JNLE1BQUwsMkNBQStDaUwsR0FBL0MsMkJBQW1FbkosSUFBSSxDQUFDRCxJQUF4RSxzQkFBK0Z3SyxXQUEvRjtBQUNEO0FBQ0YsbUJBTEksQ0FBTDtBQU1ELGlCQVBEO0FBUUQ7QUFDRjtBQUNGLFdBcEREOztBQXNEQSxjQUFJQyxJQUFJLEdBQUcsS0FBSyxDQUFoQjtBQUNBZixpQkFBTyxDQUFDNUgsRUFBUixDQUFXLE9BQVgsRUFBcUJ4RCxLQUFELElBQVc7QUFDN0J2RSxpQkFBSyxDQUFDLE1BQU07QUFDVjhQLG1CQUFLLENBQUN2TCxLQUFELENBQUw7QUFDRCxhQUZJLENBQUw7QUFHRCxXQUpEO0FBS0FvTCxpQkFBTyxDQUFDNUgsRUFBUixDQUFXLE9BQVgsRUFBb0IsTUFBTTtBQUN4Qi9ILGlCQUFLLENBQUMsTUFBTTtBQUNWOFAsbUJBQUssQ0FBQyxLQUFLLENBQU4sRUFBU1ksSUFBVCxDQUFMO0FBQ0QsYUFGSSxDQUFMO0FBR0QsV0FKRDtBQUtBZixpQkFBTyxDQUFDNUgsRUFBUixDQUFXLFFBQVgsRUFBcUIsTUFBTTtBQUN6Qi9ILGlCQUFLLENBQUMsTUFBTTtBQUNWOFAsbUJBQUssQ0FBQyxLQUFLLENBQU4sRUFBU1ksSUFBVCxDQUFMO0FBQ0QsYUFGSSxDQUFMO0FBR0QsV0FKRDtBQU1BLGdCQUFNQyxVQUFVLEdBQUcsSUFBSS9RLGVBQUosRUFBbkI7QUFDQWIsZUFBSyxDQUFDc1EsR0FBRCxFQUFNO0FBQ1QzTCxtQkFBTyxFQUFFd0MsSUFBSSxDQUFDeEMsT0FBTCxJQUFnQixFQURoQjtBQUVUa04sa0JBQU0sRUFBRUQsVUFBVSxDQUFDQztBQUZWLFdBQU4sQ0FBTCxDQUdHQyxJQUhILENBR1NDLEdBQUQsSUFBUztBQUNmSixnQkFBSSxHQUFHSSxHQUFQO0FBQ0FBLGVBQUcsQ0FBQ3RILElBQUosQ0FBU3pCLEVBQVQsQ0FBWSxPQUFaLEVBQXNCeEQsS0FBRCxJQUFXO0FBQzlCdkUsbUJBQUssQ0FBQyxNQUFNO0FBQ1Y4UCxxQkFBSyxDQUFDdkwsS0FBRCxDQUFMO0FBQ0QsZUFGSSxDQUFMO0FBR0QsYUFKRDtBQUtBdU0sZUFBRyxDQUFDdEgsSUFBSixDQUFTdUgsSUFBVCxDQUFjcEIsT0FBZDtBQUNELFdBWEQsRUFXR3FCLEtBWEgsQ0FXVUMsVUFBRCxJQUFnQjtBQUN2Qm5CLGlCQUFLLENBQUNtQixVQUFELENBQUw7QUFDRCxXQWJEOztBQWVBLGNBQUkvSyxJQUFJLENBQUNvSixPQUFMLEdBQWUsQ0FBbkIsRUFBc0I7QUFDcEJJLGlCQUFLLEdBQUd6USxNQUFNLENBQUMrTCxVQUFQLENBQWtCLE1BQU07QUFDOUI4RSxtQkFBSyxDQUFDLElBQUk3USxNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLGtDQUErQ2tELElBQUksQ0FBQ29KLE9BQXBELFFBQUQsQ0FBTDtBQUNBcUIsd0JBQVUsQ0FBQzVLLEtBQVg7QUFDRCxhQUhPLEVBR0xHLElBQUksQ0FBQ29KLE9BSEEsQ0FBUjtBQUlEO0FBQ0Y7QUFDRixPQXRHSSxDQUFMO0FBdUdELEtBeEdEO0FBMEdBLFdBQU8sSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFNEIsU0FBTyxDQUFDakwsSUFBRCxFQUFtRDtBQUFBLFFBQTVDbUcsS0FBNEMsdUVBQXBDLEVBQW9DOztBQUFBLFFBQWhDcUMsU0FBZ0M7O0FBQUEsUUFBckJDLG1CQUFxQjs7QUFDeEQsU0FBS3RLLE1BQUwsc0NBQTBDNkIsSUFBMUM7O0FBQ0EsUUFBSUMsSUFBSSxHQUFHa0csS0FBWDtBQUNBLFFBQUlsTSxRQUFRLEdBQUd1TyxTQUFmO0FBQ0EsUUFBSUUsa0JBQWtCLEdBQUdELG1CQUF6Qjs7QUFFQSxRQUFJL08sT0FBTyxDQUFDdUQsVUFBUixDQUFtQmdELElBQW5CLENBQUosRUFBOEI7QUFDNUJ5SSx3QkFBa0IsR0FBR3pPLFFBQXJCO0FBQ0FBLGNBQVEsR0FBR2dHLElBQVg7QUFDQUEsVUFBSSxHQUFPLEVBQVg7QUFDRCxLQUpELE1BSU8sSUFBSXZHLE9BQU8sQ0FBQzZDLFNBQVIsQ0FBa0J0QyxRQUFsQixDQUFKLEVBQWlDO0FBQ3RDeU8sd0JBQWtCLEdBQUd6TyxRQUFyQjtBQUNELEtBRk0sTUFFQSxJQUFJUCxPQUFPLENBQUM2QyxTQUFSLENBQWtCMEQsSUFBbEIsQ0FBSixFQUE2QjtBQUNsQ3lJLHdCQUFrQixHQUFHekksSUFBckI7QUFDRDs7QUFFRCxRQUFJLEtBQUt6RixNQUFULEVBQWlCO0FBQ2YsWUFBTSxJQUFJeEIsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixrSEFBdEIsQ0FBTjtBQUNEOztBQUVENUQsU0FBSyxDQUFDNkcsSUFBRCxFQUFPbEQsTUFBUCxDQUFMO0FBQ0EzRCxTQUFLLENBQUM4RyxJQUFELEVBQU83RyxLQUFLLENBQUM2TSxRQUFOLENBQWV0SCxNQUFmLENBQVAsQ0FBTDtBQUNBeEYsU0FBSyxDQUFDYyxRQUFELEVBQVdiLEtBQUssQ0FBQzZNLFFBQU4sQ0FBZXhILFFBQWYsQ0FBWCxDQUFMO0FBQ0F0RixTQUFLLENBQUN1UCxrQkFBRCxFQUFxQnRQLEtBQUssQ0FBQzZNLFFBQU4sQ0FBZTFILE9BQWYsQ0FBckIsQ0FBTDtBQUVBM0UsTUFBRSxDQUFDb1EsSUFBSCxDQUFRaEssSUFBUixFQUFjLENBQUNrTCxPQUFELEVBQVVoQixLQUFWLEtBQW9CblEsS0FBSyxDQUFDLE1BQU07QUFDNUMsVUFBSW1SLE9BQUosRUFBYTtBQUNYalIsZ0JBQVEsSUFBSUEsUUFBUSxDQUFDaVIsT0FBRCxDQUFwQjtBQUNELE9BRkQsTUFFTyxJQUFJaEIsS0FBSyxDQUFDaUIsTUFBTixFQUFKLEVBQW9CO0FBQ3pCLFlBQUksQ0FBQ3pSLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUI2QyxJQUFqQixDQUFMLEVBQTZCO0FBQzNCQSxjQUFJLEdBQUcsRUFBUDtBQUNEOztBQUNEQSxZQUFJLENBQUNELElBQUwsR0FBYUEsSUFBYjs7QUFFQSxZQUFJLENBQUNDLElBQUksQ0FBQ3lHLFFBQVYsRUFBb0I7QUFDbEIsZ0JBQU00QyxTQUFTLEdBQUd0SixJQUFJLENBQUNzRixLQUFMLENBQVd4TCxRQUFRLENBQUNnRSxHQUFwQixDQUFsQjtBQUNBbUMsY0FBSSxDQUFDeUcsUUFBTCxHQUFrQjFHLElBQUksQ0FBQ3NGLEtBQUwsQ0FBV3hMLFFBQVEsQ0FBQ2dFLEdBQXBCLEVBQXlCd0wsU0FBUyxDQUFDL0gsTUFBVixHQUFtQixDQUE1QyxDQUFsQjtBQUNEOztBQUVELGNBQU07QUFBQ3FGO0FBQUQsWUFBYyxLQUFLRSxPQUFMLENBQWE3RyxJQUFJLENBQUN5RyxRQUFsQixDQUFwQjs7QUFFQSxZQUFJLENBQUNoTixPQUFPLENBQUNnRCxRQUFSLENBQWlCdUQsSUFBSSxDQUFDcEMsSUFBdEIsQ0FBTCxFQUFrQztBQUNoQ29DLGNBQUksQ0FBQ3BDLElBQUwsR0FBWSxLQUFLdUosWUFBTCxDQUFrQm5ILElBQWxCLENBQVo7QUFDRDs7QUFFRCxZQUFJLENBQUN2RyxPQUFPLENBQUMwRCxRQUFSLENBQWlCNkMsSUFBSSxDQUFDZ0UsSUFBdEIsQ0FBTCxFQUFrQztBQUNoQ2hFLGNBQUksQ0FBQ2dFLElBQUwsR0FBWSxFQUFaO0FBQ0Q7O0FBRUQsWUFBSSxDQUFDdkssT0FBTyxDQUFDd0QsUUFBUixDQUFpQitDLElBQUksQ0FBQ3RDLElBQXRCLENBQUwsRUFBa0M7QUFDaENzQyxjQUFJLENBQUN0QyxJQUFMLEdBQVl1TSxLQUFLLENBQUN2TSxJQUFsQjtBQUNEOztBQUVELGNBQU1nRCxNQUFNLEdBQUcsS0FBS3FHLGFBQUwsQ0FBbUI7QUFDaEMzQyxjQUFJLEVBQUVwRSxJQUFJLENBQUN5RyxRQURxQjtBQUVoQzFHLGNBRmdDO0FBR2hDaUUsY0FBSSxFQUFFaEUsSUFBSSxDQUFDZ0UsSUFIcUI7QUFJaENwRyxjQUFJLEVBQUVvQyxJQUFJLENBQUNwQyxJQUpxQjtBQUtoQ0YsY0FBSSxFQUFFc0MsSUFBSSxDQUFDdEMsSUFMcUI7QUFNaENrRCxnQkFBTSxFQUFFWixJQUFJLENBQUNZLE1BTm1CO0FBT2hDK0YsbUJBUGdDO0FBUWhDd0Usc0JBQVksRUFBRXBMLElBQUksQ0FBQ2hELE9BQUwsV0FBZ0JsRCxRQUFRLENBQUNnRSxHQUF6QixTQUErQm1DLElBQUksQ0FBQ3lHLFFBQXBDLEdBQWdELEVBQWhELENBUmtCO0FBU2hDaEQsZ0JBQU0sRUFBRXpELElBQUksQ0FBQ3lELE1BQUwsSUFBZTtBQVRTLFNBQW5CLENBQWY7O0FBYUEsYUFBSzdJLFVBQUwsQ0FBZ0I2SixNQUFoQixDQUF1Qi9ELE1BQXZCLEVBQStCLENBQUN1SSxTQUFELEVBQVk5SixHQUFaLEtBQW9CO0FBQ2pELGNBQUk4SixTQUFKLEVBQWU7QUFDYmpQLG9CQUFRLElBQUlBLFFBQVEsQ0FBQ2lQLFNBQUQsQ0FBcEI7O0FBQ0EsaUJBQUsvSyxNQUFMLHVEQUEyRHdDLE1BQU0sQ0FBQzBELElBQWxFLGlCQUE2RSxLQUFLL0ksY0FBbEYsR0FBb0c0TixTQUFwRztBQUNELFdBSEQsTUFHTztBQUNMLGtCQUFNM0wsT0FBTyxHQUFHLEtBQUsxQyxVQUFMLENBQWdCMkYsT0FBaEIsQ0FBd0JwQixHQUF4QixDQUFoQjtBQUNBbkYsb0JBQVEsSUFBSUEsUUFBUSxDQUFDLElBQUQsRUFBT3NELE9BQVAsQ0FBcEI7O0FBQ0EsZ0JBQUltTCxrQkFBa0IsS0FBSyxJQUEzQixFQUFpQztBQUMvQixtQkFBS3pOLGFBQUwsSUFBc0IsS0FBS0EsYUFBTCxDQUFtQitGLElBQW5CLENBQXdCLElBQXhCLEVBQThCekQsT0FBOUIsQ0FBdEI7QUFDQSxtQkFBSzJHLElBQUwsQ0FBVSxhQUFWLEVBQXlCM0csT0FBekI7QUFDRDs7QUFDRCxpQkFBS1ksTUFBTCx3Q0FBNEN3QyxNQUFNLENBQUMwRCxJQUFuRCxpQkFBOEQsS0FBSy9JLGNBQW5FO0FBQ0Q7QUFDRixTQWJEO0FBY0QsT0FwRE0sTUFvREE7QUFDTHJCLGdCQUFRLElBQUlBLFFBQVEsQ0FBQyxJQUFJakIsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQix1Q0FBb0RpRCxJQUFwRCw2QkFBRCxDQUFwQjtBQUNEO0FBQ0YsS0ExRHNDLENBQXZDO0FBMkRBLFdBQU8sSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRVAsUUFBTSxDQUFDbUcsUUFBRCxFQUFXM0wsUUFBWCxFQUFxQjtBQUN6QixTQUFLa0UsTUFBTCxxQ0FBeUNrRixJQUFJLENBQUNDLFNBQUwsQ0FBZXNDLFFBQWYsQ0FBekM7O0FBQ0EsUUFBSUEsUUFBUSxLQUFLLEtBQUssQ0FBdEIsRUFBeUI7QUFDdkIsYUFBTyxDQUFQO0FBQ0Q7O0FBQ0R6TSxTQUFLLENBQUNjLFFBQUQsRUFBV2IsS0FBSyxDQUFDNk0sUUFBTixDQUFleEgsUUFBZixDQUFYLENBQUw7QUFFQSxVQUFNNE0sS0FBSyxHQUFHLEtBQUt4USxVQUFMLENBQWdCcUUsSUFBaEIsQ0FBcUIwRyxRQUFyQixDQUFkOztBQUNBLFFBQUl5RixLQUFLLENBQUN4TCxLQUFOLEtBQWdCLENBQXBCLEVBQXVCO0FBQ3JCd0wsV0FBSyxDQUFDQyxPQUFOLENBQWVsTCxJQUFELElBQVU7QUFDdEIsYUFBS2tHLE1BQUwsQ0FBWWxHLElBQVo7QUFDRCxPQUZEO0FBR0QsS0FKRCxNQUlPO0FBQ0xuRyxjQUFRLElBQUlBLFFBQVEsQ0FBQyxJQUFJakIsTUFBTSxDQUFDK0QsS0FBWCxDQUFpQixHQUFqQixFQUFzQixzQ0FBdEIsQ0FBRCxDQUFwQjtBQUNBLGFBQU8sSUFBUDtBQUNEOztBQUVELFFBQUksS0FBSzdCLGFBQVQsRUFBd0I7QUFDdEIsWUFBTXFRLElBQUksR0FBR0YsS0FBSyxDQUFDdlMsS0FBTixFQUFiO0FBQ0EsWUFBTXdELElBQUksR0FBRyxJQUFiO0FBQ0EsV0FBS3pCLFVBQUwsQ0FBZ0I0RSxNQUFoQixDQUF1Qm1HLFFBQXZCLEVBQWlDLFlBQVk7QUFDM0MzTCxnQkFBUSxJQUFJQSxRQUFRLENBQUMrRCxLQUFULENBQWUsSUFBZixFQUFxQkMsU0FBckIsQ0FBWjtBQUNBM0IsWUFBSSxDQUFDcEIsYUFBTCxDQUFtQnFRLElBQW5CO0FBQ0QsT0FIRDtBQUlELEtBUEQsTUFPTztBQUNMLFdBQUsxUSxVQUFMLENBQWdCNEUsTUFBaEIsQ0FBdUJtRyxRQUF2QixFQUFrQzNMLFFBQVEsSUFBSUMsSUFBOUM7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VzUixNQUFJLENBQUNDLEtBQUQsRUFBUTtBQUNWLFNBQUs1USxVQUFMLENBQWdCMlEsSUFBaEIsQ0FBcUJDLEtBQXJCO0FBQ0EsV0FBTyxLQUFLNVEsVUFBWjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTZRLE9BQUssQ0FBQ0QsS0FBRCxFQUFRO0FBQ1gsU0FBSzVRLFVBQUwsQ0FBZ0I2USxLQUFoQixDQUFzQkQsS0FBdEI7QUFDQSxXQUFPLEtBQUs1USxVQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRThRLFlBQVUsR0FBRztBQUNYLFNBQUs5USxVQUFMLENBQWdCMlEsSUFBaEIsQ0FBcUI7QUFDbkI5RyxZQUFNLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYyxPQUROOztBQUVuQjZDLFlBQU0sR0FBRztBQUFFLGVBQU8sSUFBUDtBQUFjLE9BRk47O0FBR25COUgsWUFBTSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWM7O0FBSE4sS0FBckI7QUFLQSxXQUFPLEtBQUs1RSxVQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRStRLGFBQVcsR0FBRztBQUNaLFNBQUsvUSxVQUFMLENBQWdCNlEsS0FBaEIsQ0FBc0I7QUFDcEJoSCxZQUFNLEdBQUc7QUFBRSxlQUFPLElBQVA7QUFBYyxPQURMOztBQUVwQjZDLFlBQU0sR0FBRztBQUFFLGVBQU8sSUFBUDtBQUFjLE9BRkw7O0FBR3BCOUgsWUFBTSxHQUFHO0FBQUUsZUFBTyxJQUFQO0FBQWM7O0FBSEwsS0FBdEI7QUFLQSxXQUFPLEtBQUs1RSxVQUFaO0FBQ0Q7QUFHRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0V5TCxRQUFNLENBQUMvSSxPQUFELEVBQVVpSSxPQUFWLEVBQW1CdkwsUUFBbkIsRUFBNkI7QUFDakMsU0FBS2tFLE1BQUwscUNBQXlDWixPQUFPLENBQUM2QixHQUFqRCxlQUF5RG9HLE9BQXpEOztBQUNBLFFBQUlBLE9BQUosRUFBYTtBQUNYLFVBQUk5TCxPQUFPLENBQUMwRCxRQUFSLENBQWlCRyxPQUFPLENBQUM0TSxRQUF6QixLQUFzQ3pRLE9BQU8sQ0FBQzBELFFBQVIsQ0FBaUJHLE9BQU8sQ0FBQzRNLFFBQVIsQ0FBaUIzRSxPQUFqQixDQUFqQixDQUF0QyxJQUFxRmpJLE9BQU8sQ0FBQzRNLFFBQVIsQ0FBaUIzRSxPQUFqQixFQUEwQnhGLElBQW5ILEVBQXlIO0FBQ3ZIcEcsVUFBRSxDQUFDME0sTUFBSCxDQUFVL0ksT0FBTyxDQUFDNE0sUUFBUixDQUFpQjNFLE9BQWpCLEVBQTBCeEYsSUFBcEMsRUFBMkMvRixRQUFRLElBQUlDLElBQXZEO0FBQ0Q7QUFDRixLQUpELE1BSU87QUFDTCxVQUFJUixPQUFPLENBQUMwRCxRQUFSLENBQWlCRyxPQUFPLENBQUM0TSxRQUF6QixDQUFKLEVBQXdDO0FBQ3RDLGFBQUksSUFBSTBCLElBQVIsSUFBZ0J0TyxPQUFPLENBQUM0TSxRQUF4QixFQUFrQztBQUNoQyxjQUFJNU0sT0FBTyxDQUFDNE0sUUFBUixDQUFpQjBCLElBQWpCLEtBQTBCdE8sT0FBTyxDQUFDNE0sUUFBUixDQUFpQjBCLElBQWpCLEVBQXVCN0wsSUFBckQsRUFBMkQ7QUFDekRwRyxjQUFFLENBQUMwTSxNQUFILENBQVUvSSxPQUFPLENBQUM0TSxRQUFSLENBQWlCMEIsSUFBakIsRUFBdUI3TCxJQUFqQyxFQUF3Qy9GLFFBQVEsSUFBSUMsSUFBcEQ7QUFDRDtBQUNGO0FBQ0YsT0FORCxNQU1PO0FBQ0xOLFVBQUUsQ0FBQzBNLE1BQUgsQ0FBVS9JLE9BQU8sQ0FBQ3lDLElBQWxCLEVBQXlCL0YsUUFBUSxJQUFJQyxJQUFyQztBQUNEO0FBQ0Y7O0FBQ0QsV0FBTyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0U0UixNQUFJLENBQUNwTCxJQUFELEVBQU87QUFDVCxTQUFLdkMsTUFBTCx1Q0FBMkN1QyxJQUFJLENBQUMrQyxPQUFMLENBQWFzSSxXQUF4RDs7QUFDQSxVQUFNNUssSUFBSSxHQUFHLG1CQUFiOztBQUVBLFFBQUksQ0FBQ1QsSUFBSSxDQUFDVSxRQUFMLENBQWNDLFdBQW5CLEVBQWdDO0FBQzlCWCxVQUFJLENBQUNVLFFBQUwsQ0FBY0UsU0FBZCxDQUF3QixHQUF4QixFQUE2QjtBQUMzQix3QkFBZ0IsWUFEVztBQUUzQiwwQkFBa0JILElBQUksQ0FBQ0k7QUFGSSxPQUE3QjtBQUtEOztBQUNELFFBQUksQ0FBQ2IsSUFBSSxDQUFDVSxRQUFMLENBQWNJLFFBQW5CLEVBQTZCO0FBQzNCZCxVQUFJLENBQUNVLFFBQUwsQ0FBY3hCLEdBQWQsQ0FBa0J1QixJQUFsQjtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VzRSxVQUFRLENBQUMvRSxJQUFELEVBQXNDO0FBQUEsUUFBL0I4RSxPQUErQix1RUFBckIsVUFBcUI7QUFBQSxRQUFUakksT0FBUztBQUM1QyxRQUFJeU8sSUFBSjs7QUFDQSxTQUFLN04sTUFBTCx1Q0FBMkN1QyxJQUFJLENBQUMrQyxPQUFMLENBQWFzSSxXQUF4RCxlQUF3RXZHLE9BQXhFOztBQUVBLFFBQUlqSSxPQUFKLEVBQWE7QUFDWCxVQUFJN0QsT0FBTyxDQUFDd08sR0FBUixDQUFZM0ssT0FBWixFQUFxQixVQUFyQixLQUFvQzdELE9BQU8sQ0FBQ3dPLEdBQVIsQ0FBWTNLLE9BQU8sQ0FBQzRNLFFBQXBCLEVBQThCM0UsT0FBOUIsQ0FBeEMsRUFBZ0Y7QUFDOUV3RyxZQUFJLEdBQUd6TyxPQUFPLENBQUM0TSxRQUFSLENBQWlCM0UsT0FBakIsQ0FBUDtBQUNBd0csWUFBSSxDQUFDNU0sR0FBTCxHQUFXN0IsT0FBTyxDQUFDNkIsR0FBbkI7QUFDRCxPQUhELE1BR087QUFDTDRNLFlBQUksR0FBR3pPLE9BQVA7QUFDRDtBQUNGLEtBUEQsTUFPTztBQUNMeU8sVUFBSSxHQUFHLEtBQVA7QUFDRDs7QUFFRCxRQUFJLENBQUNBLElBQUQsSUFBUyxDQUFDdFMsT0FBTyxDQUFDMEQsUUFBUixDQUFpQjRPLElBQWpCLENBQWQsRUFBc0M7QUFDcEMsYUFBTyxLQUFLRixJQUFMLENBQVVwTCxJQUFWLENBQVA7QUFDRCxLQUZELE1BRU8sSUFBSW5ELE9BQUosRUFBYTtBQUNsQixVQUFJLEtBQUsxQixnQkFBVCxFQUEyQjtBQUN6QixZQUFJLENBQUMsS0FBS0EsZ0JBQUwsQ0FBc0JtRixJQUF0QixDQUEyQnJDLE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBY1AsSUFBZCxFQUFvQixLQUFLSSxRQUFMLENBQWNKLElBQWQsQ0FBcEIsQ0FBM0IsRUFBcUVuRCxPQUFyRSxDQUFMLEVBQW9GO0FBQ2xGLGlCQUFPLEtBQUt1TyxJQUFMLENBQVVwTCxJQUFWLENBQVA7QUFDRDtBQUNGOztBQUVELFVBQUksS0FBSzFFLGlCQUFMLElBQTBCdEMsT0FBTyxDQUFDdUQsVUFBUixDQUFtQixLQUFLakIsaUJBQXhCLENBQTFCLElBQXdFLEtBQUtBLGlCQUFMLENBQXVCMEUsSUFBdkIsRUFBNkJuRCxPQUE3QixFQUFzQ2lJLE9BQXRDLE1BQW1ELElBQS9ILEVBQXFJO0FBQ25JLGVBQU8sS0FBSyxDQUFaO0FBQ0Q7O0FBRUQ1TCxRQUFFLENBQUNvUSxJQUFILENBQVFnQyxJQUFJLENBQUNoTSxJQUFiLEVBQW1CLENBQUNrTCxPQUFELEVBQVVoQixLQUFWLEtBQW9CblEsS0FBSyxDQUFDLE1BQU07QUFDakQsWUFBSWtTLFlBQUo7O0FBQ0EsWUFBSWYsT0FBTyxJQUFJLENBQUNoQixLQUFLLENBQUNpQixNQUFOLEVBQWhCLEVBQWdDO0FBQzlCLGlCQUFPLEtBQUtXLElBQUwsQ0FBVXBMLElBQVYsQ0FBUDtBQUNEOztBQUVELFlBQUt3SixLQUFLLENBQUN2TSxJQUFOLEtBQWVxTyxJQUFJLENBQUNyTyxJQUFyQixJQUE4QixDQUFDLEtBQUt0QyxjQUF4QyxFQUF3RDtBQUN0RDJRLGNBQUksQ0FBQ3JPLElBQUwsR0FBWXVNLEtBQUssQ0FBQ3ZNLElBQWxCO0FBQ0Q7O0FBRUQsWUFBS3VNLEtBQUssQ0FBQ3ZNLElBQU4sS0FBZXFPLElBQUksQ0FBQ3JPLElBQXJCLElBQThCLEtBQUt0QyxjQUF2QyxFQUF1RDtBQUNyRDRRLHNCQUFZLEdBQUcsS0FBZjtBQUNEOztBQUVELGVBQU8sS0FBS0MsS0FBTCxDQUFXeEwsSUFBWCxFQUFpQm5ELE9BQWpCLEVBQTBCeU8sSUFBMUIsRUFBZ0N4RyxPQUFoQyxFQUF5QyxJQUF6QyxFQUFnRHlHLFlBQVksSUFBSSxLQUFoRSxDQUFQO0FBQ0QsT0FmMkMsQ0FBNUM7QUFnQkEsYUFBTyxLQUFLLENBQVo7QUFDRDs7QUFDRCxXQUFPLEtBQUtILElBQUwsQ0FBVXBMLElBQVYsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0V3TCxPQUFLLENBQUN4TCxJQUFELEVBQU9uRCxPQUFQLEVBQWdCeU8sSUFBaEIsRUFBNEc7QUFBQSxRQUF0RnhHLE9BQXNGLHVFQUE1RSxVQUE0RTtBQUFBLFFBQWhFMkcsY0FBZ0UsdUVBQS9DLElBQStDOztBQUFBLFFBQXpDQyxhQUF5Qyx1RUFBekIsS0FBeUI7O0FBQUEsUUFBbEJDLFFBQWtCLHVFQUFQLEtBQU87QUFDL0csUUFBSUMsUUFBUSxHQUFHLEtBQWY7QUFDQSxRQUFJQyxRQUFRLEdBQUcsS0FBZjtBQUNBLFFBQUlDLGVBQWUsR0FBRyxFQUF0QjtBQUNBLFFBQUlDLEtBQUo7QUFDQSxRQUFJN00sR0FBSjtBQUNBLFFBQUk4TSxJQUFKO0FBQ0EsUUFBSVQsWUFBWSxHQUFHRyxhQUFuQjs7QUFFQSxRQUFJMUwsSUFBSSxDQUFDSyxNQUFMLENBQVl3RSxLQUFaLENBQWtCRSxRQUFsQixJQUErQi9FLElBQUksQ0FBQ0ssTUFBTCxDQUFZd0UsS0FBWixDQUFrQkUsUUFBbEIsS0FBK0IsTUFBbEUsRUFBMkU7QUFDekUrRyxxQkFBZSxHQUFHLGNBQWxCO0FBQ0QsS0FGRCxNQUVPO0FBQ0xBLHFCQUFlLEdBQUcsVUFBbEI7QUFDRDs7QUFFRCxVQUFNRyxlQUFlLHdCQUFpQkMsU0FBUyxDQUFDWixJQUFJLENBQUMzSCxJQUFMLElBQWE5RyxPQUFPLENBQUM4RyxJQUF0QixDQUFULENBQXFDckgsT0FBckMsQ0FBNkMsS0FBN0MsRUFBb0QsS0FBcEQsQ0FBakIsa0NBQW1HNlAsa0JBQWtCLENBQUNiLElBQUksQ0FBQzNILElBQUwsSUFBYTlHLE9BQU8sQ0FBQzhHLElBQXRCLENBQXJILE9BQXJCO0FBQ0EsVUFBTXlJLG1CQUFtQixHQUFHLGVBQTVCOztBQUVBLFFBQUksQ0FBQ3BNLElBQUksQ0FBQ1UsUUFBTCxDQUFjQyxXQUFuQixFQUFnQztBQUM5QlgsVUFBSSxDQUFDVSxRQUFMLENBQWN5QixTQUFkLENBQXdCLHFCQUF4QixFQUErQzJKLGVBQWUsR0FBR0csZUFBbEIsR0FBb0NHLG1CQUFuRjtBQUNEOztBQUVELFFBQUlwTSxJQUFJLENBQUMrQyxPQUFMLENBQWFoRyxPQUFiLENBQXFCc1AsS0FBckIsSUFBOEIsQ0FBQ1YsUUFBbkMsRUFBNkM7QUFDM0NDLGNBQVEsR0FBRyxJQUFYO0FBQ0EsWUFBTVUsS0FBSyxHQUFHdE0sSUFBSSxDQUFDK0MsT0FBTCxDQUFhaEcsT0FBYixDQUFxQnNQLEtBQXJCLENBQTJCekgsS0FBM0IsQ0FBaUMseUJBQWpDLENBQWQ7QUFDQW1ILFdBQUssR0FBR3RQLFFBQVEsQ0FBQzZQLEtBQUssQ0FBQyxDQUFELENBQU4sQ0FBaEI7QUFDQXBOLFNBQUcsR0FBR3pDLFFBQVEsQ0FBQzZQLEtBQUssQ0FBQyxDQUFELENBQU4sQ0FBZDs7QUFDQSxVQUFJQyxLQUFLLENBQUNyTixHQUFELENBQVQsRUFBZ0I7QUFDZEEsV0FBRyxHQUFHb00sSUFBSSxDQUFDck8sSUFBTCxHQUFZLENBQWxCO0FBQ0Q7O0FBQ0QrTyxVQUFJLEdBQUc5TSxHQUFHLEdBQUc2TSxLQUFiO0FBQ0QsS0FURCxNQVNPO0FBQ0xBLFdBQUssR0FBRyxDQUFSO0FBQ0E3TSxTQUFHLEdBQUdvTSxJQUFJLENBQUNyTyxJQUFMLEdBQVksQ0FBbEI7QUFDQStPLFVBQUksR0FBR1YsSUFBSSxDQUFDck8sSUFBWjtBQUNEOztBQUVELFFBQUkyTyxRQUFRLElBQUs1TCxJQUFJLENBQUNLLE1BQUwsQ0FBWXdFLEtBQVosQ0FBa0IySCxJQUFsQixJQUEyQnhNLElBQUksQ0FBQ0ssTUFBTCxDQUFZd0UsS0FBWixDQUFrQjJILElBQWxCLEtBQTJCLE1BQXZFLEVBQWlGO0FBQy9FWCxjQUFRLEdBQUc7QUFBQ0UsYUFBRDtBQUFRN007QUFBUixPQUFYOztBQUNBLFVBQUlxTixLQUFLLENBQUNSLEtBQUQsQ0FBTCxJQUFnQixDQUFDUSxLQUFLLENBQUNyTixHQUFELENBQTFCLEVBQWlDO0FBQy9CMk0sZ0JBQVEsQ0FBQ0UsS0FBVCxHQUFpQjdNLEdBQUcsR0FBRzhNLElBQXZCO0FBQ0FILGdCQUFRLENBQUMzTSxHQUFULEdBQWlCQSxHQUFqQjtBQUNEOztBQUNELFVBQUksQ0FBQ3FOLEtBQUssQ0FBQ1IsS0FBRCxDQUFOLElBQWlCUSxLQUFLLENBQUNyTixHQUFELENBQTFCLEVBQWlDO0FBQy9CMk0sZ0JBQVEsQ0FBQ0UsS0FBVCxHQUFpQkEsS0FBakI7QUFDQUYsZ0JBQVEsQ0FBQzNNLEdBQVQsR0FBaUI2TSxLQUFLLEdBQUdDLElBQXpCO0FBQ0Q7O0FBRUQsVUFBS0QsS0FBSyxHQUFHQyxJQUFULElBQWtCVixJQUFJLENBQUNyTyxJQUEzQixFQUFpQztBQUMvQjRPLGdCQUFRLENBQUMzTSxHQUFULEdBQWVvTSxJQUFJLENBQUNyTyxJQUFMLEdBQVksQ0FBM0I7QUFDRDs7QUFFRCxVQUFJLEtBQUtsRCxNQUFMLEtBQWlCOFIsUUFBUSxDQUFDRSxLQUFULElBQW1CVCxJQUFJLENBQUNyTyxJQUFMLEdBQVksQ0FBaEMsSUFBd0M0TyxRQUFRLENBQUMzTSxHQUFULEdBQWdCb00sSUFBSSxDQUFDck8sSUFBTCxHQUFZLENBQXBGLENBQUosRUFBOEY7QUFDNUZzTyxvQkFBWSxHQUFHLEtBQWY7QUFDRCxPQUZELE1BRU87QUFDTEEsb0JBQVksR0FBRyxLQUFmO0FBQ0Q7QUFDRixLQXBCRCxNQW9CTztBQUNMQSxrQkFBWSxHQUFHLEtBQWY7QUFDRDs7QUFFRCxVQUFNa0Isa0JBQWtCLEdBQUk3TyxLQUFELElBQVc7QUFDcEMsV0FBS0gsTUFBTCxvQ0FBd0M2TixJQUFJLENBQUNoTSxJQUE3QyxlQUFzRHdGLE9BQXRELGVBQXlFbEgsS0FBekU7O0FBQ0EsVUFBSSxDQUFDb0MsSUFBSSxDQUFDVSxRQUFMLENBQWNJLFFBQW5CLEVBQTZCO0FBQzNCZCxZQUFJLENBQUNVLFFBQUwsQ0FBY3hCLEdBQWQsQ0FBa0J0QixLQUFLLENBQUM4RSxRQUFOLEVBQWxCO0FBQ0Q7QUFDRixLQUxEOztBQU9BLFVBQU0zRixPQUFPLEdBQUcvRCxPQUFPLENBQUN1RCxVQUFSLENBQW1CLEtBQUt4QixlQUF4QixJQUEyQyxLQUFLQSxlQUFMLENBQXFCd1EsWUFBckIsRUFBbUMxTyxPQUFuQyxFQUE0Q3lPLElBQTVDLEVBQWtEeEcsT0FBbEQsRUFBMkQ5RSxJQUEzRCxDQUEzQyxHQUE4RyxLQUFLakYsZUFBbkk7O0FBRUEsUUFBSSxDQUFDZ0MsT0FBTyxDQUFDLGVBQUQsQ0FBWixFQUErQjtBQUM3QixVQUFJLENBQUNpRCxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLFlBQUksQ0FBQ1UsUUFBTCxDQUFjeUIsU0FBZCxDQUF3QixlQUF4QixFQUF5QyxLQUFLOUgsWUFBOUM7QUFDRDtBQUNGOztBQUVELFNBQUssSUFBSXFTLEdBQVQsSUFBZ0IzUCxPQUFoQixFQUF5QjtBQUN2QixVQUFJLENBQUNpRCxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLFlBQUksQ0FBQ1UsUUFBTCxDQUFjeUIsU0FBZCxDQUF3QnVLLEdBQXhCLEVBQTZCM1AsT0FBTyxDQUFDMlAsR0FBRCxDQUFwQztBQUNEO0FBQ0Y7O0FBRUQsVUFBTUMsT0FBTyxHQUFHLENBQUN2RSxNQUFELEVBQVN3RSxJQUFULEtBQWtCO0FBQ2hDeEUsWUFBTSxDQUFDeUUsUUFBUCxHQUFrQixLQUFsQjs7QUFDQSxZQUFNQyxhQUFhLEdBQUlDLFVBQUQsSUFBZ0I7QUFDcEMsWUFBSSxDQUFDQSxVQUFMLEVBQWlCO0FBQ2YzRSxnQkFBTSxDQUFDeUUsUUFBUCxHQUFrQixJQUFsQjtBQUNELFNBRkQsTUFFTztBQUNMLGVBQUtwUCxNQUFMLG9DQUF3QzZOLElBQUksQ0FBQ2hNLElBQTdDLGVBQXNEd0YsT0FBdEQsMENBQW9HaUksVUFBcEc7QUFDRDtBQUNGLE9BTkQ7O0FBUUEsWUFBTUMsV0FBVyxHQUFHLE1BQU07QUFDeEIsWUFBSSxDQUFDNUUsTUFBTSxDQUFDeUUsUUFBWixFQUFzQjtBQUNwQixjQUFJLE9BQU96RSxNQUFNLENBQUM2RSxLQUFkLEtBQXdCLFVBQTVCLEVBQXdDO0FBQ3RDN0Usa0JBQU0sQ0FBQzZFLEtBQVAsQ0FBYUgsYUFBYjtBQUNELFdBRkQsTUFFTyxJQUFJLE9BQU8xRSxNQUFNLENBQUNsSixHQUFkLEtBQXNCLFVBQTFCLEVBQXNDO0FBQzNDa0osa0JBQU0sQ0FBQ2xKLEdBQVAsQ0FBVzROLGFBQVg7QUFDRCxXQUZNLE1BRUEsSUFBSSxPQUFPMUUsTUFBTSxDQUFDeUIsT0FBZCxLQUEwQixVQUE5QixFQUEwQztBQUMvQ3pCLGtCQUFNLENBQUN5QixPQUFQLENBQWUsMEJBQWYsRUFBMkNpRCxhQUEzQztBQUNEO0FBQ0Y7QUFDRixPQVZEOztBQVlBLFVBQUksQ0FBQzlNLElBQUksQ0FBQ1UsUUFBTCxDQUFjQyxXQUFmLElBQThCOEssY0FBbEMsRUFBa0Q7QUFDaER6TCxZQUFJLENBQUNVLFFBQUwsQ0FBY0UsU0FBZCxDQUF3QmdNLElBQXhCO0FBQ0Q7O0FBRUQ1TSxVQUFJLENBQUNVLFFBQUwsQ0FBY1UsRUFBZCxDQUFpQixPQUFqQixFQUEwQjRMLFdBQTFCO0FBQ0FoTixVQUFJLENBQUMrQyxPQUFMLENBQWEzQixFQUFiLENBQWdCLFNBQWhCLEVBQTJCLE1BQU07QUFDL0JwQixZQUFJLENBQUMrQyxPQUFMLENBQWFwRCxPQUFiLEdBQXVCLElBQXZCO0FBQ0FxTixtQkFBVztBQUNaLE9BSEQ7QUFLQTVFLFlBQU0sQ0FBQ2hILEVBQVAsQ0FBVSxNQUFWLEVBQWtCLE1BQU07QUFDdEIsWUFBSSxDQUFDcEIsSUFBSSxDQUFDVSxRQUFMLENBQWNDLFdBQW5CLEVBQWdDO0FBQzlCWCxjQUFJLENBQUNVLFFBQUwsQ0FBY0UsU0FBZCxDQUF3QmdNLElBQXhCO0FBQ0Q7QUFDRixPQUpELEVBSUd4TCxFQUpILENBSU0sT0FKTixFQUllLE1BQU07QUFDbkI0TCxtQkFBVzs7QUFDWCxZQUFJLENBQUNoTixJQUFJLENBQUNVLFFBQUwsQ0FBY0ksUUFBbkIsRUFBNkI7QUFDM0JkLGNBQUksQ0FBQ1UsUUFBTCxDQUFjeEIsR0FBZDtBQUNEOztBQUNELFlBQUksQ0FBQ2MsSUFBSSxDQUFDK0MsT0FBTCxDQUFhcEQsT0FBbEIsRUFBMkI7QUFDekJLLGNBQUksQ0FBQytDLE9BQUwsQ0FBYThHLE9BQWI7QUFDRDtBQUNGLE9BWkQsRUFZR3pJLEVBWkgsQ0FZTSxPQVpOLEVBWWdCOEwsR0FBRCxJQUFTO0FBQ3RCRixtQkFBVztBQUNYUCwwQkFBa0IsQ0FBQ1MsR0FBRCxDQUFsQjtBQUNELE9BZkQsRUFlRzlMLEVBZkgsQ0FlTSxLQWZOLEVBZWEsTUFBTTtBQUNqQjRMLG1CQUFXOztBQUNYLFlBQUksQ0FBQ2hOLElBQUksQ0FBQ1UsUUFBTCxDQUFjSSxRQUFuQixFQUE2QjtBQUMzQmQsY0FBSSxDQUFDVSxRQUFMLENBQWN4QixHQUFkO0FBQ0Q7QUFDRixPQXBCRCxFQW9CR2tMLElBcEJILENBb0JRcEssSUFBSSxDQUFDVSxRQXBCYjtBQXFCRCxLQXJERDs7QUF1REEsWUFBUTZLLFlBQVI7QUFDQSxXQUFLLEtBQUw7QUFDRSxhQUFLOU4sTUFBTCxvQ0FBd0M2TixJQUFJLENBQUNoTSxJQUE3QyxlQUFzRHdGLE9BQXREOztBQUNBLFlBQUlyRSxJQUFJLEdBQUcsMEJBQVg7O0FBRUEsWUFBSSxDQUFDVCxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLGNBQUksQ0FBQ1UsUUFBTCxDQUFjRSxTQUFkLENBQXdCLEdBQXhCLEVBQTZCO0FBQzNCLDRCQUFnQixZQURXO0FBRTNCLDhCQUFrQkgsSUFBSSxDQUFDSTtBQUZJLFdBQTdCO0FBSUQ7O0FBRUQsWUFBSSxDQUFDYixJQUFJLENBQUNVLFFBQUwsQ0FBY0ksUUFBbkIsRUFBNkI7QUFDM0JkLGNBQUksQ0FBQ1UsUUFBTCxDQUFjeEIsR0FBZCxDQUFrQnVCLElBQWxCO0FBQ0Q7O0FBQ0Q7O0FBQ0YsV0FBSyxLQUFMO0FBQ0UsYUFBSzJLLElBQUwsQ0FBVXBMLElBQVY7O0FBQ0E7O0FBQ0YsV0FBSyxLQUFMO0FBQ0UsYUFBS3ZDLE1BQUwsb0NBQXdDNk4sSUFBSSxDQUFDaE0sSUFBN0MsZUFBc0R3RixPQUF0RDs7QUFDQSxZQUFJLENBQUM5RSxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLGNBQUksQ0FBQ1UsUUFBTCxDQUFjRSxTQUFkLENBQXdCLEdBQXhCO0FBQ0Q7O0FBQ0QsWUFBSSxDQUFDWixJQUFJLENBQUNVLFFBQUwsQ0FBY0ksUUFBbkIsRUFBNkI7QUFDM0JkLGNBQUksQ0FBQ1UsUUFBTCxDQUFjeEIsR0FBZDtBQUNEOztBQUNEOztBQUNGLFdBQUssS0FBTDtBQUNFLGFBQUt6QixNQUFMLG9DQUF3QzZOLElBQUksQ0FBQ2hNLElBQTdDLGVBQXNEd0YsT0FBdEQ7O0FBQ0EsWUFBSSxDQUFDOUUsSUFBSSxDQUFDVSxRQUFMLENBQWNDLFdBQW5CLEVBQWdDO0FBQzlCWCxjQUFJLENBQUNVLFFBQUwsQ0FBY3lCLFNBQWQsQ0FBd0IsZUFBeEIsa0JBQWtEMEosUUFBUSxDQUFDRSxLQUEzRCxjQUFvRUYsUUFBUSxDQUFDM00sR0FBN0UsY0FBb0ZvTSxJQUFJLENBQUNyTyxJQUF6RjtBQUNEOztBQUNEMFAsZUFBTyxDQUFDbEIsY0FBYyxJQUFJdlMsRUFBRSxDQUFDaVUsZ0JBQUgsQ0FBb0I3QixJQUFJLENBQUNoTSxJQUF6QixFQUErQjtBQUFDeU0sZUFBSyxFQUFFRixRQUFRLENBQUNFLEtBQWpCO0FBQXdCN00sYUFBRyxFQUFFMk0sUUFBUSxDQUFDM007QUFBdEMsU0FBL0IsQ0FBbkIsRUFBK0YsR0FBL0YsQ0FBUDtBQUNBOztBQUNGO0FBQ0UsWUFBSSxDQUFDYyxJQUFJLENBQUNVLFFBQUwsQ0FBY0MsV0FBbkIsRUFBZ0M7QUFDOUJYLGNBQUksQ0FBQ1UsUUFBTCxDQUFjeUIsU0FBZCxDQUF3QixnQkFBeEIsWUFBNkNtSixJQUFJLENBQUNyTyxJQUFsRDtBQUNEOztBQUNELGFBQUtRLE1BQUwsb0NBQXdDNk4sSUFBSSxDQUFDaE0sSUFBN0MsZUFBc0R3RixPQUF0RDs7QUFDQTZILGVBQU8sQ0FBQ2xCLGNBQWMsSUFBSXZTLEVBQUUsQ0FBQ2lVLGdCQUFILENBQW9CN0IsSUFBSSxDQUFDaE0sSUFBekIsQ0FBbkIsRUFBbUQsR0FBbkQsQ0FBUDtBQUNBO0FBekNGO0FBMkNEOztBQTV6RHNELEM7Ozs7Ozs7Ozs7O0FDdEV6RHhILE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUNhLFNBQU8sRUFBQyxNQUFJQztBQUFiLENBQWQ7QUFBaUQsSUFBSXVVLFlBQUo7QUFBaUJ0VixNQUFNLENBQUNJLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNrVixjQUFZLENBQUNqVixDQUFELEVBQUc7QUFBQ2lWLGdCQUFZLEdBQUNqVixDQUFiO0FBQWU7O0FBQWhDLENBQTVCLEVBQThELENBQTlEO0FBQWlFLElBQUlNLEtBQUosRUFBVUMsS0FBVjtBQUFnQlosTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTyxPQUFLLENBQUNOLENBQUQsRUFBRztBQUFDTSxTQUFLLEdBQUNOLENBQU47QUFBUSxHQUFsQjs7QUFBbUJPLE9BQUssQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNPLFNBQUssR0FBQ1AsQ0FBTjtBQUFROztBQUFwQyxDQUEzQixFQUFpRSxDQUFqRTtBQUFvRSxJQUFJa1YsWUFBSixFQUFpQnJVLE9BQWpCO0FBQXlCbEIsTUFBTSxDQUFDSSxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDbVYsY0FBWSxDQUFDbFYsQ0FBRCxFQUFHO0FBQUNrVixnQkFBWSxHQUFDbFYsQ0FBYjtBQUFlLEdBQWhDOztBQUFpQ2EsU0FBTyxDQUFDYixDQUFELEVBQUc7QUFBQ2EsV0FBTyxHQUFDYixDQUFSO0FBQVU7O0FBQXRELENBQXZCLEVBQStFLENBQS9FO0FBQWtGLElBQUltVixXQUFKLEVBQWdCQyxVQUFoQjtBQUEyQnpWLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ29WLGFBQVcsQ0FBQ25WLENBQUQsRUFBRztBQUFDbVYsZUFBVyxHQUFDblYsQ0FBWjtBQUFjLEdBQTlCOztBQUErQm9WLFlBQVUsQ0FBQ3BWLENBQUQsRUFBRztBQUFDb1YsY0FBVSxHQUFDcFYsQ0FBWDtBQUFhOztBQUExRCxDQUExQixFQUFzRixDQUF0Rjs7QUFLOVUsTUFBTVUsbUJBQU4sU0FBa0N1VSxZQUFsQyxDQUErQztBQUM1RDNULGFBQVcsR0FBRztBQUNaO0FBQ0Q7O0FBMEZEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0VnRSxRQUFNLEdBQUc7QUFDUCxRQUFJLEtBQUs3RCxLQUFULEVBQWdCO0FBQ2QsT0FBQzJJLE9BQU8sQ0FBQ2lMLElBQVIsSUFBZ0JqTCxPQUFPLENBQUNrTCxHQUF4QixJQUErQixZQUFZLENBQUcsQ0FBL0MsRUFBaURuUSxLQUFqRCxDQUF1RCxLQUFLLENBQTVELEVBQStEQyxTQUEvRDtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTBJLGNBQVksQ0FBQ2dCLFFBQUQsRUFBVztBQUNyQixVQUFNakIsUUFBUSxHQUFHaUIsUUFBUSxDQUFDdEQsSUFBVCxJQUFpQnNELFFBQVEsQ0FBQ2pCLFFBQTNDOztBQUNBLFFBQUloTixPQUFPLENBQUNnRCxRQUFSLENBQWlCZ0ssUUFBakIsS0FBK0JBLFFBQVEsQ0FBQ25GLE1BQVQsR0FBa0IsQ0FBckQsRUFBeUQ7QUFDdkQsYUFBTyxDQUFDb0csUUFBUSxDQUFDdEQsSUFBVCxJQUFpQnNELFFBQVEsQ0FBQ2pCLFFBQTNCLEVBQXFDMUosT0FBckMsQ0FBNkMsUUFBN0MsRUFBdUQsRUFBdkQsRUFBMkRBLE9BQTNELENBQW1FLFNBQW5FLEVBQThFLEdBQTlFLEVBQW1GQSxPQUFuRixDQUEyRixLQUEzRixFQUFrRyxFQUFsRyxDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxFQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRThKLFNBQU8sQ0FBQ0osUUFBRCxFQUFXO0FBQ2hCLFFBQUlBLFFBQVEsQ0FBQ2hFLFFBQVQsQ0FBa0IsR0FBbEIsQ0FBSixFQUE0QjtBQUMxQixZQUFNa0UsU0FBUyxHQUFHLENBQUNGLFFBQVEsQ0FBQ3BCLEtBQVQsQ0FBZSxHQUFmLEVBQW9COEksR0FBcEIsR0FBMEI5SSxLQUExQixDQUFnQyxHQUFoQyxFQUFxQyxDQUFyQyxLQUEyQyxFQUE1QyxFQUFnRCtJLFdBQWhELEVBQWxCO0FBQ0EsYUFBTztBQUFFdEgsV0FBRyxFQUFFSCxTQUFQO0FBQWtCQSxpQkFBbEI7QUFBNkJDLHdCQUFnQixhQUFNRCxTQUFOO0FBQTdDLE9BQVA7QUFDRDs7QUFDRCxXQUFPO0FBQUVHLFNBQUcsRUFBRSxFQUFQO0FBQVdILGVBQVMsRUFBRSxFQUF0QjtBQUEwQkMsc0JBQWdCLEVBQUU7QUFBNUMsS0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFUSxrQkFBZ0IsQ0FBQ3BDLElBQUQsRUFBTztBQUNyQkEsUUFBSSxDQUFDcUosT0FBTCxHQUFlLFlBQVkzTCxJQUFaLENBQWlCc0MsSUFBSSxDQUFDcEgsSUFBdEIsQ0FBZjtBQUNBb0gsUUFBSSxDQUFDc0osT0FBTCxHQUFlLFlBQVk1TCxJQUFaLENBQWlCc0MsSUFBSSxDQUFDcEgsSUFBdEIsQ0FBZjtBQUNBb0gsUUFBSSxDQUFDdUosT0FBTCxHQUFlLFlBQVk3TCxJQUFaLENBQWlCc0MsSUFBSSxDQUFDcEgsSUFBdEIsQ0FBZjtBQUNBb0gsUUFBSSxDQUFDd0osTUFBTCxHQUFjLFdBQVc5TCxJQUFYLENBQWdCc0MsSUFBSSxDQUFDcEgsSUFBckIsQ0FBZDtBQUNBb0gsUUFBSSxDQUFDeUosTUFBTCxHQUFjLHVCQUF1Qi9MLElBQXZCLENBQTRCc0MsSUFBSSxDQUFDcEgsSUFBakMsQ0FBZDtBQUNBb0gsUUFBSSxDQUFDMEosS0FBTCxHQUFhLDJCQUEyQmhNLElBQTNCLENBQWdDc0MsSUFBSSxDQUFDcEgsSUFBckMsQ0FBYjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VtSixlQUFhLENBQUMvQixJQUFELEVBQU87QUFDbEIsVUFBTTJKLEVBQUUsR0FBRztBQUNUdkssVUFBSSxFQUFFWSxJQUFJLENBQUNaLElBREY7QUFFVHVDLGVBQVMsRUFBRTNCLElBQUksQ0FBQzJCLFNBRlA7QUFHVEcsU0FBRyxFQUFFOUIsSUFBSSxDQUFDMkIsU0FIRDtBQUlUQyxzQkFBZ0IsRUFBRSxNQUFNNUIsSUFBSSxDQUFDMkIsU0FKcEI7QUFLVDVHLFVBQUksRUFBRWlGLElBQUksQ0FBQ2pGLElBTEY7QUFNVGlFLFVBQUksRUFBRWdCLElBQUksQ0FBQ2hCLElBTkY7QUFPVHBHLFVBQUksRUFBRW9ILElBQUksQ0FBQ3BILElBUEY7QUFRVCtKLFVBQUksRUFBRTNDLElBQUksQ0FBQ3BILElBUkY7QUFTVCxtQkFBYW9ILElBQUksQ0FBQ3BILElBVFQ7QUFVVEYsVUFBSSxFQUFFc0gsSUFBSSxDQUFDdEgsSUFWRjtBQVdUa0QsWUFBTSxFQUFFb0UsSUFBSSxDQUFDcEUsTUFBTCxJQUFlLElBWGQ7QUFZVHNKLGNBQVEsRUFBRTtBQUNSQyxnQkFBUSxFQUFFO0FBQ1JwSyxjQUFJLEVBQUVpRixJQUFJLENBQUNqRixJQURIO0FBRVJyQyxjQUFJLEVBQUVzSCxJQUFJLENBQUN0SCxJQUZIO0FBR1JFLGNBQUksRUFBRW9ILElBQUksQ0FBQ3BILElBSEg7QUFJUitJLG1CQUFTLEVBQUUzQixJQUFJLENBQUMyQjtBQUpSO0FBREYsT0FaRDtBQW9CVGlJLG9CQUFjLEVBQUU1SixJQUFJLENBQUM0SixjQUFMLElBQXVCLEtBQUs3VCxhQXBCbkM7QUFxQlQ4VCxxQkFBZSxFQUFFN0osSUFBSSxDQUFDNkosZUFBTCxJQUF3QixLQUFLeFQ7QUFyQnJDLEtBQVgsQ0FEa0IsQ0F5QmxCOztBQUNBLFFBQUkySixJQUFJLENBQUN2QixNQUFULEVBQWlCO0FBQ2ZrTCxRQUFFLENBQUN4UCxHQUFILEdBQVM2RixJQUFJLENBQUN2QixNQUFkO0FBQ0Q7O0FBRUQsU0FBSzJELGdCQUFMLENBQXNCdUgsRUFBdEI7O0FBQ0FBLE1BQUUsQ0FBQ3hELFlBQUgsR0FBa0JuRyxJQUFJLENBQUNtRyxZQUFMLElBQXFCLEtBQUsvUSxXQUFMLENBQWlCc0UsTUFBTSxDQUFDc0MsTUFBUCxDQUFjLEVBQWQsRUFBa0JnRSxJQUFsQixFQUF3QjJKLEVBQXhCLENBQWpCLENBQXZDO0FBQ0EsV0FBT0EsRUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRXBPLFNBQU8sR0FBeUI7QUFBQSxRQUF4Qm9GLFFBQXdCLHVFQUFiLEVBQWE7QUFBQSxRQUFUbUosT0FBUzs7QUFDOUIsU0FBSzVRLE1BQUwsc0NBQTBDa0YsSUFBSSxDQUFDQyxTQUFMLENBQWVzQyxRQUFmLENBQTFDLGVBQXVFdkMsSUFBSSxDQUFDQyxTQUFMLENBQWV5TCxPQUFmLENBQXZFOztBQUNBNVYsU0FBSyxDQUFDeU0sUUFBRCxFQUFXeE0sS0FBSyxDQUFDNk0sUUFBTixDQUFlN00sS0FBSyxDQUFDc0YsS0FBTixDQUFZQyxNQUFaLEVBQW9CN0IsTUFBcEIsRUFBNEJ5QixPQUE1QixFQUFxQ0MsTUFBckMsRUFBNkMsSUFBN0MsQ0FBZixDQUFYLENBQUw7QUFDQXJGLFNBQUssQ0FBQzRWLE9BQUQsRUFBVTNWLEtBQUssQ0FBQzZNLFFBQU4sQ0FBZXRILE1BQWYsQ0FBVixDQUFMO0FBRUEsVUFBTWEsR0FBRyxHQUFHLEtBQUszRSxVQUFMLENBQWdCMkYsT0FBaEIsQ0FBd0JvRixRQUF4QixFQUFrQ21KLE9BQWxDLENBQVo7O0FBQ0EsUUFBSXZQLEdBQUosRUFBUztBQUNQLGFBQU8sSUFBSXlPLFVBQUosQ0FBZXpPLEdBQWYsRUFBb0IsSUFBcEIsQ0FBUDtBQUNEOztBQUNELFdBQU9BLEdBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VOLE1BQUksR0FBeUI7QUFBQSxRQUF4QjBHLFFBQXdCLHVFQUFiLEVBQWE7QUFBQSxRQUFUbUosT0FBUzs7QUFDM0IsU0FBSzVRLE1BQUwsbUNBQXVDa0YsSUFBSSxDQUFDQyxTQUFMLENBQWVzQyxRQUFmLENBQXZDLGVBQW9FdkMsSUFBSSxDQUFDQyxTQUFMLENBQWV5TCxPQUFmLENBQXBFOztBQUNBNVYsU0FBSyxDQUFDeU0sUUFBRCxFQUFXeE0sS0FBSyxDQUFDNk0sUUFBTixDQUFlN00sS0FBSyxDQUFDc0YsS0FBTixDQUFZQyxNQUFaLEVBQW9CN0IsTUFBcEIsRUFBNEJ5QixPQUE1QixFQUFxQ0MsTUFBckMsRUFBNkMsSUFBN0MsQ0FBZixDQUFYLENBQUw7QUFDQXJGLFNBQUssQ0FBQzRWLE9BQUQsRUFBVTNWLEtBQUssQ0FBQzZNLFFBQU4sQ0FBZXRILE1BQWYsQ0FBVixDQUFMO0FBRUEsV0FBTyxJQUFJcVAsV0FBSixDQUFnQnBJLFFBQWhCLEVBQTBCbUosT0FBMUIsRUFBbUMsSUFBbkMsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0V4SCxRQUFNLEdBQUc7QUFDUCxTQUFLMU0sVUFBTCxDQUFnQjBNLE1BQWhCLENBQXVCdkosS0FBdkIsQ0FBNkIsS0FBS25ELFVBQWxDLEVBQThDb0QsU0FBOUM7QUFDQSxXQUFPLEtBQUtwRCxVQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VqQyxNQUFJLENBQUMyRSxPQUFELEVBQXlDO0FBQUEsUUFBL0JpSSxPQUErQix1RUFBckIsVUFBcUI7QUFBQSxRQUFUd0osT0FBUzs7QUFDM0MsU0FBSzdRLE1BQUwsbUNBQXdDekUsT0FBTyxDQUFDMEQsUUFBUixDQUFpQkcsT0FBakIsSUFBNEJBLE9BQU8sQ0FBQzZCLEdBQXBDLEdBQTBDLEtBQUssQ0FBdkYsZUFBOEZvRyxPQUE5Rjs7QUFDQXJNLFNBQUssQ0FBQ29FLE9BQUQsRUFBVW9CLE1BQVYsQ0FBTDs7QUFFQSxRQUFJLENBQUNwQixPQUFMLEVBQWM7QUFDWixhQUFPLEVBQVA7QUFDRDs7QUFDRCxXQUFPd1EsWUFBWSxDQUFDeFEsT0FBRCxFQUFVaUksT0FBVixFQUFtQndKLE9BQW5CLENBQW5CO0FBQ0Q7O0FBMVEyRDs7QUFBekN6VixtQixDQUtaMFYsUyxHQUFZdlYsTztBQUxBSCxtQixDQU9aZ0IsTSxHQUFTO0FBQ2Q2RSxLQUFHLEVBQUU7QUFDSHZCLFFBQUksRUFBRWY7QUFESCxHQURTO0FBSWRhLE1BQUksRUFBRTtBQUNKRSxRQUFJLEVBQUVXO0FBREYsR0FKUTtBQU9kNkYsTUFBSSxFQUFFO0FBQ0p4RyxRQUFJLEVBQUVmO0FBREYsR0FQUTtBQVVkZSxNQUFJLEVBQUU7QUFDSkEsUUFBSSxFQUFFZjtBQURGLEdBVlE7QUFhZGtELE1BQUksRUFBRTtBQUNKbkMsUUFBSSxFQUFFZjtBQURGLEdBYlE7QUFnQmR3UixTQUFPLEVBQUU7QUFDUHpRLFFBQUksRUFBRVU7QUFEQyxHQWhCSztBQW1CZGdRLFNBQU8sRUFBRTtBQUNQMVEsUUFBSSxFQUFFVTtBQURDLEdBbkJLO0FBc0JkaVEsU0FBTyxFQUFFO0FBQ1AzUSxRQUFJLEVBQUVVO0FBREMsR0F0Qks7QUF5QmRrUSxRQUFNLEVBQUU7QUFDTjVRLFFBQUksRUFBRVU7QUFEQSxHQXpCTTtBQTRCZG1RLFFBQU0sRUFBRTtBQUNON1EsUUFBSSxFQUFFVTtBQURBLEdBNUJNO0FBK0Jkb1EsT0FBSyxFQUFFO0FBQ0w5USxRQUFJLEVBQUVVO0FBREQsR0EvQk87QUFrQ2RxSSxXQUFTLEVBQUU7QUFDVC9JLFFBQUksRUFBRWYsTUFERztBQUVUb1MsWUFBUSxFQUFFO0FBRkQsR0FsQ0c7QUFzQ2RuSSxLQUFHLEVBQUU7QUFDSGxKLFFBQUksRUFBRWYsTUFESDtBQUVIb1MsWUFBUSxFQUFFO0FBRlAsR0F0Q1M7QUEwQ2RySSxrQkFBZ0IsRUFBRTtBQUNoQmhKLFFBQUksRUFBRWYsTUFEVTtBQUVoQm9TLFlBQVEsRUFBRTtBQUZNLEdBMUNKO0FBOENkdEgsTUFBSSxFQUFFO0FBQ0ovSixRQUFJLEVBQUVmLE1BREY7QUFFSm9TLFlBQVEsRUFBRTtBQUZOLEdBOUNRO0FBa0RkLGVBQWE7QUFDWHJSLFFBQUksRUFBRWYsTUFESztBQUVYb1MsWUFBUSxFQUFFO0FBRkMsR0FsREM7QUFzRGQ5RCxjQUFZLEVBQUU7QUFDWnZOLFFBQUksRUFBRWY7QUFETSxHQXREQTtBQXlEZCtSLGdCQUFjLEVBQUU7QUFDZGhSLFFBQUksRUFBRWY7QUFEUSxHQXpERjtBQTREZGdTLGlCQUFlLEVBQUU7QUFDZmpSLFFBQUksRUFBRWY7QUFEUyxHQTVESDtBQStEZHRDLFFBQU0sRUFBRTtBQUNOcUQsUUFBSSxFQUFFVSxPQURBO0FBRU4yUSxZQUFRLEVBQUU7QUFGSixHQS9ETTtBQW1FZGpMLE1BQUksRUFBRTtBQUNKcEcsUUFBSSxFQUFFYyxNQURGO0FBRUp3USxZQUFRLEVBQUUsSUFGTjtBQUdKRCxZQUFRLEVBQUU7QUFITixHQW5FUTtBQXdFZHJPLFFBQU0sRUFBRTtBQUNOaEQsUUFBSSxFQUFFZixNQURBO0FBRU5vUyxZQUFRLEVBQUU7QUFGSixHQXhFTTtBQTRFZEUsV0FBUyxFQUFFO0FBQ1R2UixRQUFJLEVBQUUyRyxJQURHO0FBRVQwSyxZQUFRLEVBQUU7QUFGRCxHQTVFRztBQWdGZC9FLFVBQVEsRUFBRTtBQUNSdE0sUUFBSSxFQUFFYyxNQURFO0FBRVJ3USxZQUFRLEVBQUU7QUFGRjtBQWhGSSxDOzs7Ozs7Ozs7OztBQ1psQjNXLE1BQU0sQ0FBQ0MsTUFBUCxDQUFjO0FBQUN3VixZQUFVLEVBQUMsTUFBSUEsVUFBaEI7QUFBMkJELGFBQVcsRUFBQyxNQUFJQTtBQUEzQyxDQUFkO0FBQXVFLElBQUloVixNQUFKO0FBQVdSLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0ksUUFBTSxDQUFDSCxDQUFELEVBQUc7QUFBQ0csVUFBTSxHQUFDSCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEOztBQVUzRSxNQUFNb1YsVUFBTixDQUFpQjtBQUN0QjlULGFBQVcsQ0FBQ2tWLFFBQUQsRUFBV0MsV0FBWCxFQUF3QjtBQUNqQyxTQUFLRCxRQUFMLEdBQW1CQSxRQUFuQjtBQUNBLFNBQUtDLFdBQUwsR0FBbUJBLFdBQW5CO0FBQ0EzUSxVQUFNLENBQUNzQyxNQUFQLENBQWMsSUFBZCxFQUFvQm9PLFFBQXBCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTVQLFFBQU0sQ0FBQ3hGLFFBQUQsRUFBVztBQUNmLFNBQUtxVixXQUFMLENBQWlCblIsTUFBakIsQ0FBd0IsMkNBQXhCOztBQUNBLFFBQUksS0FBS2tSLFFBQVQsRUFBbUI7QUFDakIsV0FBS0MsV0FBTCxDQUFpQjdQLE1BQWpCLENBQXdCLEtBQUs0UCxRQUFMLENBQWNqUSxHQUF0QyxFQUEyQ25GLFFBQTNDO0FBQ0QsS0FGRCxNQUVPO0FBQ0xBLGNBQVEsSUFBSUEsUUFBUSxDQUFDLElBQUlqQixNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLGNBQXRCLENBQUQsQ0FBcEI7QUFDRDs7QUFDRCxXQUFPLElBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VuRSxNQUFJLEdBQWdDO0FBQUEsUUFBL0I0TSxPQUErQix1RUFBckIsVUFBcUI7QUFBQSxRQUFUd0osT0FBUzs7QUFDbEMsU0FBS00sV0FBTCxDQUFpQm5SLE1BQWpCLGdEQUFnRXFILE9BQWhFOztBQUNBLFFBQUksS0FBSzZKLFFBQVQsRUFBbUI7QUFDakIsYUFBTyxLQUFLQyxXQUFMLENBQWlCMVcsSUFBakIsQ0FBc0IsS0FBS3lXLFFBQTNCLEVBQXFDN0osT0FBckMsRUFBOEN3SixPQUE5QyxDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxFQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTdHLEtBQUcsQ0FBQ29ILFFBQUQsRUFBVztBQUNaLFNBQUtELFdBQUwsQ0FBaUJuUixNQUFqQiwrQ0FBK0RvUixRQUEvRDs7QUFDQSxRQUFJQSxRQUFKLEVBQWM7QUFDWixhQUFPLEtBQUtGLFFBQUwsQ0FBY0UsUUFBZCxDQUFQO0FBQ0Q7O0FBQ0QsV0FBTyxLQUFLRixRQUFaO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0V2VyxPQUFLLEdBQUc7QUFDTixTQUFLd1csV0FBTCxDQUFpQm5SLE1BQWpCLENBQXdCLDBDQUF4Qjs7QUFDQSxXQUFPLENBQUMsS0FBS2tSLFFBQU4sQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFRyxNQUFJLEdBQUc7QUFDTCxTQUFLRixXQUFMLENBQWlCblIsTUFBakIsQ0FBd0IseUNBQXhCOztBQUNBLFdBQU9RLE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBYyxJQUFkLEVBQW9CLEtBQUtxTyxXQUFMLENBQWlCelUsVUFBakIsQ0FBNEIyRixPQUE1QixDQUFvQyxLQUFLNk8sUUFBTCxDQUFjalEsR0FBbEQsQ0FBcEIsQ0FBUDtBQUNEOztBQWhGcUI7O0FBNEZqQixNQUFNNE8sV0FBTixDQUFrQjtBQUN2QjdULGFBQVcsR0FBdUM7QUFBQSxRQUF0Q3NWLFNBQXNDLHVFQUExQixFQUEwQjs7QUFBQSxRQUF0QlYsT0FBc0I7O0FBQUEsUUFBYk8sV0FBYTs7QUFDaEQsU0FBS0EsV0FBTCxHQUFtQkEsV0FBbkI7QUFDQSxTQUFLRyxTQUFMLEdBQW1CQSxTQUFuQjtBQUNBLFNBQUtDLFFBQUwsR0FBbUIsQ0FBQyxDQUFwQjtBQUNBLFNBQUszSixNQUFMLEdBQW1CLEtBQUt1SixXQUFMLENBQWlCelUsVUFBakIsQ0FBNEJxRSxJQUE1QixDQUFpQyxLQUFLdVEsU0FBdEMsRUFBaURWLE9BQWpELENBQW5CO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0U1RyxLQUFHLEdBQUc7QUFDSixTQUFLbUgsV0FBTCxDQUFpQm5SLE1BQWpCLENBQXdCLHlDQUF4Qjs7QUFDQSxXQUFPLEtBQUs0SCxNQUFMLENBQVlqTixLQUFaLEVBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTZXLFNBQU8sR0FBRztBQUNSLFNBQUtMLFdBQUwsQ0FBaUJuUixNQUFqQixDQUF3Qiw2Q0FBeEI7O0FBQ0EsV0FBTyxLQUFLdVIsUUFBTCxHQUFpQixLQUFLM0osTUFBTCxDQUFZbEcsS0FBWixLQUFzQixDQUE5QztBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFMkMsTUFBSSxHQUFHO0FBQ0wsU0FBSzhNLFdBQUwsQ0FBaUJuUixNQUFqQixDQUF3QiwwQ0FBeEI7O0FBQ0EsU0FBSzRILE1BQUwsQ0FBWWpOLEtBQVosR0FBb0IsRUFBRSxLQUFLNFcsUUFBM0I7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUUsYUFBVyxHQUFHO0FBQ1osU0FBS04sV0FBTCxDQUFpQm5SLE1BQWpCLENBQXdCLGlEQUF4Qjs7QUFDQSxXQUFPLEtBQUt1UixRQUFMLEtBQWtCLENBQUMsQ0FBMUI7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUcsVUFBUSxHQUFHO0FBQ1QsU0FBS1AsV0FBTCxDQUFpQm5SLE1BQWpCLENBQXdCLDhDQUF4Qjs7QUFDQSxTQUFLNEgsTUFBTCxDQUFZak4sS0FBWixHQUFvQixFQUFFLEtBQUs0VyxRQUEzQjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFNVcsT0FBSyxHQUFHO0FBQ04sU0FBS3dXLFdBQUwsQ0FBaUJuUixNQUFqQixDQUF3QiwyQ0FBeEI7O0FBQ0EsV0FBTyxLQUFLNEgsTUFBTCxDQUFZak4sS0FBWixNQUF1QixFQUE5QjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFZ1gsT0FBSyxHQUFHO0FBQ04sU0FBS1IsV0FBTCxDQUFpQm5SLE1BQWpCLENBQXdCLDJDQUF4Qjs7QUFDQSxTQUFLdVIsUUFBTCxHQUFnQixDQUFoQjtBQUNBLFdBQU8sS0FBSzVXLEtBQUwsR0FBYSxLQUFLNFcsUUFBbEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFSyxNQUFJLEdBQUc7QUFDTCxTQUFLVCxXQUFMLENBQWlCblIsTUFBakIsQ0FBd0IsMENBQXhCOztBQUNBLFNBQUt1UixRQUFMLEdBQWdCLEtBQUs3UCxLQUFMLEtBQWUsQ0FBL0I7QUFDQSxXQUFPLEtBQUsvRyxLQUFMLEdBQWEsS0FBSzRXLFFBQWxCLENBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTdQLE9BQUssR0FBRztBQUNOLFNBQUt5UCxXQUFMLENBQWlCblIsTUFBakIsQ0FBd0IsMkNBQXhCOztBQUNBLFdBQU8sS0FBSzRILE1BQUwsQ0FBWWxHLEtBQVosRUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VKLFFBQU0sQ0FBQ3hGLFFBQUQsRUFBVztBQUNmLFNBQUtxVixXQUFMLENBQWlCblIsTUFBakIsQ0FBd0IsNENBQXhCOztBQUNBLFNBQUttUixXQUFMLENBQWlCN1AsTUFBakIsQ0FBd0IsS0FBS2dRLFNBQTdCLEVBQXdDeFYsUUFBeEM7O0FBQ0EsV0FBTyxJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFcVIsU0FBTyxDQUFDclIsUUFBRCxFQUF5QjtBQUFBLFFBQWQrVixPQUFjLHVFQUFKLEVBQUk7O0FBQzlCLFNBQUtWLFdBQUwsQ0FBaUJuUixNQUFqQixDQUF3Qiw2Q0FBeEI7O0FBQ0EsU0FBSzRILE1BQUwsQ0FBWXVGLE9BQVosQ0FBb0JyUixRQUFwQixFQUE4QitWLE9BQTlCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUMsTUFBSSxHQUFHO0FBQ0wsV0FBTyxLQUFLQyxHQUFMLENBQVU5UCxJQUFELElBQVU7QUFDeEIsYUFBTyxJQUFJNk4sVUFBSixDQUFlN04sSUFBZixFQUFxQixLQUFLa1AsV0FBMUIsQ0FBUDtBQUNELEtBRk0sQ0FBUDtBQUdEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRVksS0FBRyxDQUFDalcsUUFBRCxFQUF5QjtBQUFBLFFBQWQrVixPQUFjLHVFQUFKLEVBQUk7O0FBQzFCLFNBQUtWLFdBQUwsQ0FBaUJuUixNQUFqQixDQUF3Qix5Q0FBeEI7O0FBQ0EsV0FBTyxLQUFLNEgsTUFBTCxDQUFZbUssR0FBWixDQUFnQmpXLFFBQWhCLEVBQTBCK1YsT0FBMUIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFRyxTQUFPLEdBQUc7QUFDUixTQUFLYixXQUFMLENBQWlCblIsTUFBakIsQ0FBd0IsNkNBQXhCOztBQUNBLFFBQUksS0FBS3VSLFFBQUwsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsV0FBS0EsUUFBTCxHQUFnQixDQUFoQjtBQUNEOztBQUNELFdBQU8sS0FBSzVXLEtBQUwsR0FBYSxLQUFLNFcsUUFBbEIsQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRXBRLFNBQU8sQ0FBQzhRLFNBQUQsRUFBWTtBQUNqQixTQUFLZCxXQUFMLENBQWlCblIsTUFBakIsQ0FBd0IsNkNBQXhCOztBQUNBLFdBQU8sS0FBSzRILE1BQUwsQ0FBWXpHLE9BQVosQ0FBb0I4USxTQUFwQixDQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFQyxnQkFBYyxDQUFDRCxTQUFELEVBQVk7QUFDeEIsU0FBS2QsV0FBTCxDQUFpQm5SLE1BQWpCLENBQXdCLG9EQUF4Qjs7QUFDQSxXQUFPLEtBQUs0SCxNQUFMLENBQVlzSyxjQUFaLENBQTJCRCxTQUEzQixDQUFQO0FBQ0Q7O0FBdk5zQixDOzs7Ozs7Ozs7OztBQ3RHekI1WCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDZSxjQUFZLEVBQUMsTUFBSUEsWUFBbEI7QUFBK0JDLGtCQUFnQixFQUFDLE1BQUlBLGdCQUFwRDtBQUFxRXNVLGNBQVksRUFBQyxNQUFJQSxZQUF0RjtBQUFtR3JVLFNBQU8sRUFBQyxNQUFJQTtBQUEvRyxDQUFkO0FBQXVJLElBQUlQLEtBQUo7QUFBVVgsTUFBTSxDQUFDSSxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTyxPQUFLLENBQUNOLENBQUQsRUFBRztBQUFDTSxTQUFLLEdBQUNOLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFakosTUFBTWEsT0FBTyxHQUFHO0FBQ2Q0VyxhQUFXLENBQUNDLEdBQUQsRUFBTTtBQUNmLFdBQU9BLEdBQUcsS0FBSyxLQUFLLENBQXBCO0FBQ0QsR0FIYTs7QUFJZG5ULFVBQVEsQ0FBQ21ULEdBQUQsRUFBTTtBQUNaLFFBQUksS0FBS0MsT0FBTCxDQUFhRCxHQUFiLEtBQXFCLEtBQUt0VCxVQUFMLENBQWdCc1QsR0FBaEIsQ0FBekIsRUFBK0M7QUFDN0MsYUFBTyxLQUFQO0FBQ0Q7O0FBQ0QsV0FBT0EsR0FBRyxLQUFLNVIsTUFBTSxDQUFDNFIsR0FBRCxDQUFyQjtBQUNELEdBVGE7O0FBVWRDLFNBQU8sQ0FBQ0QsR0FBRCxFQUFNO0FBQ1gsV0FBT0UsS0FBSyxDQUFDRCxPQUFOLENBQWNELEdBQWQsQ0FBUDtBQUNELEdBWmE7O0FBYWRoVSxXQUFTLENBQUNnVSxHQUFELEVBQU07QUFDYixXQUFPQSxHQUFHLEtBQUssSUFBUixJQUFnQkEsR0FBRyxLQUFLLEtBQXhCLElBQWlDNVIsTUFBTSxDQUFDK1IsU0FBUCxDQUFpQnROLFFBQWpCLENBQTBCcEMsSUFBMUIsQ0FBK0J1UCxHQUEvQixNQUF3QyxrQkFBaEY7QUFDRCxHQWZhOztBQWdCZHRULFlBQVUsQ0FBQ3NULEdBQUQsRUFBTTtBQUNkLFdBQU8sT0FBT0EsR0FBUCxLQUFlLFVBQWYsSUFBNkIsS0FBcEM7QUFDRCxHQWxCYTs7QUFtQmRJLFNBQU8sQ0FBQ0osR0FBRCxFQUFNO0FBQ1gsUUFBSSxLQUFLSyxNQUFMLENBQVlMLEdBQVosQ0FBSixFQUFzQjtBQUNwQixhQUFPLEtBQVA7QUFDRDs7QUFDRCxRQUFJLEtBQUtuVCxRQUFMLENBQWNtVCxHQUFkLENBQUosRUFBd0I7QUFDdEIsYUFBTyxDQUFDNVIsTUFBTSxDQUFDcUcsSUFBUCxDQUFZdUwsR0FBWixFQUFpQmhQLE1BQXpCO0FBQ0Q7O0FBQ0QsUUFBSSxLQUFLaVAsT0FBTCxDQUFhRCxHQUFiLEtBQXFCLEtBQUs3VCxRQUFMLENBQWM2VCxHQUFkLENBQXpCLEVBQTZDO0FBQzNDLGFBQU8sQ0FBQ0EsR0FBRyxDQUFDaFAsTUFBWjtBQUNEOztBQUNELFdBQU8sS0FBUDtBQUNELEdBOUJhOztBQStCZGdELE9BQUssQ0FBQ2dNLEdBQUQsRUFBTTtBQUNULFFBQUksQ0FBQyxLQUFLblQsUUFBTCxDQUFjbVQsR0FBZCxDQUFMLEVBQXlCLE9BQU9BLEdBQVA7QUFDekIsV0FBTyxLQUFLQyxPQUFMLENBQWFELEdBQWIsSUFBb0JBLEdBQUcsQ0FBQ00sS0FBSixFQUFwQixHQUFrQ2xTLE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBYyxFQUFkLEVBQWtCc1AsR0FBbEIsQ0FBekM7QUFDRCxHQWxDYTs7QUFtQ2RySSxLQUFHLENBQUM0SSxJQUFELEVBQU85USxJQUFQLEVBQWE7QUFDZCxRQUFJdVEsR0FBRyxHQUFHTyxJQUFWOztBQUNBLFFBQUksQ0FBQyxLQUFLMVQsUUFBTCxDQUFjbVQsR0FBZCxDQUFMLEVBQXlCO0FBQ3ZCLGFBQU8sS0FBUDtBQUNEOztBQUNELFFBQUksQ0FBQyxLQUFLQyxPQUFMLENBQWF4USxJQUFiLENBQUwsRUFBeUI7QUFDdkIsYUFBTyxLQUFLNUMsUUFBTCxDQUFjbVQsR0FBZCxLQUFzQjVSLE1BQU0sQ0FBQytSLFNBQVAsQ0FBaUJLLGNBQWpCLENBQWdDL1AsSUFBaEMsQ0FBcUN1UCxHQUFyQyxFQUEwQ3ZRLElBQTFDLENBQTdCO0FBQ0Q7O0FBRUQsVUFBTXVCLE1BQU0sR0FBR3ZCLElBQUksQ0FBQ3VCLE1BQXBCOztBQUNBLFNBQUssSUFBSXlQLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUd6UCxNQUFwQixFQUE0QnlQLENBQUMsRUFBN0IsRUFBaUM7QUFDL0IsVUFBSSxDQUFDclMsTUFBTSxDQUFDK1IsU0FBUCxDQUFpQkssY0FBakIsQ0FBZ0MvUCxJQUFoQyxDQUFxQ3VQLEdBQXJDLEVBQTBDdlEsSUFBSSxDQUFDZ1IsQ0FBRCxDQUE5QyxDQUFMLEVBQXlEO0FBQ3ZELGVBQU8sS0FBUDtBQUNEOztBQUNEVCxTQUFHLEdBQUdBLEdBQUcsQ0FBQ3ZRLElBQUksQ0FBQ2dSLENBQUQsQ0FBTCxDQUFUO0FBQ0Q7O0FBQ0QsV0FBTyxDQUFDLENBQUN6UCxNQUFUO0FBQ0QsR0FwRGE7O0FBcURkb0QsTUFBSSxDQUFDNEwsR0FBRCxFQUFlO0FBQ2pCLFVBQU1VLEtBQUssR0FBR3RTLE1BQU0sQ0FBQ3NDLE1BQVAsQ0FBYyxFQUFkLEVBQWtCc1AsR0FBbEIsQ0FBZDs7QUFEaUIsc0NBQU52TCxJQUFNO0FBQU5BLFVBQU07QUFBQTs7QUFFakIsU0FBSyxJQUFJZ00sQ0FBQyxHQUFHaE0sSUFBSSxDQUFDekQsTUFBTCxHQUFjLENBQTNCLEVBQThCeVAsQ0FBQyxJQUFJLENBQW5DLEVBQXNDQSxDQUFDLEVBQXZDLEVBQTJDO0FBQ3pDLGFBQU9DLEtBQUssQ0FBQ2pNLElBQUksQ0FBQ2dNLENBQUQsQ0FBTCxDQUFaO0FBQ0Q7O0FBRUQsV0FBT0MsS0FBUDtBQUNELEdBNURhOztBQTZEZEMsS0FBRyxFQUFFMU0sSUFBSSxDQUFDME0sR0E3REk7O0FBOERkQyxVQUFRLENBQUNDLElBQUQsRUFBT0MsSUFBUCxFQUEyQjtBQUFBLFFBQWR0QyxPQUFjLHVFQUFKLEVBQUk7QUFDakMsUUFBSWMsUUFBUSxHQUFHLENBQWY7QUFDQSxRQUFJeEcsT0FBTyxHQUFHLElBQWQ7QUFDQSxRQUFJMUksTUFBSjtBQUNBLFVBQU0yUSxJQUFJLEdBQUcsSUFBYjtBQUNBLFFBQUloVixJQUFKO0FBQ0EsUUFBSWlWLElBQUo7O0FBRUEsVUFBTUMsS0FBSyxHQUFHLE1BQU07QUFDbEIzQixjQUFRLEdBQUdkLE9BQU8sQ0FBQzBDLE9BQVIsS0FBb0IsS0FBcEIsR0FBNEIsQ0FBNUIsR0FBZ0NILElBQUksQ0FBQ0osR0FBTCxFQUEzQztBQUNBN0gsYUFBTyxHQUFHLElBQVY7QUFDQTFJLFlBQU0sR0FBR3lRLElBQUksQ0FBQ3BULEtBQUwsQ0FBVzFCLElBQVgsRUFBaUJpVixJQUFqQixDQUFUOztBQUNBLFVBQUksQ0FBQ2xJLE9BQUwsRUFBYztBQUNaL00sWUFBSSxHQUFHaVYsSUFBSSxHQUFHLElBQWQ7QUFDRDtBQUNGLEtBUEQ7O0FBU0EsVUFBTUcsU0FBUyxHQUFHLFlBQVk7QUFDNUIsWUFBTVIsR0FBRyxHQUFHSSxJQUFJLENBQUNKLEdBQUwsRUFBWjtBQUNBLFVBQUksQ0FBQ3JCLFFBQUQsSUFBYWQsT0FBTyxDQUFDMEMsT0FBUixLQUFvQixLQUFyQyxFQUE0QzVCLFFBQVEsR0FBR3FCLEdBQVg7QUFDNUMsWUFBTVMsU0FBUyxHQUFHTixJQUFJLElBQUlILEdBQUcsR0FBR3JCLFFBQVYsQ0FBdEI7QUFDQXZULFVBQUksR0FBRyxJQUFQO0FBQ0FpVixVQUFJLEdBQUd0VCxTQUFQOztBQUNBLFVBQUkwVCxTQUFTLElBQUksQ0FBYixJQUFrQkEsU0FBUyxHQUFHTixJQUFsQyxFQUF3QztBQUN0QyxZQUFJaEksT0FBSixFQUFhO0FBQ1hTLHNCQUFZLENBQUNULE9BQUQsQ0FBWjtBQUNBQSxpQkFBTyxHQUFHLElBQVY7QUFDRDs7QUFDRHdHLGdCQUFRLEdBQUdxQixHQUFYO0FBQ0F2USxjQUFNLEdBQUd5USxJQUFJLENBQUNwVCxLQUFMLENBQVcxQixJQUFYLEVBQWlCaVYsSUFBakIsQ0FBVDs7QUFDQSxZQUFJLENBQUNsSSxPQUFMLEVBQWM7QUFDWi9NLGNBQUksR0FBR2lWLElBQUksR0FBRyxJQUFkO0FBQ0Q7QUFDRixPQVZELE1BVU8sSUFBSSxDQUFDbEksT0FBRCxJQUFZMEYsT0FBTyxDQUFDNkMsUUFBUixLQUFxQixLQUFyQyxFQUE0QztBQUNqRHZJLGVBQU8sR0FBR3RFLFVBQVUsQ0FBQ3lNLEtBQUQsRUFBUUcsU0FBUixDQUFwQjtBQUNEOztBQUNELGFBQU9oUixNQUFQO0FBQ0QsS0FwQkQ7O0FBc0JBK1EsYUFBUyxDQUFDRyxNQUFWLEdBQW1CLE1BQU07QUFDdkIvSCxrQkFBWSxDQUFDVCxPQUFELENBQVo7QUFDQXdHLGNBQVEsR0FBRyxDQUFYO0FBQ0F4RyxhQUFPLEdBQUcvTSxJQUFJLEdBQUdpVixJQUFJLEdBQUcsSUFBeEI7QUFDRCxLQUpEOztBQU1BLFdBQU9HLFNBQVA7QUFDRDs7QUE1R2EsQ0FBaEI7QUErR0EsTUFBTUksUUFBUSxHQUFHLENBQUMsUUFBRCxFQUFXLFFBQVgsRUFBcUIsTUFBckIsQ0FBakI7O0FBQ0EsS0FBSyxJQUFJZCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHYyxRQUFRLENBQUN2USxNQUE3QixFQUFxQ3lQLENBQUMsRUFBdEMsRUFBMEM7QUFDeEN0WCxTQUFPLENBQUMsT0FBT29ZLFFBQVEsQ0FBQ2QsQ0FBRCxDQUFoQixDQUFQLEdBQThCLFVBQVVULEdBQVYsRUFBZTtBQUMzQyxXQUFPNVIsTUFBTSxDQUFDK1IsU0FBUCxDQUFpQnROLFFBQWpCLENBQTBCcEMsSUFBMUIsQ0FBK0J1UCxHQUEvQixNQUF3QyxhQUFhdUIsUUFBUSxDQUFDZCxDQUFELENBQXJCLEdBQTJCLEdBQTFFO0FBQ0QsR0FGRDtBQUdEO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxNQUFNeFgsWUFBWSxHQUFHLFVBQVMrVyxHQUFULEVBQWM7QUFDakMsT0FBSyxJQUFJbkQsR0FBVCxJQUFnQm1ELEdBQWhCLEVBQXFCO0FBQ25CLFFBQUk3VyxPQUFPLENBQUNnRCxRQUFSLENBQWlCNlQsR0FBRyxDQUFDbkQsR0FBRCxDQUFwQixLQUE4Qm1ELEdBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxDQUFTMUssUUFBVCxDQUFrQixpQkFBbEIsQ0FBbEMsRUFBd0U7QUFDdEU2TixTQUFHLENBQUNuRCxHQUFELENBQUgsR0FBV21ELEdBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxDQUFTcFEsT0FBVCxDQUFpQixpQkFBakIsRUFBb0MsRUFBcEMsQ0FBWDtBQUNBdVQsU0FBRyxDQUFDbkQsR0FBRCxDQUFILEdBQVcsSUFBSTVJLElBQUosQ0FBU3JILFFBQVEsQ0FBQ29ULEdBQUcsQ0FBQ25ELEdBQUQsQ0FBSixDQUFqQixDQUFYO0FBQ0QsS0FIRCxNQUdPLElBQUkxVCxPQUFPLENBQUMwRCxRQUFSLENBQWlCbVQsR0FBRyxDQUFDbkQsR0FBRCxDQUFwQixDQUFKLEVBQWdDO0FBQ3JDbUQsU0FBRyxDQUFDbkQsR0FBRCxDQUFILEdBQVc1VCxZQUFZLENBQUMrVyxHQUFHLENBQUNuRCxHQUFELENBQUosQ0FBdkI7QUFDRCxLQUZNLE1BRUEsSUFBSTFULE9BQU8sQ0FBQzhXLE9BQVIsQ0FBZ0JELEdBQUcsQ0FBQ25ELEdBQUQsQ0FBbkIsQ0FBSixFQUErQjtBQUNwQyxVQUFJdlUsQ0FBSjs7QUFDQSxXQUFLLElBQUltWSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHVCxHQUFHLENBQUNuRCxHQUFELENBQUgsQ0FBUzdMLE1BQTdCLEVBQXFDeVAsQ0FBQyxFQUF0QyxFQUEwQztBQUN4Q25ZLFNBQUMsR0FBRzBYLEdBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxDQUFTNEQsQ0FBVCxDQUFKOztBQUNBLFlBQUl0WCxPQUFPLENBQUMwRCxRQUFSLENBQWlCdkUsQ0FBakIsQ0FBSixFQUF5QjtBQUN2QjBYLGFBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxDQUFTNEQsQ0FBVCxJQUFjeFgsWUFBWSxDQUFDWCxDQUFELENBQTFCO0FBQ0QsU0FGRCxNQUVPLElBQUlhLE9BQU8sQ0FBQ2dELFFBQVIsQ0FBaUI3RCxDQUFqQixLQUF1QkEsQ0FBQyxDQUFDNkosUUFBRixDQUFXLGlCQUFYLENBQTNCLEVBQTBEO0FBQy9EN0osV0FBQyxHQUFHQSxDQUFDLENBQUNtRSxPQUFGLENBQVUsaUJBQVYsRUFBNkIsRUFBN0IsQ0FBSjtBQUNBdVQsYUFBRyxDQUFDbkQsR0FBRCxDQUFILENBQVM0RCxDQUFULElBQWMsSUFBSXhNLElBQUosQ0FBU3JILFFBQVEsQ0FBQ3RFLENBQUQsQ0FBakIsQ0FBZDtBQUNEO0FBQ0Y7QUFDRjtBQUNGOztBQUNELFNBQU8wWCxHQUFQO0FBQ0QsQ0FyQkQ7QUF1QkE7QUFDQTtBQUNBOzs7QUFDQSxNQUFNOVcsZ0JBQWdCLEdBQUcsVUFBUzhXLEdBQVQsRUFBYztBQUNyQyxPQUFLLElBQUluRCxHQUFULElBQWdCbUQsR0FBaEIsRUFBcUI7QUFDbkIsUUFBSTdXLE9BQU8sQ0FBQ2tYLE1BQVIsQ0FBZUwsR0FBRyxDQUFDbkQsR0FBRCxDQUFsQixDQUFKLEVBQThCO0FBQzVCbUQsU0FBRyxDQUFDbkQsR0FBRCxDQUFILDRCQUE2QixDQUFDbUQsR0FBRyxDQUFDbkQsR0FBRCxDQUFqQztBQUNELEtBRkQsTUFFTyxJQUFJMVQsT0FBTyxDQUFDMEQsUUFBUixDQUFpQm1ULEdBQUcsQ0FBQ25ELEdBQUQsQ0FBcEIsQ0FBSixFQUFnQztBQUNyQ21ELFNBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxHQUFXM1QsZ0JBQWdCLENBQUM4VyxHQUFHLENBQUNuRCxHQUFELENBQUosQ0FBM0I7QUFDRCxLQUZNLE1BRUEsSUFBSTFULE9BQU8sQ0FBQzhXLE9BQVIsQ0FBZ0JELEdBQUcsQ0FBQ25ELEdBQUQsQ0FBbkIsQ0FBSixFQUErQjtBQUNwQyxVQUFJdlUsQ0FBSjs7QUFDQSxXQUFLLElBQUltWSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHVCxHQUFHLENBQUNuRCxHQUFELENBQUgsQ0FBUzdMLE1BQTdCLEVBQXFDeVAsQ0FBQyxFQUF0QyxFQUEwQztBQUN4Q25ZLFNBQUMsR0FBRzBYLEdBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxDQUFTNEQsQ0FBVCxDQUFKOztBQUNBLFlBQUl0WCxPQUFPLENBQUMwRCxRQUFSLENBQWlCdkUsQ0FBakIsQ0FBSixFQUF5QjtBQUN2QjBYLGFBQUcsQ0FBQ25ELEdBQUQsQ0FBSCxDQUFTNEQsQ0FBVCxJQUFjdlgsZ0JBQWdCLENBQUNaLENBQUQsQ0FBOUI7QUFDRCxTQUZELE1BRU8sSUFBSWEsT0FBTyxDQUFDa1gsTUFBUixDQUFlL1gsQ0FBZixDQUFKLEVBQXVCO0FBQzVCMFgsYUFBRyxDQUFDbkQsR0FBRCxDQUFILENBQVM0RCxDQUFULDZCQUFnQyxDQUFDblksQ0FBakM7QUFDRDtBQUNGO0FBQ0Y7QUFDRjs7QUFDRCxTQUFPMFgsR0FBUDtBQUNELENBbkJEO0FBcUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFNeEMsWUFBWSxHQUFHLFVBQUN4USxPQUFELEVBQTBGO0FBQUEsTUFBaEZpSSxPQUFnRix1RUFBdEUsVUFBc0U7O0FBQUEsTUFBMUR1TSxRQUEwRCx1RUFBL0MsQ0FBQ0MseUJBQXlCLElBQUksRUFBOUIsRUFBa0NDLFFBQWE7O0FBQzdHOVksT0FBSyxDQUFDb0UsT0FBRCxFQUFVb0IsTUFBVixDQUFMO0FBQ0F4RixPQUFLLENBQUNxTSxPQUFELEVBQVUxSSxNQUFWLENBQUw7QUFDQSxNQUFJa1MsT0FBTyxHQUFHK0MsUUFBZDs7QUFFQSxNQUFJLENBQUNyWSxPQUFPLENBQUNnRCxRQUFSLENBQWlCc1MsT0FBakIsQ0FBTCxFQUFnQztBQUM5QkEsV0FBTyxHQUFHLENBQUNnRCx5QkFBeUIsSUFBSSxFQUE5QixFQUFrQ0MsUUFBbEMsSUFBOEMsR0FBeEQ7QUFDRDs7QUFFRCxRQUFNQyxLQUFLLEdBQUdsRCxPQUFPLENBQUNoUyxPQUFSLENBQWdCLE1BQWhCLEVBQXdCLEVBQXhCLENBQWQ7O0FBQ0EsUUFBTWdQLElBQUksR0FBSXpPLE9BQU8sQ0FBQzRNLFFBQVIsSUFBb0I1TSxPQUFPLENBQUM0TSxRQUFSLENBQWlCM0UsT0FBakIsQ0FBckIsSUFBbURqSSxPQUFuRCxJQUE4RCxFQUEzRTtBQUVBLE1BQUl3SixHQUFKOztBQUNBLE1BQUlyTixPQUFPLENBQUNnRCxRQUFSLENBQWlCc1AsSUFBSSxDQUFDcEYsU0FBdEIsQ0FBSixFQUFzQztBQUNwQ0csT0FBRyxjQUFPaUYsSUFBSSxDQUFDcEYsU0FBTCxDQUFlNUosT0FBZixDQUF1QixLQUF2QixFQUE4QixFQUE5QixDQUFQLENBQUg7QUFDRCxHQUZELE1BRU87QUFDTCtKLE9BQUcsR0FBRyxFQUFOO0FBQ0Q7O0FBRUQsTUFBSXhKLE9BQU8sQ0FBQy9DLE1BQVIsS0FBbUIsSUFBdkIsRUFBNkI7QUFDM0IsV0FBTzBYLEtBQUssSUFBSTFNLE9BQU8sS0FBSyxVQUFaLGFBQTRCakksT0FBTyxDQUFDc1IsY0FBcEMsY0FBc0R0UixPQUFPLENBQUM2QixHQUE5RCxTQUFvRTJILEdBQXBFLGNBQStFeEosT0FBTyxDQUFDc1IsY0FBdkYsY0FBeUdySixPQUF6RyxjQUFvSGpJLE9BQU8sQ0FBQzZCLEdBQTVILFNBQWtJMkgsR0FBbEksQ0FBSixDQUFaO0FBQ0Q7O0FBQ0QsbUJBQVVtTCxLQUFWLFNBQWtCM1UsT0FBTyxDQUFDc1IsY0FBMUIsY0FBNEN0UixPQUFPLENBQUN1UixlQUFwRCxjQUF1RXZSLE9BQU8sQ0FBQzZCLEdBQS9FLGNBQXNGb0csT0FBdEYsY0FBaUdqSSxPQUFPLENBQUM2QixHQUF6RyxTQUErRzJILEdBQS9HO0FBQ0QsQ0F2QkQsQzs7Ozs7Ozs7Ozs7QUNwTEF2TyxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDYSxTQUFPLEVBQUMsTUFBSUQ7QUFBYixDQUFkO0FBQXlDLElBQUlPLEVBQUo7QUFBT3BCLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZLFVBQVosRUFBdUI7QUFBQ1UsU0FBTyxDQUFDVCxDQUFELEVBQUc7QUFBQ2UsTUFBRSxHQUFDZixDQUFIO0FBQUs7O0FBQWpCLENBQXZCLEVBQTBDLENBQTFDO0FBQTZDLElBQUlHLE1BQUo7QUFBV1IsTUFBTSxDQUFDSSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDSSxRQUFNLENBQUNILENBQUQsRUFBRztBQUFDRyxVQUFNLEdBQUNILENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWEsT0FBSjtBQUFZbEIsTUFBTSxDQUFDSSxJQUFQLENBQVksVUFBWixFQUF1QjtBQUFDYyxTQUFPLENBQUNiLENBQUQsRUFBRztBQUFDYSxXQUFPLEdBQUNiLENBQVI7QUFBVTs7QUFBdEIsQ0FBdkIsRUFBK0MsQ0FBL0M7O0FBR3pLLE1BQU1xQixJQUFJLEdBQUcsTUFBTSxDQUFFLENBQXJCO0FBRUE7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU1ILEtBQUssR0FBS2YsTUFBTSxDQUFDZ0IsZUFBUCxDQUF1QkMsUUFBUSxJQUFJQSxRQUFRLEVBQTNDLENBQWhCO0FBQ0EsTUFBTWtZLE9BQU8sR0FBRyxFQUFoQjtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNlLE1BQU05WSxXQUFOLENBQWtCO0FBQy9CYyxhQUFXLENBQUM2RixJQUFELEVBQU95RSxTQUFQLEVBQWtCckUsSUFBbEIsRUFBd0J0RixXQUF4QixFQUFxQztBQUM5QyxTQUFLa0YsSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBS3lFLFNBQUwsR0FBaUJBLFNBQWpCO0FBQ0EsU0FBS3JFLElBQUwsR0FBWUEsSUFBWjtBQUNBLFNBQUt0RixXQUFMLEdBQW1CQSxXQUFuQjs7QUFDQSxRQUFJLENBQUMsS0FBS2tGLElBQU4sSUFBYyxDQUFDdEcsT0FBTyxDQUFDZ0QsUUFBUixDQUFpQixLQUFLc0QsSUFBdEIsQ0FBbkIsRUFBZ0Q7QUFDOUM7QUFDRDs7QUFFRCxTQUFLb1MsRUFBTCxHQUFxQixJQUFyQjtBQUNBLFNBQUtDLGFBQUwsR0FBcUIsQ0FBckI7QUFDQSxTQUFLL1IsS0FBTCxHQUFxQixLQUFyQjtBQUNBLFNBQUtELE9BQUwsR0FBcUIsS0FBckI7O0FBRUEsUUFBSThSLE9BQU8sQ0FBQyxLQUFLblMsSUFBTixDQUFQLElBQXNCLENBQUNtUyxPQUFPLENBQUMsS0FBS25TLElBQU4sQ0FBUCxDQUFtQk0sS0FBMUMsSUFBbUQsQ0FBQzZSLE9BQU8sQ0FBQyxLQUFLblMsSUFBTixDQUFQLENBQW1CSyxPQUEzRSxFQUFvRjtBQUNsRixXQUFLK1IsRUFBTCxHQUFVRCxPQUFPLENBQUMsS0FBS25TLElBQU4sQ0FBUCxDQUFtQm9TLEVBQTdCO0FBQ0EsV0FBS0MsYUFBTCxHQUFxQkYsT0FBTyxDQUFDLEtBQUtuUyxJQUFOLENBQVAsQ0FBbUJxUyxhQUF4QztBQUNELEtBSEQsTUFHTztBQUNMelksUUFBRSxDQUFDZ1AsVUFBSCxDQUFjLEtBQUs1SSxJQUFuQixFQUEwQjZJLE9BQUQsSUFBYTtBQUNwQzlPLGFBQUssQ0FBQyxNQUFNO0FBQ1YsY0FBSThPLE9BQUosRUFBYTtBQUNYLGlCQUFLL0ksS0FBTDtBQUNBLGtCQUFNLElBQUk5RyxNQUFNLENBQUMrRCxLQUFYLENBQWlCLEdBQWpCLEVBQXNCLDJEQUEyRDhMLE9BQWpGLENBQU47QUFDRCxXQUhELE1BR087QUFDTGpQLGNBQUUsQ0FBQzBZLElBQUgsQ0FBUSxLQUFLdFMsSUFBYixFQUFtQixJQUFuQixFQUF5QixLQUFLbEYsV0FBOUIsRUFBMkMsQ0FBQ3lYLE1BQUQsRUFBU0gsRUFBVCxLQUFnQjtBQUN6RHJZLG1CQUFLLENBQUMsTUFBTTtBQUNWLG9CQUFJd1ksTUFBSixFQUFZO0FBQ1YsdUJBQUt6UyxLQUFMO0FBQ0Esd0JBQU0sSUFBSTlHLE1BQU0sQ0FBQytELEtBQVgsQ0FBaUIsR0FBakIsRUFBc0Isa0VBQWtFd1YsTUFBeEYsQ0FBTjtBQUNELGlCQUhELE1BR087QUFDTCx1QkFBS0gsRUFBTCxHQUFVQSxFQUFWO0FBQ0FELHlCQUFPLENBQUMsS0FBS25TLElBQU4sQ0FBUCxHQUFxQixJQUFyQjtBQUNEO0FBQ0YsZUFSSSxDQUFMO0FBU0QsYUFWRDtBQVdEO0FBQ0YsU0FqQkksQ0FBTDtBQWtCRCxPQW5CRDtBQW9CRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRTBILE9BQUssQ0FBQzhLLEdBQUQsRUFBTUMsS0FBTixFQUFheFksUUFBYixFQUF1QjtBQUMxQixRQUFJLENBQUMsS0FBS29HLE9BQU4sSUFBaUIsQ0FBQyxLQUFLQyxLQUEzQixFQUFrQztBQUNoQyxVQUFJLEtBQUs4UixFQUFULEVBQWE7QUFDWHhZLFVBQUUsQ0FBQzhOLEtBQUgsQ0FBUyxLQUFLMEssRUFBZCxFQUFrQkssS0FBbEIsRUFBeUIsQ0FBekIsRUFBNEJBLEtBQUssQ0FBQ2xSLE1BQWxDLEVBQTBDLENBQUNpUixHQUFHLEdBQUcsQ0FBUCxJQUFZLEtBQUtwUyxJQUFMLENBQVV6RixTQUFoRSxFQUEyRSxDQUFDMkQsS0FBRCxFQUFRb1UsT0FBUixFQUFpQm5LLE1BQWpCLEtBQTRCO0FBQ3JHeE8sZUFBSyxDQUFDLE1BQU07QUFDVkUsb0JBQVEsSUFBSUEsUUFBUSxDQUFDcUUsS0FBRCxFQUFRb1UsT0FBUixFQUFpQm5LLE1BQWpCLENBQXBCOztBQUNBLGdCQUFJakssS0FBSixFQUFXO0FBQ1QyRSxxQkFBTyxDQUFDQyxJQUFSLENBQWEsa0RBQWIsRUFBaUU1RSxLQUFqRTtBQUNBLG1CQUFLd0IsS0FBTDtBQUNELGFBSEQsTUFHTztBQUNMLGdCQUFFLEtBQUt1UyxhQUFQO0FBQ0Q7QUFDRixXQVJJLENBQUw7QUFTRCxTQVZEO0FBV0QsT0FaRCxNQVlPO0FBQ0xyWixjQUFNLENBQUMrTCxVQUFQLENBQWtCLE1BQU07QUFDdEIsZUFBSzJDLEtBQUwsQ0FBVzhLLEdBQVgsRUFBZ0JDLEtBQWhCLEVBQXVCeFksUUFBdkI7QUFDRCxTQUZELEVBRUcsRUFGSDtBQUdEO0FBQ0Y7O0FBQ0QsV0FBTyxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UyRixLQUFHLENBQUMzRixRQUFELEVBQVc7QUFDWixRQUFJLENBQUMsS0FBS29HLE9BQU4sSUFBaUIsQ0FBQyxLQUFLQyxLQUEzQixFQUFrQztBQUNoQyxVQUFJLEtBQUsrUixhQUFMLEtBQXVCLEtBQUs1TixTQUFoQyxFQUEyQztBQUN6QzdLLFVBQUUsQ0FBQytULEtBQUgsQ0FBUyxLQUFLeUUsRUFBZCxFQUFrQixNQUFNO0FBQ3RCclksZUFBSyxDQUFDLE1BQU07QUFDVixtQkFBT29ZLE9BQU8sQ0FBQyxLQUFLblMsSUFBTixDQUFkO0FBQ0EsaUJBQUtNLEtBQUwsR0FBYSxJQUFiO0FBQ0FyRyxvQkFBUSxJQUFJQSxRQUFRLENBQUMsS0FBSyxDQUFOLEVBQVMsSUFBVCxDQUFwQjtBQUNELFdBSkksQ0FBTDtBQUtELFNBTkQ7QUFPQSxlQUFPLElBQVA7QUFDRDs7QUFFREwsUUFBRSxDQUFDb1EsSUFBSCxDQUFRLEtBQUtoSyxJQUFiLEVBQW1CLENBQUMxQixLQUFELEVBQVEwTCxJQUFSLEtBQWlCO0FBQ2xDalEsYUFBSyxDQUFDLE1BQU07QUFDVixjQUFJLENBQUN1RSxLQUFELElBQVUwTCxJQUFkLEVBQW9CO0FBQ2xCLGlCQUFLcUksYUFBTCxHQUFxQjdWLElBQUksQ0FBQ21XLElBQUwsQ0FBVTNJLElBQUksQ0FBQ3JNLElBQUwsR0FBWSxLQUFLeUMsSUFBTCxDQUFVekYsU0FBaEMsQ0FBckI7QUFDRDs7QUFFRCxpQkFBTzNCLE1BQU0sQ0FBQytMLFVBQVAsQ0FBa0IsTUFBTTtBQUM3QixpQkFBS25GLEdBQUwsQ0FBUzNGLFFBQVQ7QUFDRCxXQUZNLEVBRUosRUFGSSxDQUFQO0FBR0QsU0FSSSxDQUFMO0FBU0QsT0FWRDtBQVdELEtBdkJELE1BdUJPO0FBQ0xBLGNBQVEsSUFBSUEsUUFBUSxDQUFDLEtBQUssQ0FBTixFQUFTLEtBQUtxRyxLQUFkLENBQXBCO0FBQ0Q7O0FBQ0QsV0FBTyxLQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0VSLE9BQUssQ0FBQzdGLFFBQUQsRUFBVztBQUNkLFNBQUtvRyxPQUFMLEdBQWUsSUFBZjtBQUNBLFdBQU84UixPQUFPLENBQUMsS0FBS25TLElBQU4sQ0FBZDtBQUNBcEcsTUFBRSxDQUFDME0sTUFBSCxDQUFVLEtBQUt0RyxJQUFmLEVBQXNCL0YsUUFBUSxJQUFJQyxJQUFsQztBQUNBLFdBQU8sSUFBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRXlGLE1BQUksR0FBRztBQUNMLFNBQUtVLE9BQUwsR0FBZSxJQUFmO0FBQ0EsV0FBTzhSLE9BQU8sQ0FBQyxLQUFLblMsSUFBTixDQUFkO0FBQ0EsV0FBTyxJQUFQO0FBQ0Q7O0FBdkk4QixDIiwiZmlsZSI6Ii9wYWNrYWdlcy9vc3RyaW9fZmlsZXMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBmZXRjaCB9IGZyb20gJ21ldGVvci9mZXRjaCc7XG5pbXBvcnQgeyBXZWJBcHAgfSBmcm9tICdtZXRlb3Ivd2ViYXBwJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgUmFuZG9tIH0gZnJvbSAnbWV0ZW9yL3JhbmRvbSc7XG5pbXBvcnQgeyBDb29raWVzIH0gZnJvbSAnbWV0ZW9yL29zdHJpbzpjb29raWVzJztcbmltcG9ydCB7IGNoZWNrLCBNYXRjaCB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5cbmltcG9ydCBXcml0ZVN0cmVhbSBmcm9tICcuL3dyaXRlLXN0cmVhbS5qcyc7XG5pbXBvcnQgRmlsZXNDb2xsZWN0aW9uQ29yZSBmcm9tICcuL2NvcmUuanMnO1xuaW1wb3J0IHsgZml4SlNPTlBhcnNlLCBmaXhKU09OU3RyaW5naWZ5LCBoZWxwZXJzIH0gZnJvbSAnLi9saWIuanMnO1xuXG5pbXBvcnQgQWJvcnRDb250cm9sbGVyIGZyb20gJ2Fib3J0LWNvbnRyb2xsZXInO1xuaW1wb3J0IGZzIGZyb20gJ2ZzLWV4dHJhJztcbmltcG9ydCBub2RlUXMgZnJvbSAncXVlcnlzdHJpbmcnO1xuaW1wb3J0IG5vZGVQYXRoIGZyb20gJ3BhdGgnO1xuXG4vKlxuICogQGNvbnN0IHtPYmplY3R9IGJvdW5kICAtIE1ldGVvci5iaW5kRW52aXJvbm1lbnQgKEZpYmVyIHdyYXBwZXIpXG4gKiBAY29uc3Qge0Z1bmN0aW9ufSBOT09QIC0gTm8gT3BlcmF0aW9uIGZ1bmN0aW9uLCBwbGFjZWhvbGRlciBmb3IgcmVxdWlyZWQgY2FsbGJhY2tzXG4gKi9cbmNvbnN0IGJvdW5kID0gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChjYWxsYmFjayA9PiBjYWxsYmFjaygpKTtcbmNvbnN0IE5PT1AgID0gKCkgPT4geyAgfTtcblxuLypcbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQGNsYXNzIEZpbGVzQ29sbGVjdGlvblxuICogQHBhcmFtIGNvbmZpZyAgICAgICAgICAge09iamVjdH0gICAtIFtCb3RoXSAgIENvbmZpZ3VyYXRpb24gb2JqZWN0IHdpdGggbmV4dCBwcm9wZXJ0aWVzOlxuICogQHBhcmFtIGNvbmZpZy5kZWJ1ZyAgICAge0Jvb2xlYW59ICAtIFtCb3RoXSAgIFR1cm4gb24vb2YgZGVidWdnaW5nIGFuZCBleHRyYSBsb2dnaW5nXG4gKiBAcGFyYW0gY29uZmlnLnNjaGVtYSAgICB7T2JqZWN0fSAgIC0gW0JvdGhdICAgQ29sbGVjdGlvbiBTY2hlbWFcbiAqIEBwYXJhbSBjb25maWcucHVibGljICAgIHtCb29sZWFufSAgLSBbQm90aF0gICBTdG9yZSBmaWxlcyBpbiBmb2xkZXIgYWNjZXNzaWJsZSBmb3IgcHJveHkgc2VydmVycywgZm9yIGxpbWl0cywgYW5kIG1vcmUgLSByZWFkIGRvY3NcbiAqIEBwYXJhbSBjb25maWcuc3RyaWN0ICAgIHtCb29sZWFufSAgLSBbU2VydmVyXSBTdHJpY3QgbW9kZSBmb3IgcGFydGlhbCBjb250ZW50LCBpZiBpcyBgdHJ1ZWAgc2VydmVyIHdpbGwgcmV0dXJuIGA0MTZgIHJlc3BvbnNlIGNvZGUsIHdoZW4gYHJhbmdlYCBpcyBub3Qgc3BlY2lmaWVkLCBvdGhlcndpc2Ugc2VydmVyIHJldHVybiBgMjA2YFxuICogQHBhcmFtIGNvbmZpZy5wcm90ZWN0ZWQge0Z1bmN0aW9ufSAtIFtTZXJ2ZXJdIElmIGB0cnVlYCAtIGZpbGVzIHdpbGwgYmUgc2VydmVkIG9ubHkgdG8gYXV0aG9yaXplZCB1c2VycywgaWYgYGZ1bmN0aW9uKClgIC0geW91J3JlIGFibGUgdG8gY2hlY2sgdmlzaXRvcidzIHBlcm1pc3Npb25zIGluIHlvdXIgb3duIHdheSBmdW5jdGlvbidzIGNvbnRleHQgaGFzOlxuICogIC0gYHJlcXVlc3RgXG4gKiAgLSBgcmVzcG9uc2VgXG4gKiAgLSBgdXNlcigpYFxuICogIC0gYHVzZXJJZGBcbiAqIEBwYXJhbSBjb25maWcuY2h1bmtTaXplICAgICAge051bWJlcn0gIC0gW0JvdGhdIFVwbG9hZCBjaHVuayBzaXplLCBkZWZhdWx0OiA1MjQyODggYnl0ZXMgKDAsNSBNYilcbiAqIEBwYXJhbSBjb25maWcucGVybWlzc2lvbnMgICAge051bWJlcn0gIC0gW1NlcnZlcl0gUGVybWlzc2lvbnMgd2hpY2ggd2lsbCBiZSBzZXQgdG8gdXBsb2FkZWQgZmlsZXMgKG9jdGFsKSwgbGlrZTogYDUxMWAgb3IgYDBvNzU1YC4gRGVmYXVsdDogMDY0NFxuICogQHBhcmFtIGNvbmZpZy5wYXJlbnREaXJQZXJtaXNzaW9ucyB7TnVtYmVyfSAgLSBbU2VydmVyXSBQZXJtaXNzaW9ucyB3aGljaCB3aWxsIGJlIHNldCB0byBwYXJlbnQgZGlyZWN0b3J5IG9mIHVwbG9hZGVkIGZpbGVzIChvY3RhbCksIGxpa2U6IGA2MTFgIG9yIGAwbzc3N2AuIERlZmF1bHQ6IDA3NTVcbiAqIEBwYXJhbSBjb25maWcuc3RvcmFnZVBhdGggICAge1N0cmluZ3xGdW5jdGlvbn0gIC0gW1NlcnZlcl0gU3RvcmFnZSBwYXRoIG9uIGZpbGUgc3lzdGVtXG4gKiBAcGFyYW0gY29uZmlnLmNhY2hlQ29udHJvbCAgIHtTdHJpbmd9ICAtIFtTZXJ2ZXJdIERlZmF1bHQgYENhY2hlLUNvbnRyb2xgIGhlYWRlclxuICogQHBhcmFtIGNvbmZpZy5yZXNwb25zZUhlYWRlcnMge09iamVjdHxGdW5jdGlvbn0gLSBbU2VydmVyXSBDdXN0b20gcmVzcG9uc2UgaGVhZGVycywgaWYgZnVuY3Rpb24gaXMgcGFzc2VkLCBtdXN0IHJldHVybiBPYmplY3RcbiAqIEBwYXJhbSBjb25maWcudGhyb3R0bGUgICAgICAge051bWJlcn0gIC0gW1NlcnZlcl0gREVQUkVDQVRFRCBicHMgdGhyb3R0bGUgdGhyZXNob2xkXG4gKiBAcGFyYW0gY29uZmlnLmRvd25sb2FkUm91dGUgIHtTdHJpbmd9ICAtIFtCb3RoXSAgIFNlcnZlciBSb3V0ZSB1c2VkIHRvIHJldHJpZXZlIGZpbGVzXG4gKiBAcGFyYW0gY29uZmlnLmNvbGxlY3Rpb24gICAgIHtNb25nby5Db2xsZWN0aW9ufSAtIFtCb3RoXSBNb25nbyBDb2xsZWN0aW9uIEluc3RhbmNlXG4gKiBAcGFyYW0gY29uZmlnLmNvbGxlY3Rpb25OYW1lIHtTdHJpbmd9ICAtIFtCb3RoXSAgIENvbGxlY3Rpb24gbmFtZVxuICogQHBhcmFtIGNvbmZpZy5uYW1pbmdGdW5jdGlvbiB7RnVuY3Rpb259LSBbQm90aF0gICBGdW5jdGlvbiB3aGljaCByZXR1cm5zIGBTdHJpbmdgXG4gKiBAcGFyYW0gY29uZmlnLmludGVncml0eUNoZWNrIHtCb29sZWFufSAtIFtTZXJ2ZXJdIENoZWNrIGZpbGUncyBpbnRlZ3JpdHkgYmVmb3JlIHNlcnZpbmcgdG8gdXNlcnNcbiAqIEBwYXJhbSBjb25maWcub25BZnRlclVwbG9hZCAge0Z1bmN0aW9ufS0gW1NlcnZlcl0gQ2FsbGVkIHJpZ2h0IGFmdGVyIGZpbGUgaXMgcmVhZHkgb24gRlMuIFVzZSB0byB0cmFuc2ZlciBmaWxlIHNvbWV3aGVyZSBlbHNlLCBvciBkbyBvdGhlciB0aGluZyB3aXRoIGZpbGUgZGlyZWN0bHlcbiAqIEBwYXJhbSBjb25maWcub25BZnRlclJlbW92ZSAge0Z1bmN0aW9ufSAtIFtTZXJ2ZXJdIENhbGxlZCByaWdodCBhZnRlciBmaWxlIGlzIHJlbW92ZWQuIFJlbW92ZWQgb2JqZWN0cyBpcyBwYXNzZWQgdG8gY2FsbGJhY2tcbiAqIEBwYXJhbSBjb25maWcuY29udGludWVVcGxvYWRUVEwge051bWJlcn0gLSBbU2VydmVyXSBUaW1lIGluIHNlY29uZHMsIGR1cmluZyB1cGxvYWQgbWF5IGJlIGNvbnRpbnVlZCwgZGVmYXVsdCAzIGhvdXJzICgxMDgwMCBzZWNvbmRzKVxuICogQHBhcmFtIGNvbmZpZy5vbkJlZm9yZVVwbG9hZCB7RnVuY3Rpb259LSBbQm90aF0gICBGdW5jdGlvbiB3aGljaCBleGVjdXRlcyBvbiBzZXJ2ZXIgYWZ0ZXIgcmVjZWl2aW5nIGVhY2ggY2h1bmsgYW5kIG9uIGNsaWVudCByaWdodCBiZWZvcmUgYmVnaW5uaW5nIHVwbG9hZC4gRnVuY3Rpb24gY29udGV4dCBpcyBgRmlsZWAgLSBzbyB5b3UgYXJlIGFibGUgdG8gY2hlY2sgZm9yIGV4dGVuc2lvbiwgbWltZS10eXBlLCBzaXplIGFuZCBldGMuOlxuICogIC0gcmV0dXJuIGB0cnVlYCB0byBjb250aW51ZVxuICogIC0gcmV0dXJuIGBmYWxzZWAgb3IgYFN0cmluZ2AgdG8gYWJvcnQgdXBsb2FkXG4gKiBAcGFyYW0gY29uZmlnLmdldFVzZXIgICAgICAgIHtGdW5jdGlvbn0gLSBbU2VydmVyXSBSZXBsYWNlIGRlZmF1bHQgd2F5IG9mIHJlY29nbml6aW5nIHVzZXIsIHVzZWZ1bGwgd2hlbiB5b3Ugd2FudCB0byBhdXRoIHVzZXIgYmFzZWQgb24gY3VzdG9tIGNvb2tpZSAob3Igb3RoZXIgd2F5KS4gYXJndW1lbnRzIHtodHRwOiB7cmVxdWVzdDogey4uLn0sIHJlc3BvbnNlOiB7Li4ufX19LCBuZWVkIHRvIHJldHVybiB7dXNlcklkOiBTdHJpbmcsIHVzZXI6IEZ1bmN0aW9ufVxuICogQHBhcmFtIGNvbmZpZy5vbkluaXRpYXRlVXBsb2FkIHtGdW5jdGlvbn0gLSBbU2VydmVyXSBGdW5jdGlvbiB3aGljaCBleGVjdXRlcyBvbiBzZXJ2ZXIgcmlnaHQgYmVmb3JlIHVwbG9hZCBpcyBiZWdpbiBhbmQgcmlnaHQgYWZ0ZXIgYG9uQmVmb3JlVXBsb2FkYCBob29rLiBUaGlzIGhvb2sgaXMgZnVsbHkgYXN5bmNocm9ub3VzLlxuICogQHBhcmFtIGNvbmZpZy5vbkJlZm9yZVJlbW92ZSB7RnVuY3Rpb259IC0gW1NlcnZlcl0gRXhlY3V0ZXMgYmVmb3JlIHJlbW92aW5nIGZpbGUgb24gc2VydmVyLCBzbyB5b3UgY2FuIGNoZWNrIHBlcm1pc3Npb25zLiBSZXR1cm4gYHRydWVgIHRvIGFsbG93IGFjdGlvbiBhbmQgYGZhbHNlYCB0byBkZW55LlxuICogQHBhcmFtIGNvbmZpZy5hbGxvd0NsaWVudENvZGUgIHtCb29sZWFufSAgLSBbQm90aF0gICBBbGxvdyB0byBydW4gYHJlbW92ZWAgZnJvbSBjbGllbnRcbiAqIEBwYXJhbSBjb25maWcuZG93bmxvYWRDYWxsYmFjayB7RnVuY3Rpb259IC0gW1NlcnZlcl0gQ2FsbGJhY2sgdHJpZ2dlcmVkIGVhY2ggdGltZSBmaWxlIGlzIHJlcXVlc3RlZCwgcmV0dXJuIHRydXRoeSB2YWx1ZSB0byBjb250aW51ZSBkb3dubG9hZCwgb3IgZmFsc3kgdG8gYWJvcnRcbiAgKiBAcGFyYW0gY29uZmlnLmludGVyY2VwdFJlcXVlc3Qge0Z1bmN0aW9ufSAtIFtTZXJ2ZXJdIEludGVyY2VwdCBpbmNvbWluZyBIVFRQIHJlcXVlc3QsIHNvIHlvdSBjYW4gd2hhdGV2ZXIgeW91IHdhbnQsIG5vIGNoZWNrcyBvciBwcmVwcm9jZXNzaW5nLCBhcmd1bWVudHMge2h0dHA6IHtyZXF1ZXN0OiB7Li4ufSwgcmVzcG9uc2U6IHsuLi59fSwgcGFyYW1zOiB7Li4ufX1cbiAqIEBwYXJhbSBjb25maWcuaW50ZXJjZXB0RG93bmxvYWQge0Z1bmN0aW9ufSAtIFtTZXJ2ZXJdIEludGVyY2VwdCBkb3dubG9hZCByZXF1ZXN0LCBzbyB5b3UgY2FuIHNlcnZlIGZpbGUgZnJvbSB0aGlyZC1wYXJ0eSByZXNvdXJjZSwgYXJndW1lbnRzIHtodHRwOiB7cmVxdWVzdDogey4uLn0sIHJlc3BvbnNlOiB7Li4ufX0sIGZpbGVSZWY6IHsuLi59fVxuICogQHBhcmFtIGNvbmZpZy5kaXNhYmxlVXBsb2FkIHtCb29sZWFufSAtIERpc2FibGUgZmlsZSB1cGxvYWQsIHVzZWZ1bCBmb3Igc2VydmVyIG9ubHkgc29sdXRpb25zXG4gKiBAcGFyYW0gY29uZmlnLmRpc2FibGVEb3dubG9hZCB7Qm9vbGVhbn0gLSBEaXNhYmxlIGZpbGUgZG93bmxvYWQgKHNlcnZpbmcpLCB1c2VmdWwgZm9yIGZpbGUgbWFuYWdlbWVudCBvbmx5IHNvbHV0aW9uc1xuICogQHBhcmFtIGNvbmZpZy5hbGxvd2VkT3JpZ2lucyAge1JlZ2V4fEJvb2xlYW59ICAtIFtTZXJ2ZXJdICAgUmVnZXggb2YgT3JpZ2lucyB0aGF0IGFyZSBhbGxvd2VkIENPUlMgYWNjZXNzIG9yIGBmYWxzZWAgdG8gZGlzYWJsZSBjb21wbGV0ZWx5LiBEZWZhdWx0cyB0byBgL15odHRwOlxcL1xcL2xvY2FsaG9zdDoxMlswLTldezN9JC9gIGZvciBhbGxvd2luZyBNZXRlb3ItQ29yZG92YSBidWlsZHMgYWNjZXNzXG4gKiBAcGFyYW0gY29uZmlnLmFsbG93UXVlcnlTdHJpbmdDb29raWVzIHtCb29sZWFufSAtIEFsbG93IHBhc3NpbmcgQ29va2llcyBpbiBhIHF1ZXJ5IHN0cmluZyAoaW4gVVJMKS4gUHJpbWFyeSBzaG91bGQgYmUgdXNlZCBvbmx5IGluIENvcmRvdmEgZW52aXJvbm1lbnQuIE5vdGU6IHRoaXMgb3B0aW9uIHdpbGwgYmUgdXNlZCBvbmx5IG9uIENvcmRvdmEuIERlZmF1bHQ6IGBmYWxzZWBcbiAqIEBwYXJhbSBjb25maWcuX3ByZUNvbGxlY3Rpb24gIHtNb25nby5Db2xsZWN0aW9ufSAtIFtTZXJ2ZXJdIE1vbmdvIHByZUNvbGxlY3Rpb24gSW5zdGFuY2VcbiAqIEBwYXJhbSBjb25maWcuX3ByZUNvbGxlY3Rpb25OYW1lIHtTdHJpbmd9ICAtIFtTZXJ2ZXJdICBwcmVDb2xsZWN0aW9uIG5hbWVcbiAqIEBzdW1tYXJ5IENyZWF0ZSBuZXcgaW5zdGFuY2Ugb2YgRmlsZXNDb2xsZWN0aW9uXG4gKi9cbmV4cG9ydCBjbGFzcyBGaWxlc0NvbGxlY3Rpb24gZXh0ZW5kcyBGaWxlc0NvbGxlY3Rpb25Db3JlIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgc3VwZXIoKTtcbiAgICBsZXQgc3RvcmFnZVBhdGg7XG4gICAgaWYgKGNvbmZpZykge1xuICAgICAgKHtcbiAgICAgICAgc3RvcmFnZVBhdGgsXG4gICAgICAgIGRlYnVnOiB0aGlzLmRlYnVnLFxuICAgICAgICBzY2hlbWE6IHRoaXMuc2NoZW1hLFxuICAgICAgICBwdWJsaWM6IHRoaXMucHVibGljLFxuICAgICAgICBzdHJpY3Q6IHRoaXMuc3RyaWN0LFxuICAgICAgICBnZXRVc2VyOiB0aGlzLmdldFVzZXIsXG4gICAgICAgIGNodW5rU2l6ZTogdGhpcy5jaHVua1NpemUsXG4gICAgICAgIHByb3RlY3RlZDogdGhpcy5wcm90ZWN0ZWQsXG4gICAgICAgIGNvbGxlY3Rpb246IHRoaXMuY29sbGVjdGlvbixcbiAgICAgICAgcGVybWlzc2lvbnM6IHRoaXMucGVybWlzc2lvbnMsXG4gICAgICAgIGNhY2hlQ29udHJvbDogdGhpcy5jYWNoZUNvbnRyb2wsXG4gICAgICAgIGRvd25sb2FkUm91dGU6IHRoaXMuZG93bmxvYWRSb3V0ZSxcbiAgICAgICAgb25BZnRlclVwbG9hZDogdGhpcy5vbkFmdGVyVXBsb2FkLFxuICAgICAgICBvbkFmdGVyUmVtb3ZlOiB0aGlzLm9uQWZ0ZXJSZW1vdmUsXG4gICAgICAgIGRpc2FibGVVcGxvYWQ6IHRoaXMuZGlzYWJsZVVwbG9hZCxcbiAgICAgICAgb25CZWZvcmVSZW1vdmU6IHRoaXMub25CZWZvcmVSZW1vdmUsXG4gICAgICAgIGludGVncml0eUNoZWNrOiB0aGlzLmludGVncml0eUNoZWNrLFxuICAgICAgICBjb2xsZWN0aW9uTmFtZTogdGhpcy5jb2xsZWN0aW9uTmFtZSxcbiAgICAgICAgb25CZWZvcmVVcGxvYWQ6IHRoaXMub25CZWZvcmVVcGxvYWQsXG4gICAgICAgIG5hbWluZ0Z1bmN0aW9uOiB0aGlzLm5hbWluZ0Z1bmN0aW9uLFxuICAgICAgICByZXNwb25zZUhlYWRlcnM6IHRoaXMucmVzcG9uc2VIZWFkZXJzLFxuICAgICAgICBkaXNhYmxlRG93bmxvYWQ6IHRoaXMuZGlzYWJsZURvd25sb2FkLFxuICAgICAgICBhbGxvd2VkT3JpZ2luczogdGhpcy5hbGxvd2VkT3JpZ2lucyxcbiAgICAgICAgYWxsb3dDbGllbnRDb2RlOiB0aGlzLmFsbG93Q2xpZW50Q29kZSxcbiAgICAgICAgZG93bmxvYWRDYWxsYmFjazogdGhpcy5kb3dubG9hZENhbGxiYWNrLFxuICAgICAgICBvbkluaXRpYXRlVXBsb2FkOiB0aGlzLm9uSW5pdGlhdGVVcGxvYWQsXG4gICAgICAgIGludGVyY2VwdFJlcXVlc3Q6IHRoaXMuaW50ZXJjZXB0UmVxdWVzdCxcbiAgICAgICAgaW50ZXJjZXB0RG93bmxvYWQ6IHRoaXMuaW50ZXJjZXB0RG93bmxvYWQsXG4gICAgICAgIGNvbnRpbnVlVXBsb2FkVFRMOiB0aGlzLmNvbnRpbnVlVXBsb2FkVFRMLFxuICAgICAgICBwYXJlbnREaXJQZXJtaXNzaW9uczogdGhpcy5wYXJlbnREaXJQZXJtaXNzaW9ucyxcbiAgICAgICAgYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXM6IHRoaXMuYWxsb3dRdWVyeVN0cmluZ0Nvb2tpZXMsXG4gICAgICAgIF9wcmVDb2xsZWN0aW9uOiB0aGlzLl9wcmVDb2xsZWN0aW9uLFxuICAgICAgICBfcHJlQ29sbGVjdGlvbk5hbWU6IHRoaXMuX3ByZUNvbGxlY3Rpb25OYW1lLFxuICAgICAgfSA9IGNvbmZpZyk7XG4gICAgfVxuXG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNCb29sZWFuKHRoaXMuZGVidWcpKSB7XG4gICAgICB0aGlzLmRlYnVnID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzQm9vbGVhbih0aGlzLnB1YmxpYykpIHtcbiAgICAgIHRoaXMucHVibGljID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCF0aGlzLnByb3RlY3RlZCkge1xuICAgICAgdGhpcy5wcm90ZWN0ZWQgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMuY2h1bmtTaXplKSB7XG4gICAgICB0aGlzLmNodW5rU2l6ZSA9IDEwMjQgKiA1MTI7XG4gICAgfVxuXG4gICAgdGhpcy5jaHVua1NpemUgPSBNYXRoLmZsb29yKHRoaXMuY2h1bmtTaXplIC8gOCkgKiA4O1xuXG4gICAgaWYgKCFoZWxwZXJzLmlzU3RyaW5nKHRoaXMuY29sbGVjdGlvbk5hbWUpICYmICF0aGlzLmNvbGxlY3Rpb24pIHtcbiAgICAgIHRoaXMuY29sbGVjdGlvbk5hbWUgPSAnTWV0ZW9yVXBsb2FkRmlsZXMnO1xuICAgIH1cblxuICAgIGlmICghdGhpcy5jb2xsZWN0aW9uKSB7XG4gICAgICB0aGlzLmNvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbih0aGlzLmNvbGxlY3Rpb25OYW1lKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb2xsZWN0aW9uTmFtZSA9IHRoaXMuY29sbGVjdGlvbi5fbmFtZTtcbiAgICB9XG5cbiAgICB0aGlzLmNvbGxlY3Rpb24uZmlsZXNDb2xsZWN0aW9uID0gdGhpcztcbiAgICBjaGVjayh0aGlzLmNvbGxlY3Rpb25OYW1lLCBTdHJpbmcpO1xuXG4gICAgaWYgKHRoaXMucHVibGljICYmICF0aGlzLmRvd25sb2FkUm91dGUpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCBgW0ZpbGVzQ29sbGVjdGlvbi4ke3RoaXMuY29sbGVjdGlvbk5hbWV9XTogXCJkb3dubG9hZFJvdXRlXCIgbXVzdCBiZSBwcmVjaXNlbHkgcHJvdmlkZWQgb24gXCJwdWJsaWNcIiBjb2xsZWN0aW9ucyEgTm90ZTogXCJkb3dubG9hZFJvdXRlXCIgbXVzdCBiZSBlcXVhbCBvciBiZSBpbnNpZGUgb2YgeW91ciB3ZWIvcHJveHktc2VydmVyIChyZWxhdGl2ZSkgcm9vdC5gKTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNTdHJpbmcodGhpcy5kb3dubG9hZFJvdXRlKSkge1xuICAgICAgdGhpcy5kb3dubG9hZFJvdXRlID0gJy9jZG4vc3RvcmFnZSc7XG4gICAgfVxuXG4gICAgdGhpcy5kb3dubG9hZFJvdXRlID0gdGhpcy5kb3dubG9hZFJvdXRlLnJlcGxhY2UoL1xcLyQvLCAnJyk7XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLm5hbWluZ0Z1bmN0aW9uKSkge1xuICAgICAgdGhpcy5uYW1pbmdGdW5jdGlvbiA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMub25CZWZvcmVVcGxvYWQpKSB7XG4gICAgICB0aGlzLm9uQmVmb3JlVXBsb2FkID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5nZXRVc2VyKSkge1xuICAgICAgdGhpcy5nZXRVc2VyID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzQm9vbGVhbih0aGlzLmFsbG93Q2xpZW50Q29kZSkpIHtcbiAgICAgIHRoaXMuYWxsb3dDbGllbnRDb2RlID0gdHJ1ZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLm9uSW5pdGlhdGVVcGxvYWQpKSB7XG4gICAgICB0aGlzLm9uSW5pdGlhdGVVcGxvYWQgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLmludGVyY2VwdFJlcXVlc3QpKSB7XG4gICAgICB0aGlzLmludGVyY2VwdFJlcXVlc3QgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLmludGVyY2VwdERvd25sb2FkKSkge1xuICAgICAgdGhpcy5pbnRlcmNlcHREb3dubG9hZCA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Jvb2xlYW4odGhpcy5zdHJpY3QpKSB7XG4gICAgICB0aGlzLnN0cmljdCA9IHRydWU7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzQm9vbGVhbih0aGlzLmFsbG93UXVlcnlTdHJpbmdDb29raWVzKSkge1xuICAgICAgdGhpcy5hbGxvd1F1ZXJ5U3RyaW5nQ29va2llcyA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc051bWJlcih0aGlzLnBlcm1pc3Npb25zKSkge1xuICAgICAgdGhpcy5wZXJtaXNzaW9ucyA9IHBhcnNlSW50KCc2NDQnLCA4KTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNOdW1iZXIodGhpcy5wYXJlbnREaXJQZXJtaXNzaW9ucykpIHtcbiAgICAgIHRoaXMucGFyZW50RGlyUGVybWlzc2lvbnMgPSBwYXJzZUludCgnNzU1JywgOCk7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzU3RyaW5nKHRoaXMuY2FjaGVDb250cm9sKSkge1xuICAgICAgdGhpcy5jYWNoZUNvbnRyb2wgPSAncHVibGljLCBtYXgtYWdlPTMxNTM2MDAwLCBzLW1heGFnZT0zMTUzNjAwMCc7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5vbkFmdGVyVXBsb2FkKSkge1xuICAgICAgdGhpcy5vbkFmdGVyVXBsb2FkID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzQm9vbGVhbih0aGlzLmRpc2FibGVVcGxvYWQpKSB7XG4gICAgICB0aGlzLmRpc2FibGVVcGxvYWQgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLm9uQWZ0ZXJSZW1vdmUpKSB7XG4gICAgICB0aGlzLm9uQWZ0ZXJSZW1vdmUgPSBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNGdW5jdGlvbih0aGlzLm9uQmVmb3JlUmVtb3ZlKSkge1xuICAgICAgdGhpcy5vbkJlZm9yZVJlbW92ZSA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Jvb2xlYW4odGhpcy5pbnRlZ3JpdHlDaGVjaykpIHtcbiAgICAgIHRoaXMuaW50ZWdyaXR5Q2hlY2sgPSB0cnVlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Jvb2xlYW4odGhpcy5kaXNhYmxlRG93bmxvYWQpKSB7XG4gICAgICB0aGlzLmRpc2FibGVEb3dubG9hZCA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc0Jvb2xlYW4odGhpcy5hbGxvd2VkT3JpZ2lucykgfHwgdGhpcy5hbGxvd2VkT3JpZ2lucyA9PT0gdHJ1ZSkge1xuICAgICAgdGhpcy5hbGxvd2VkT3JpZ2lucyA9IC9eaHR0cDpcXC9cXC9sb2NhbGhvc3Q6MTJbMC05XXszfSQvO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc09iamVjdCh0aGlzLl9jdXJyZW50VXBsb2FkcykpIHtcbiAgICAgIHRoaXMuX2N1cnJlbnRVcGxvYWRzID0ge307XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5kb3dubG9hZENhbGxiYWNrKSkge1xuICAgICAgdGhpcy5kb3dubG9hZENhbGxiYWNrID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzTnVtYmVyKHRoaXMuY29udGludWVVcGxvYWRUVEwpKSB7XG4gICAgICB0aGlzLmNvbnRpbnVlVXBsb2FkVFRMID0gMTA4MDA7XG4gICAgfVxuXG4gICAgaWYgKCFoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5yZXNwb25zZUhlYWRlcnMpKSB7XG4gICAgICB0aGlzLnJlc3BvbnNlSGVhZGVycyA9IChyZXNwb25zZUNvZGUsIGZpbGVSZWYsIHZlcnNpb25SZWYpID0+IHtcbiAgICAgICAgY29uc3QgaGVhZGVycyA9IHt9O1xuICAgICAgICBzd2l0Y2ggKHJlc3BvbnNlQ29kZSkge1xuICAgICAgICBjYXNlICcyMDYnOlxuICAgICAgICAgIGhlYWRlcnMuUHJhZ21hICAgICAgICAgICAgICAgPSAncHJpdmF0ZSc7XG4gICAgICAgICAgaGVhZGVyc1snVHJhbnNmZXItRW5jb2RpbmcnXSA9ICdjaHVua2VkJztcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnNDAwJzpcbiAgICAgICAgICBoZWFkZXJzWydDYWNoZS1Db250cm9sJ10gICAgID0gJ25vLWNhY2hlJztcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnNDE2JzpcbiAgICAgICAgICBoZWFkZXJzWydDb250ZW50LVJhbmdlJ10gICAgID0gYGJ5dGVzICovJHt2ZXJzaW9uUmVmLnNpemV9YDtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIGhlYWRlcnMuQ29ubmVjdGlvbiAgICAgICA9ICdrZWVwLWFsaXZlJztcbiAgICAgICAgaGVhZGVyc1snQ29udGVudC1UeXBlJ10gID0gdmVyc2lvblJlZi50eXBlIHx8ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nO1xuICAgICAgICBoZWFkZXJzWydBY2NlcHQtUmFuZ2VzJ10gPSAnYnl0ZXMnO1xuICAgICAgICByZXR1cm4gaGVhZGVycztcbiAgICAgIH07XG4gICAgfVxuXG4gICAgaWYgKHRoaXMucHVibGljICYmICFzdG9yYWdlUGF0aCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsIGBbRmlsZXNDb2xsZWN0aW9uLiR7dGhpcy5jb2xsZWN0aW9uTmFtZX1dIFwic3RvcmFnZVBhdGhcIiBtdXN0IGJlIHNldCBvbiBcInB1YmxpY1wiIGNvbGxlY3Rpb25zISBOb3RlOiBcInN0b3JhZ2VQYXRoXCIgbXVzdCBiZSBlcXVhbCBvbiBiZSBpbnNpZGUgb2YgeW91ciB3ZWIvcHJveHktc2VydmVyIChhYnNvbHV0ZSkgcm9vdC5gKTtcbiAgICB9XG5cbiAgICBpZiAoIXN0b3JhZ2VQYXRoKSB7XG4gICAgICBzdG9yYWdlUGF0aCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIGBhc3NldHMke25vZGVQYXRoLnNlcH1hcHAke25vZGVQYXRoLnNlcH11cGxvYWRzJHtub2RlUGF0aC5zZXB9JHtzZWxmLmNvbGxlY3Rpb25OYW1lfWA7XG4gICAgICB9O1xuICAgIH1cblxuICAgIGlmIChoZWxwZXJzLmlzU3RyaW5nKHN0b3JhZ2VQYXRoKSkge1xuICAgICAgdGhpcy5zdG9yYWdlUGF0aCA9ICgpID0+IHN0b3JhZ2VQYXRoO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnN0b3JhZ2VQYXRoID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBsZXQgc3AgPSBzdG9yYWdlUGF0aC5hcHBseShzZWxmLCBhcmd1bWVudHMpO1xuICAgICAgICBpZiAoIWhlbHBlcnMuaXNTdHJpbmcoc3ApKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsIGBbRmlsZXNDb2xsZWN0aW9uLiR7c2VsZi5jb2xsZWN0aW9uTmFtZX1dIFwic3RvcmFnZVBhdGhcIiBmdW5jdGlvbiBtdXN0IHJldHVybiBhIFN0cmluZyFgKTtcbiAgICAgICAgfVxuICAgICAgICBzcCA9IHNwLnJlcGxhY2UoL1xcLyQvLCAnJyk7XG4gICAgICAgIHJldHVybiBub2RlUGF0aC5ub3JtYWxpemUoc3ApO1xuICAgICAgfTtcbiAgICB9XG5cbiAgICB0aGlzLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbi5zdG9yYWdlUGF0aF0gU2V0IHRvOicsIHRoaXMuc3RvcmFnZVBhdGgoe30pKTtcblxuICAgIGZzLm1rZGlycyh0aGlzLnN0b3JhZ2VQYXRoKHt9KSwgeyBtb2RlOiB0aGlzLnBhcmVudERpclBlcm1pc3Npb25zIH0sIChlcnJvcikgPT4ge1xuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAxLCBgW0ZpbGVzQ29sbGVjdGlvbi4ke3NlbGYuY29sbGVjdGlvbk5hbWV9XSBQYXRoIFwiJHt0aGlzLnN0b3JhZ2VQYXRoKHt9KX1cIiBpcyBub3Qgd3JpdGFibGUhICR7ZXJyb3J9YCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBjaGVjayh0aGlzLnN0cmljdCwgQm9vbGVhbik7XG4gICAgY2hlY2sodGhpcy5wZXJtaXNzaW9ucywgTnVtYmVyKTtcbiAgICBjaGVjayh0aGlzLnN0b3JhZ2VQYXRoLCBGdW5jdGlvbik7XG4gICAgY2hlY2sodGhpcy5jYWNoZUNvbnRyb2wsIFN0cmluZyk7XG4gICAgY2hlY2sodGhpcy5vbkFmdGVyUmVtb3ZlLCBNYXRjaC5PbmVPZihmYWxzZSwgRnVuY3Rpb24pKTtcbiAgICBjaGVjayh0aGlzLm9uQWZ0ZXJVcGxvYWQsIE1hdGNoLk9uZU9mKGZhbHNlLCBGdW5jdGlvbikpO1xuICAgIGNoZWNrKHRoaXMuZGlzYWJsZVVwbG9hZCwgQm9vbGVhbik7XG4gICAgY2hlY2sodGhpcy5pbnRlZ3JpdHlDaGVjaywgQm9vbGVhbik7XG4gICAgY2hlY2sodGhpcy5vbkJlZm9yZVJlbW92ZSwgTWF0Y2guT25lT2YoZmFsc2UsIEZ1bmN0aW9uKSk7XG4gICAgY2hlY2sodGhpcy5kaXNhYmxlRG93bmxvYWQsIEJvb2xlYW4pO1xuICAgIGNoZWNrKHRoaXMuZG93bmxvYWRDYWxsYmFjaywgTWF0Y2guT25lT2YoZmFsc2UsIEZ1bmN0aW9uKSk7XG4gICAgY2hlY2sodGhpcy5pbnRlcmNlcHRSZXF1ZXN0LCBNYXRjaC5PbmVPZihmYWxzZSwgRnVuY3Rpb24pKTtcbiAgICBjaGVjayh0aGlzLmludGVyY2VwdERvd25sb2FkLCBNYXRjaC5PbmVPZihmYWxzZSwgRnVuY3Rpb24pKTtcbiAgICBjaGVjayh0aGlzLmNvbnRpbnVlVXBsb2FkVFRMLCBOdW1iZXIpO1xuICAgIGNoZWNrKHRoaXMucmVzcG9uc2VIZWFkZXJzLCBNYXRjaC5PbmVPZihPYmplY3QsIEZ1bmN0aW9uKSk7XG4gICAgY2hlY2sodGhpcy5hbGxvd1F1ZXJ5U3RyaW5nQ29va2llcywgQm9vbGVhbik7XG5cbiAgICBuZXcgQ29va2llcyh7XG4gICAgICBhbGxvd1F1ZXJ5U3RyaW5nQ29va2llczogdGhpcy5hbGxvd1F1ZXJ5U3RyaW5nQ29va2llcyxcbiAgICAgIGFsbG93ZWRDb3Jkb3ZhT3JpZ2luczogdGhpcy5hbGxvd2VkT3JpZ2luc1xuICAgIH0pO1xuXG4gICAgaWYgKCF0aGlzLmRpc2FibGVVcGxvYWQpIHtcbiAgICAgIGlmICghaGVscGVycy5pc1N0cmluZyh0aGlzLl9wcmVDb2xsZWN0aW9uTmFtZSkgJiYgIXRoaXMuX3ByZUNvbGxlY3Rpb24pIHtcbiAgICAgICAgdGhpcy5fcHJlQ29sbGVjdGlvbk5hbWUgPSBgX19wcmVfJHt0aGlzLmNvbGxlY3Rpb25OYW1lfWA7XG4gICAgICB9XG5cbiAgICAgIGlmICghdGhpcy5fcHJlQ29sbGVjdGlvbikge1xuICAgICAgICB0aGlzLl9wcmVDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24odGhpcy5fcHJlQ29sbGVjdGlvbk5hbWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5fcHJlQ29sbGVjdGlvbk5hbWUgPSB0aGlzLl9wcmVDb2xsZWN0aW9uLl9uYW1lO1xuICAgICAgfVxuICAgICAgY2hlY2sodGhpcy5fcHJlQ29sbGVjdGlvbk5hbWUsIFN0cmluZyk7XG5cbiAgICAgIHRoaXMuX3ByZUNvbGxlY3Rpb24uX2Vuc3VyZUluZGV4KHsgY3JlYXRlZEF0OiAxIH0sIHsgZXhwaXJlQWZ0ZXJTZWNvbmRzOiB0aGlzLmNvbnRpbnVlVXBsb2FkVFRMLCBiYWNrZ3JvdW5kOiB0cnVlIH0pO1xuICAgICAgY29uc3QgX3ByZUNvbGxlY3Rpb25DdXJzb3IgPSB0aGlzLl9wcmVDb2xsZWN0aW9uLmZpbmQoe30sIHtcbiAgICAgICAgZmllbGRzOiB7XG4gICAgICAgICAgX2lkOiAxLFxuICAgICAgICAgIGlzRmluaXNoZWQ6IDFcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIF9wcmVDb2xsZWN0aW9uQ3Vyc29yLm9ic2VydmUoe1xuICAgICAgICBjaGFuZ2VkKGRvYykge1xuICAgICAgICAgIGlmIChkb2MuaXNGaW5pc2hlZCkge1xuICAgICAgICAgICAgc2VsZi5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtfcHJlQ29sbGVjdGlvbkN1cnNvci5vYnNlcnZlXSBbY2hhbmdlZF06ICR7ZG9jLl9pZH1gKTtcbiAgICAgICAgICAgIHNlbGYuX3ByZUNvbGxlY3Rpb24ucmVtb3ZlKHtfaWQ6IGRvYy5faWR9LCBOT09QKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHJlbW92ZWQoZG9jKSB7XG4gICAgICAgICAgLy8gRnJlZSBtZW1vcnkgYWZ0ZXIgdXBsb2FkIGlzIGRvbmVcbiAgICAgICAgICAvLyBPciBpZiB1cGxvYWQgaXMgdW5maW5pc2hlZFxuICAgICAgICAgIHNlbGYuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbX3ByZUNvbGxlY3Rpb25DdXJzb3Iub2JzZXJ2ZV0gW3JlbW92ZWRdOiAke2RvYy5faWR9YCk7XG4gICAgICAgICAgaWYgKGhlbHBlcnMuaXNPYmplY3Qoc2VsZi5fY3VycmVudFVwbG9hZHNbZG9jLl9pZF0pKSB7XG4gICAgICAgICAgICBzZWxmLl9jdXJyZW50VXBsb2Fkc1tkb2MuX2lkXS5zdG9wKCk7XG4gICAgICAgICAgICBzZWxmLl9jdXJyZW50VXBsb2Fkc1tkb2MuX2lkXS5lbmQoKTtcblxuICAgICAgICAgICAgLy8gV2UgY2FuIGJlIHVubHVja3kgdG8gcnVuIGludG8gYSByYWNlIGNvbmRpdGlvbiB3aGVyZSBhbm90aGVyIHNlcnZlciByZW1vdmVkIHRoaXMgZG9jdW1lbnQgYmVmb3JlIHRoZSBjaGFuZ2Ugb2YgYGlzRmluaXNoZWRgIGlzIHJlZ2lzdGVyZWQgb24gdGhpcyBzZXJ2ZXIuXG4gICAgICAgICAgICAvLyBUaGVyZWZvcmUgaXQncyBiZXR0ZXIgdG8gZG91YmxlLWNoZWNrIHdpdGggdGhlIG1haW4gY29sbGVjdGlvbiBpZiB0aGUgZmlsZSBpcyByZWZlcmVuY2VkIHRoZXJlLiBJc3N1ZTogaHR0cHM6Ly9naXRodWIuY29tL1ZlbGlvdkdyb3VwL01ldGVvci1GaWxlcy9pc3N1ZXMvNjcyXG4gICAgICAgICAgICBpZiAoIWRvYy5pc0ZpbmlzaGVkICYmIHNlbGYuY29sbGVjdGlvbi5maW5kKHsgX2lkOiBkb2MuX2lkIH0pLmNvdW50KCkgPT09IDApIHtcbiAgICAgICAgICAgICAgc2VsZi5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtfcHJlQ29sbGVjdGlvbkN1cnNvci5vYnNlcnZlXSBbcmVtb3ZlVW5maW5pc2hlZFVwbG9hZF06ICR7ZG9jLl9pZH1gKTtcbiAgICAgICAgICAgICAgc2VsZi5fY3VycmVudFVwbG9hZHNbZG9jLl9pZF0uYWJvcnQoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZGVsZXRlIHNlbGYuX2N1cnJlbnRVcGxvYWRzW2RvYy5faWRdO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIHRoaXMuX2NyZWF0ZVN0cmVhbSA9IChfaWQsIHBhdGgsIG9wdHMpID0+IHtcbiAgICAgICAgdGhpcy5fY3VycmVudFVwbG9hZHNbX2lkXSA9IG5ldyBXcml0ZVN0cmVhbShwYXRoLCBvcHRzLmZpbGVMZW5ndGgsIG9wdHMsIHRoaXMucGVybWlzc2lvbnMpO1xuICAgICAgfTtcblxuICAgICAgLy8gVGhpcyBsaXR0bGUgZnVuY3Rpb24gYWxsb3dzIHRvIGNvbnRpbnVlIHVwbG9hZFxuICAgICAgLy8gZXZlbiBhZnRlciBzZXJ2ZXIgaXMgcmVzdGFydGVkICgqbm90IG9uIGRldi1zdGFnZSopXG4gICAgICB0aGlzLl9jb250aW51ZVVwbG9hZCA9IChfaWQpID0+IHtcbiAgICAgICAgaWYgKHRoaXMuX2N1cnJlbnRVcGxvYWRzW19pZF0gJiYgdGhpcy5fY3VycmVudFVwbG9hZHNbX2lkXS5maWxlKSB7XG4gICAgICAgICAgaWYgKCF0aGlzLl9jdXJyZW50VXBsb2Fkc1tfaWRdLmFib3J0ZWQgJiYgIXRoaXMuX2N1cnJlbnRVcGxvYWRzW19pZF0uZW5kZWQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jdXJyZW50VXBsb2Fkc1tfaWRdLmZpbGU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuX2NyZWF0ZVN0cmVhbShfaWQsIHRoaXMuX2N1cnJlbnRVcGxvYWRzW19pZF0uZmlsZS5maWxlLnBhdGgsIHRoaXMuX2N1cnJlbnRVcGxvYWRzW19pZF0uZmlsZSk7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX2N1cnJlbnRVcGxvYWRzW19pZF0uZmlsZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjb250VXBsZCA9IHRoaXMuX3ByZUNvbGxlY3Rpb24uZmluZE9uZSh7X2lkfSk7XG4gICAgICAgIGlmIChjb250VXBsZCkge1xuICAgICAgICAgIHRoaXMuX2NyZWF0ZVN0cmVhbShfaWQsIGNvbnRVcGxkLmZpbGUucGF0aCwgY29udFVwbGQpO1xuICAgICAgICAgIHJldHVybiB0aGlzLl9jdXJyZW50VXBsb2Fkc1tfaWRdLmZpbGU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfTtcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMuc2NoZW1hKSB7XG4gICAgICB0aGlzLnNjaGVtYSA9IEZpbGVzQ29sbGVjdGlvbkNvcmUuc2NoZW1hO1xuICAgIH1cblxuICAgIGNoZWNrKHRoaXMuZGVidWcsIEJvb2xlYW4pO1xuICAgIGNoZWNrKHRoaXMuc2NoZW1hLCBPYmplY3QpO1xuICAgIGNoZWNrKHRoaXMucHVibGljLCBCb29sZWFuKTtcbiAgICBjaGVjayh0aGlzLmdldFVzZXIsIE1hdGNoLk9uZU9mKGZhbHNlLCBGdW5jdGlvbikpO1xuICAgIGNoZWNrKHRoaXMucHJvdGVjdGVkLCBNYXRjaC5PbmVPZihCb29sZWFuLCBGdW5jdGlvbikpO1xuICAgIGNoZWNrKHRoaXMuY2h1bmtTaXplLCBOdW1iZXIpO1xuICAgIGNoZWNrKHRoaXMuZG93bmxvYWRSb3V0ZSwgU3RyaW5nKTtcbiAgICBjaGVjayh0aGlzLm5hbWluZ0Z1bmN0aW9uLCBNYXRjaC5PbmVPZihmYWxzZSwgRnVuY3Rpb24pKTtcbiAgICBjaGVjayh0aGlzLm9uQmVmb3JlVXBsb2FkLCBNYXRjaC5PbmVPZihmYWxzZSwgRnVuY3Rpb24pKTtcbiAgICBjaGVjayh0aGlzLm9uSW5pdGlhdGVVcGxvYWQsIE1hdGNoLk9uZU9mKGZhbHNlLCBGdW5jdGlvbikpO1xuICAgIGNoZWNrKHRoaXMuYWxsb3dDbGllbnRDb2RlLCBCb29sZWFuKTtcblxuICAgIGlmICh0aGlzLnB1YmxpYyAmJiB0aGlzLnByb3RlY3RlZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsIGBbRmlsZXNDb2xsZWN0aW9uLiR7dGhpcy5jb2xsZWN0aW9uTmFtZX1dOiBGaWxlcyBjYW4gbm90IGJlIHB1YmxpYyBhbmQgcHJvdGVjdGVkIGF0IHRoZSBzYW1lIHRpbWUhYCk7XG4gICAgfVxuXG4gICAgdGhpcy5fY2hlY2tBY2Nlc3MgPSAoaHR0cCkgPT4ge1xuICAgICAgaWYgKHRoaXMucHJvdGVjdGVkKSB7XG4gICAgICAgIGxldCByZXN1bHQ7XG4gICAgICAgIGNvbnN0IHt1c2VyLCB1c2VySWR9ID0gdGhpcy5fZ2V0VXNlcihodHRwKTtcblxuICAgICAgICBpZiAoaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMucHJvdGVjdGVkKSkge1xuICAgICAgICAgIGxldCBmaWxlUmVmO1xuICAgICAgICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KGh0dHAucGFyYW1zKSAmJiAgaHR0cC5wYXJhbXMuX2lkKSB7XG4gICAgICAgICAgICBmaWxlUmVmID0gdGhpcy5jb2xsZWN0aW9uLmZpbmRPbmUoaHR0cC5wYXJhbXMuX2lkKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXN1bHQgPSBodHRwID8gdGhpcy5wcm90ZWN0ZWQuY2FsbChPYmplY3QuYXNzaWduKGh0dHAsIHt1c2VyLCB1c2VySWR9KSwgKGZpbGVSZWYgfHwgbnVsbCkpIDogdGhpcy5wcm90ZWN0ZWQuY2FsbCh7dXNlciwgdXNlcklkfSwgKGZpbGVSZWYgfHwgbnVsbCkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc3VsdCA9ICEhdXNlcklkO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKChodHRwICYmIChyZXN1bHQgPT09IHRydWUpKSB8fCAhaHR0cCkge1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgcmMgPSBoZWxwZXJzLmlzTnVtYmVyKHJlc3VsdCkgPyByZXN1bHQgOiA0MDE7XG4gICAgICAgIHRoaXMuX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uLl9jaGVja0FjY2Vzc10gV0FSTjogQWNjZXNzIGRlbmllZCEnKTtcbiAgICAgICAgaWYgKGh0dHApIHtcbiAgICAgICAgICBjb25zdCB0ZXh0ID0gJ0FjY2VzcyBkZW5pZWQhJztcbiAgICAgICAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgICAgIGh0dHAucmVzcG9uc2Uud3JpdGVIZWFkKHJjLCB7XG4gICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC9wbGFpbicsXG4gICAgICAgICAgICAgICdDb250ZW50LUxlbmd0aCc6IHRleHQubGVuZ3RoXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoIWh0dHAucmVzcG9uc2UuZmluaXNoZWQpIHtcbiAgICAgICAgICAgIGh0dHAucmVzcG9uc2UuZW5kKHRleHQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH07XG5cbiAgICB0aGlzLl9tZXRob2ROYW1lcyA9IHtcbiAgICAgIF9BYm9ydDogYF9GaWxlc0NvbGxlY3Rpb25BYm9ydF8ke3RoaXMuY29sbGVjdGlvbk5hbWV9YCxcbiAgICAgIF9Xcml0ZTogYF9GaWxlc0NvbGxlY3Rpb25Xcml0ZV8ke3RoaXMuY29sbGVjdGlvbk5hbWV9YCxcbiAgICAgIF9TdGFydDogYF9GaWxlc0NvbGxlY3Rpb25TdGFydF8ke3RoaXMuY29sbGVjdGlvbk5hbWV9YCxcbiAgICAgIF9SZW1vdmU6IGBfRmlsZXNDb2xsZWN0aW9uUmVtb3ZlXyR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gXG4gICAgfTtcblxuICAgIHRoaXMub24oJ19oYW5kbGVVcGxvYWQnLCB0aGlzLl9oYW5kbGVVcGxvYWQpO1xuICAgIHRoaXMub24oJ19maW5pc2hVcGxvYWQnLCB0aGlzLl9maW5pc2hVcGxvYWQpO1xuICAgIHRoaXMuX2hhbmRsZVVwbG9hZFN5bmMgPSBNZXRlb3Iud3JhcEFzeW5jKHRoaXMuX2hhbmRsZVVwbG9hZC5iaW5kKHRoaXMpKTtcblxuICAgIGlmICh0aGlzLmRpc2FibGVVcGxvYWQgJiYgdGhpcy5kaXNhYmxlRG93bmxvYWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoKGh0dHBSZXEsIGh0dHBSZXNwLCBuZXh0KSA9PiB7XG4gICAgICBpZiAodGhpcy5hbGxvd2VkT3JpZ2lucyAmJiBodHRwUmVxLl9wYXJzZWRVcmwucGF0aC5pbmNsdWRlcyhgJHt0aGlzLmRvd25sb2FkUm91dGV9L2ApICYmICFodHRwUmVzcC5oZWFkZXJzU2VudCkge1xuICAgICAgICBpZiAodGhpcy5hbGxvd2VkT3JpZ2lucy50ZXN0KGh0dHBSZXEuaGVhZGVycy5vcmlnaW4pKSB7XG4gICAgICAgICAgaHR0cFJlc3Auc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1BbGxvdy1DcmVkZW50aWFscycsICd0cnVlJyk7XG4gICAgICAgICAgaHR0cFJlc3Auc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nLCBodHRwUmVxLmhlYWRlcnMub3JpZ2luKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChodHRwUmVxLm1ldGhvZCA9PT0gJ09QVElPTlMnKSB7XG4gICAgICAgICAgaHR0cFJlc3Auc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzJywgJ0dFVCwgUE9TVCwgT1BUSU9OUycpO1xuICAgICAgICAgIGh0dHBSZXNwLnNldEhlYWRlcignQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycycsICdSYW5nZSwgQ29udGVudC1UeXBlLCB4LW10b2ssIHgtc3RhcnQsIHgtY2h1bmtpZCwgeC1maWxlaWQsIHgtZW9mJyk7XG4gICAgICAgICAgaHR0cFJlc3Auc2V0SGVhZGVyKCdBY2Nlc3MtQ29udHJvbC1FeHBvc2UtSGVhZGVycycsICdBY2NlcHQtUmFuZ2VzLCBDb250ZW50LUVuY29kaW5nLCBDb250ZW50LUxlbmd0aCwgQ29udGVudC1SYW5nZScpO1xuICAgICAgICAgIGh0dHBSZXNwLnNldEhlYWRlcignQWxsb3cnLCAnR0VULCBQT1NULCBPUFRJT05TJyk7XG4gICAgICAgICAgaHR0cFJlc3Aud3JpdGVIZWFkKDIwMCk7XG4gICAgICAgICAgaHR0cFJlc3AuZW5kKCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmICghdGhpcy5kaXNhYmxlVXBsb2FkICYmIGh0dHBSZXEuX3BhcnNlZFVybC5wYXRoLmluY2x1ZGVzKGAke3RoaXMuZG93bmxvYWRSb3V0ZX0vJHt0aGlzLmNvbGxlY3Rpb25OYW1lfS9fX3VwbG9hZGApKSB7XG4gICAgICAgIGlmIChodHRwUmVxLm1ldGhvZCAhPT0gJ1BPU1QnKSB7XG4gICAgICAgICAgbmV4dCgpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGhhbmRsZUVycm9yID0gKF9lcnJvcikgPT4ge1xuICAgICAgICAgIGxldCBlcnJvciA9IF9lcnJvcjtcbiAgICAgICAgICBjb25zb2xlLndhcm4oJ1tGaWxlc0NvbGxlY3Rpb25dIFtVcGxvYWRdIFtIVFRQXSBFeGNlcHRpb246JywgZXJyb3IpO1xuICAgICAgICAgIGNvbnNvbGUudHJhY2UoKTtcblxuICAgICAgICAgIGlmICghaHR0cFJlc3AuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgICAgIGh0dHBSZXNwLndyaXRlSGVhZCg1MDApO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmICghaHR0cFJlc3AuZmluaXNoZWQpIHtcbiAgICAgICAgICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KGVycm9yKSAmJiBoZWxwZXJzLmlzRnVuY3Rpb24oZXJyb3IudG9TdHJpbmcpKSB7XG4gICAgICAgICAgICAgIGVycm9yID0gZXJyb3IudG9TdHJpbmcoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCFoZWxwZXJzLmlzU3RyaW5nKGVycm9yKSkge1xuICAgICAgICAgICAgICBlcnJvciA9ICdVbmV4cGVjdGVkIGVycm9yISc7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGh0dHBSZXNwLmVuZChKU09OLnN0cmluZ2lmeSh7IGVycm9yIH0pKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgbGV0IGJvZHkgPSAnJztcbiAgICAgICAgY29uc3QgaGFuZGxlRGF0YSA9ICgpID0+IHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgbGV0IG9wdHM7XG4gICAgICAgICAgICBsZXQgcmVzdWx0O1xuICAgICAgICAgICAgbGV0IHVzZXIgPSB0aGlzLl9nZXRVc2VyKHtyZXF1ZXN0OiBodHRwUmVxLCByZXNwb25zZTogaHR0cFJlc3B9KTtcblxuICAgICAgICAgICAgaWYgKGh0dHBSZXEuaGVhZGVyc1sneC1zdGFydCddICE9PSAnMScpIHtcbiAgICAgICAgICAgICAgLy8gQ0hVTksgVVBMT0FEIFNDRU5BUklPOlxuICAgICAgICAgICAgICBvcHRzID0ge1xuICAgICAgICAgICAgICAgIGZpbGVJZDogaHR0cFJlcS5oZWFkZXJzWyd4LWZpbGVpZCddXG4gICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgaWYgKGh0dHBSZXEuaGVhZGVyc1sneC1lb2YnXSA9PT0gJzEnKSB7XG4gICAgICAgICAgICAgICAgb3B0cy5lb2YgPSB0cnVlO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG9wdHMuYmluRGF0YSA9IEJ1ZmZlci5mcm9tKGJvZHksICdiYXNlNjQnKTtcbiAgICAgICAgICAgICAgICBvcHRzLmNodW5rSWQgPSBwYXJzZUludChodHRwUmVxLmhlYWRlcnNbJ3gtY2h1bmtpZCddKTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGNvbnN0IF9jb250aW51ZVVwbG9hZCA9IHRoaXMuX2NvbnRpbnVlVXBsb2FkKG9wdHMuZmlsZUlkKTtcbiAgICAgICAgICAgICAgaWYgKCFfY29udGludWVVcGxvYWQpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwOCwgJ0NhblxcJ3QgY29udGludWUgdXBsb2FkLCBzZXNzaW9uIGV4cGlyZWQuIFN0YXJ0IHVwbG9hZCBhZ2Fpbi4nKTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICh7cmVzdWx0LCBvcHRzfSAgPSB0aGlzLl9wcmVwYXJlVXBsb2FkKE9iamVjdC5hc3NpZ24ob3B0cywgX2NvbnRpbnVlVXBsb2FkKSwgdXNlci51c2VySWQsICdIVFRQJykpO1xuXG4gICAgICAgICAgICAgIGlmIChvcHRzLmVvZikge1xuICAgICAgICAgICAgICAgIC8vIEZJTklTSCBVUExPQUQgU0NFTkFSSU86XG4gICAgICAgICAgICAgICAgdGhpcy5faGFuZGxlVXBsb2FkKHJlc3VsdCwgb3B0cywgKF9lcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgbGV0IGVycm9yID0gX2Vycm9yO1xuICAgICAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghaHR0cFJlc3AuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBodHRwUmVzcC53cml0ZUhlYWQoNTAwKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmICghaHR0cFJlc3AuZmluaXNoZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVscGVycy5pc09iamVjdChlcnJvcikgJiYgaGVscGVycy5pc0Z1bmN0aW9uKGVycm9yLnRvU3RyaW5nKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3IgPSBlcnJvci50b1N0cmluZygpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgIGlmICghaGVscGVycy5pc1N0cmluZyhlcnJvcikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yID0gJ1VuZXhwZWN0ZWQgZXJyb3IhJztcbiAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICBodHRwUmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkoeyBlcnJvciB9KSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgaWYgKCFodHRwUmVzcC5oZWFkZXJzU2VudCkge1xuICAgICAgICAgICAgICAgICAgICBodHRwUmVzcC53cml0ZUhlYWQoMjAwKTtcbiAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgaWYgKGhlbHBlcnMuaXNPYmplY3QocmVzdWx0LmZpbGUpICYmIHJlc3VsdC5maWxlLm1ldGEpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LmZpbGUubWV0YSA9IGZpeEpTT05TdHJpbmdpZnkocmVzdWx0LmZpbGUubWV0YSk7XG4gICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgIGlmICghaHR0cFJlc3AuZmluaXNoZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgaHR0cFJlc3AuZW5kKEpTT04uc3RyaW5naWZ5KHJlc3VsdCkpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIHRoaXMuZW1pdCgnX2hhbmRsZVVwbG9hZCcsIHJlc3VsdCwgb3B0cywgTk9PUCk7XG5cbiAgICAgICAgICAgICAgaWYgKCFodHRwUmVzcC5oZWFkZXJzU2VudCkge1xuICAgICAgICAgICAgICAgIGh0dHBSZXNwLndyaXRlSGVhZCgyMDQpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGlmICghaHR0cFJlc3AuZmluaXNoZWQpIHtcbiAgICAgICAgICAgICAgICBodHRwUmVzcC5lbmQoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy8gU1RBUlQgU0NFTkFSSU86XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgb3B0cyA9IEpTT04ucGFyc2UoYm9keSk7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGpzb25FcnIpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdDYW5cXCd0IHBhcnNlIGluY29taW5nIEpTT04gZnJvbSBDbGllbnQgb24gWy5pbnNlcnQoKSB8IHVwbG9hZF0sIHNvbWV0aGluZyB3ZW50IHdyb25nIScsIGpzb25FcnIpO1xuICAgICAgICAgICAgICAgIG9wdHMgPSB7ZmlsZToge319O1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgaWYgKCFoZWxwZXJzLmlzT2JqZWN0KG9wdHMuZmlsZSkpIHtcbiAgICAgICAgICAgICAgICBvcHRzLmZpbGUgPSB7fTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZSBTdGFydCBIVFRQXSAke29wdHMuZmlsZS5uYW1lIHx8ICdbbm8tbmFtZV0nfSAtICR7b3B0cy5maWxlSWR9YCk7XG4gICAgICAgICAgICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KG9wdHMuZmlsZSkgJiYgb3B0cy5maWxlLm1ldGEpIHtcbiAgICAgICAgICAgICAgICBvcHRzLmZpbGUubWV0YSA9IGZpeEpTT05QYXJzZShvcHRzLmZpbGUubWV0YSk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBvcHRzLl9fX3MgPSB0cnVlO1xuICAgICAgICAgICAgICAoe3Jlc3VsdH0gPSB0aGlzLl9wcmVwYXJlVXBsb2FkKGhlbHBlcnMuY2xvbmUob3B0cyksIHVzZXIudXNlcklkLCAnSFRUUCBTdGFydCBNZXRob2QnKSk7XG5cbiAgICAgICAgICAgICAgaWYgKHRoaXMuY29sbGVjdGlvbi5maW5kT25lKHJlc3VsdC5faWQpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDAsICdDYW5cXCd0IHN0YXJ0IHVwbG9hZCwgZGF0YSBzdWJzdGl0dXRpb24gZGV0ZWN0ZWQhJyk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBvcHRzLl9pZCA9IG9wdHMuZmlsZUlkO1xuICAgICAgICAgICAgICBvcHRzLmNyZWF0ZWRBdCA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgIG9wdHMubWF4TGVuZ3RoID0gb3B0cy5maWxlTGVuZ3RoO1xuICAgICAgICAgICAgICB0aGlzLl9wcmVDb2xsZWN0aW9uLmluc2VydChoZWxwZXJzLm9taXQob3B0cywgJ19fX3MnKSk7XG4gICAgICAgICAgICAgIHRoaXMuX2NyZWF0ZVN0cmVhbShyZXN1bHQuX2lkLCByZXN1bHQucGF0aCwgaGVscGVycy5vbWl0KG9wdHMsICdfX19zJykpO1xuXG4gICAgICAgICAgICAgIGlmIChvcHRzLnJldHVybk1ldGEpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWh0dHBSZXNwLmhlYWRlcnNTZW50KSB7XG4gICAgICAgICAgICAgICAgICBodHRwUmVzcC53cml0ZUhlYWQoMjAwKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAoIWh0dHBSZXNwLmZpbmlzaGVkKSB7XG4gICAgICAgICAgICAgICAgICBodHRwUmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICB1cGxvYWRSb3V0ZTogYCR7dGhpcy5kb3dubG9hZFJvdXRlfS8ke3RoaXMuY29sbGVjdGlvbk5hbWV9L19fdXBsb2FkYCxcbiAgICAgICAgICAgICAgICAgICAgZmlsZTogcmVzdWx0XG4gICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmICghaHR0cFJlc3AuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgICAgICAgICAgIGh0dHBSZXNwLndyaXRlSGVhZCgyMDQpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmICghaHR0cFJlc3AuZmluaXNoZWQpIHtcbiAgICAgICAgICAgICAgICAgIGh0dHBSZXNwLmVuZCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gY2F0Y2ggKGh0dHBSZXNwRXJyKSB7XG4gICAgICAgICAgICBoYW5kbGVFcnJvcihodHRwUmVzcEVycik7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIGh0dHBSZXEuc2V0VGltZW91dCgyMDAwMCwgaGFuZGxlRXJyb3IpO1xuICAgICAgICBpZiAodHlwZW9mIGh0dHBSZXEuYm9keSA9PT0gJ29iamVjdCcgJiYgT2JqZWN0LmtleXMoaHR0cFJlcS5ib2R5KS5sZW5ndGggIT09IDApIHtcbiAgICAgICAgICBib2R5ID0gSlNPTi5zdHJpbmdpZnkoaHR0cFJlcS5ib2R5KTtcbiAgICAgICAgICBoYW5kbGVEYXRhKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaHR0cFJlcS5vbignZGF0YScsIChkYXRhKSA9PiBib3VuZCgoKSA9PiB7XG4gICAgICAgICAgICBib2R5ICs9IGRhdGE7XG4gICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgaHR0cFJlcS5vbignZW5kJywgKCkgPT4gYm91bmQoKCkgPT4ge1xuICAgICAgICAgICAgaGFuZGxlRGF0YSgpO1xuICAgICAgICAgIH0pKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGlmICghdGhpcy5kaXNhYmxlRG93bmxvYWQpIHtcbiAgICAgICAgbGV0IHVyaTtcblxuICAgICAgICBpZiAoIXRoaXMucHVibGljKSB7XG4gICAgICAgICAgaWYgKGh0dHBSZXEuX3BhcnNlZFVybC5wYXRoLmluY2x1ZGVzKGAke3RoaXMuZG93bmxvYWRSb3V0ZX0vJHt0aGlzLmNvbGxlY3Rpb25OYW1lfWApKSB7XG4gICAgICAgICAgICB1cmkgPSBodHRwUmVxLl9wYXJzZWRVcmwucGF0aC5yZXBsYWNlKGAke3RoaXMuZG93bmxvYWRSb3V0ZX0vJHt0aGlzLmNvbGxlY3Rpb25OYW1lfWAsICcnKTtcbiAgICAgICAgICAgIGlmICh1cmkuaW5kZXhPZignLycpID09PSAwKSB7XG4gICAgICAgICAgICAgIHVyaSA9IHVyaS5zdWJzdHJpbmcoMSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IHVyaXMgPSB1cmkuc3BsaXQoJy8nKTtcbiAgICAgICAgICAgIGlmICh1cmlzLmxlbmd0aCA9PT0gMykge1xuICAgICAgICAgICAgICBjb25zdCBwYXJhbXMgPSB7XG4gICAgICAgICAgICAgICAgX2lkOiB1cmlzWzBdLFxuICAgICAgICAgICAgICAgIHF1ZXJ5OiBodHRwUmVxLl9wYXJzZWRVcmwucXVlcnkgPyBub2RlUXMucGFyc2UoaHR0cFJlcS5fcGFyc2VkVXJsLnF1ZXJ5KSA6IHt9LFxuICAgICAgICAgICAgICAgIG5hbWU6IHVyaXNbMl0uc3BsaXQoJz8nKVswXSxcbiAgICAgICAgICAgICAgICB2ZXJzaW9uOiB1cmlzWzFdXG4gICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgY29uc3QgaHR0cCA9IHtyZXF1ZXN0OiBodHRwUmVxLCByZXNwb25zZTogaHR0cFJlc3AsIHBhcmFtc307XG4gICAgICAgICAgICAgIGlmICh0aGlzLmludGVyY2VwdFJlcXVlc3QgJiYgaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMuaW50ZXJjZXB0UmVxdWVzdCkgJiYgdGhpcy5pbnRlcmNlcHRSZXF1ZXN0KGh0dHApID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgaWYgKHRoaXMuX2NoZWNrQWNjZXNzKGh0dHApKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5kb3dubG9hZChodHRwLCB1cmlzWzFdLCB0aGlzLmNvbGxlY3Rpb24uZmluZE9uZSh1cmlzWzBdKSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIG5leHQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbmV4dCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoaHR0cFJlcS5fcGFyc2VkVXJsLnBhdGguaW5jbHVkZXMoYCR7dGhpcy5kb3dubG9hZFJvdXRlfWApKSB7XG4gICAgICAgICAgICB1cmkgPSBodHRwUmVxLl9wYXJzZWRVcmwucGF0aC5yZXBsYWNlKGAke3RoaXMuZG93bmxvYWRSb3V0ZX1gLCAnJyk7XG4gICAgICAgICAgICBpZiAodXJpLmluZGV4T2YoJy8nKSA9PT0gMCkge1xuICAgICAgICAgICAgICB1cmkgPSB1cmkuc3Vic3RyaW5nKDEpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCB1cmlzID0gdXJpLnNwbGl0KCcvJyk7XG4gICAgICAgICAgICBsZXQgX2ZpbGUgPSB1cmlzW3VyaXMubGVuZ3RoIC0gMV07XG4gICAgICAgICAgICBpZiAoX2ZpbGUpIHtcbiAgICAgICAgICAgICAgbGV0IHZlcnNpb247XG4gICAgICAgICAgICAgIGlmIChfZmlsZS5pbmNsdWRlcygnLScpKSB7XG4gICAgICAgICAgICAgICAgdmVyc2lvbiA9IF9maWxlLnNwbGl0KCctJylbMF07XG4gICAgICAgICAgICAgICAgX2ZpbGUgICA9IF9maWxlLnNwbGl0KCctJylbMV0uc3BsaXQoJz8nKVswXTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB2ZXJzaW9uID0gJ29yaWdpbmFsJztcbiAgICAgICAgICAgICAgICBfZmlsZSAgID0gX2ZpbGUuc3BsaXQoJz8nKVswXTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIGNvbnN0IHBhcmFtcyA9IHtcbiAgICAgICAgICAgICAgICBxdWVyeTogaHR0cFJlcS5fcGFyc2VkVXJsLnF1ZXJ5ID8gbm9kZVFzLnBhcnNlKGh0dHBSZXEuX3BhcnNlZFVybC5xdWVyeSkgOiB7fSxcbiAgICAgICAgICAgICAgICBmaWxlOiBfZmlsZSxcbiAgICAgICAgICAgICAgICBfaWQ6IF9maWxlLnNwbGl0KCcuJylbMF0sXG4gICAgICAgICAgICAgICAgdmVyc2lvbixcbiAgICAgICAgICAgICAgICBuYW1lOiBfZmlsZVxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICBjb25zdCBodHRwID0ge3JlcXVlc3Q6IGh0dHBSZXEsIHJlc3BvbnNlOiBodHRwUmVzcCwgcGFyYW1zfTtcbiAgICAgICAgICAgICAgaWYgKHRoaXMuaW50ZXJjZXB0UmVxdWVzdCAmJiBoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5pbnRlcmNlcHRSZXF1ZXN0KSAmJiB0aGlzLmludGVyY2VwdFJlcXVlc3QoaHR0cCkgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgdGhpcy5kb3dubG9hZChodHRwLCB2ZXJzaW9uLCB0aGlzLmNvbGxlY3Rpb24uZmluZE9uZShwYXJhbXMuX2lkKSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBuZXh0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5leHQoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbmV4dCgpO1xuICAgIH0pO1xuXG4gICAgaWYgKCF0aGlzLmRpc2FibGVVcGxvYWQpIHtcbiAgICAgIGNvbnN0IF9tZXRob2RzID0ge307XG5cbiAgICAgIC8vIE1ldGhvZCB1c2VkIHRvIHJlbW92ZSBmaWxlXG4gICAgICAvLyBmcm9tIENsaWVudCBzaWRlXG4gICAgICBfbWV0aG9kc1t0aGlzLl9tZXRob2ROYW1lcy5fUmVtb3ZlXSA9IGZ1bmN0aW9uIChzZWxlY3Rvcikge1xuICAgICAgICBjaGVjayhzZWxlY3RvciwgTWF0Y2guT25lT2YoU3RyaW5nLCBPYmplY3QpKTtcbiAgICAgICAgc2VsZi5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtVbmxpbmsgTWV0aG9kXSBbLnJlbW92ZSgke3NlbGVjdG9yfSldYCk7XG5cbiAgICAgICAgaWYgKHNlbGYuYWxsb3dDbGllbnRDb2RlKSB7XG4gICAgICAgICAgaWYgKHNlbGYub25CZWZvcmVSZW1vdmUgJiYgaGVscGVycy5pc0Z1bmN0aW9uKHNlbGYub25CZWZvcmVSZW1vdmUpKSB7XG4gICAgICAgICAgICBjb25zdCB1c2VySWQgPSB0aGlzLnVzZXJJZDtcbiAgICAgICAgICAgIGNvbnN0IHVzZXJGdW5jcyA9IHtcbiAgICAgICAgICAgICAgdXNlcklkOiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgICAgdXNlcigpIHtcbiAgICAgICAgICAgICAgICBpZiAoTWV0ZW9yLnVzZXJzKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmRPbmUodXNlcklkKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIGlmICghc2VsZi5vbkJlZm9yZVJlbW92ZS5jYWxsKHVzZXJGdW5jcywgKHNlbGYuZmluZChzZWxlY3RvcikgfHwgbnVsbCkpKSB7XG4gICAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCAnW0ZpbGVzQ29sbGVjdGlvbl0gW3JlbW92ZV0gTm90IHBlcm1pdHRlZCEnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCBjdXJzb3IgPSBzZWxmLmZpbmQoc2VsZWN0b3IpO1xuICAgICAgICAgIGlmIChjdXJzb3IuY291bnQoKSA+IDApIHtcbiAgICAgICAgICAgIHNlbGYucmVtb3ZlKHNlbGVjdG9yKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwNCwgJ0N1cnNvciBpcyBlbXB0eSwgbm8gZmlsZXMgaXMgcmVtb3ZlZCcpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAxLCAnW0ZpbGVzQ29sbGVjdGlvbl0gW3JlbW92ZV0gUnVuIGNvZGUgZnJvbSBjbGllbnQgaXMgbm90IGFsbG93ZWQhJyk7XG4gICAgICAgIH1cbiAgICAgIH07XG5cblxuICAgICAgLy8gTWV0aG9kIHVzZWQgdG8gcmVjZWl2ZSBcImZpcnN0IGJ5dGVcIiBvZiB1cGxvYWRcbiAgICAgIC8vIGFuZCBhbGwgZmlsZSdzIG1ldGEtZGF0YSwgc29cbiAgICAgIC8vIGl0IHdvbid0IGJlIHRyYW5zZmVycmVkIHdpdGggZXZlcnkgY2h1bmtcbiAgICAgIC8vIEJhc2ljYWxseSBpdCBwcmVwYXJlcyBldmVyeXRoaW5nXG4gICAgICAvLyBTbyB1c2VyIGNhbiBwYXVzZS9kaXNjb25uZWN0IGFuZFxuICAgICAgLy8gY29udGludWUgdXBsb2FkIGxhdGVyLCBkdXJpbmcgYGNvbnRpbnVlVXBsb2FkVFRMYFxuICAgICAgX21ldGhvZHNbdGhpcy5fbWV0aG9kTmFtZXMuX1N0YXJ0XSA9IGZ1bmN0aW9uIChvcHRzLCByZXR1cm5NZXRhKSB7XG4gICAgICAgIGNoZWNrKG9wdHMsIHtcbiAgICAgICAgICBmaWxlOiBPYmplY3QsXG4gICAgICAgICAgZmlsZUlkOiBTdHJpbmcsXG4gICAgICAgICAgRlNOYW1lOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgICAgICAgIGNodW5rU2l6ZTogTnVtYmVyLFxuICAgICAgICAgIGZpbGVMZW5ndGg6IE51bWJlclxuICAgICAgICB9KTtcblxuICAgICAgICBjaGVjayhyZXR1cm5NZXRhLCBNYXRjaC5PcHRpb25hbChCb29sZWFuKSk7XG5cbiAgICAgICAgc2VsZi5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtGaWxlIFN0YXJ0IE1ldGhvZF0gJHtvcHRzLmZpbGUubmFtZX0gLSAke29wdHMuZmlsZUlkfWApO1xuICAgICAgICBvcHRzLl9fX3MgPSB0cnVlO1xuICAgICAgICBjb25zdCB7IHJlc3VsdCB9ID0gc2VsZi5fcHJlcGFyZVVwbG9hZChoZWxwZXJzLmNsb25lKG9wdHMpLCB0aGlzLnVzZXJJZCwgJ0REUCBTdGFydCBNZXRob2QnKTtcblxuICAgICAgICBpZiAoc2VsZi5jb2xsZWN0aW9uLmZpbmRPbmUocmVzdWx0Ll9pZCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMCwgJ0NhblxcJ3Qgc3RhcnQgdXBsb2FkLCBkYXRhIHN1YnN0aXR1dGlvbiBkZXRlY3RlZCEnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIG9wdHMuX2lkICAgICAgID0gb3B0cy5maWxlSWQ7XG4gICAgICAgIG9wdHMuY3JlYXRlZEF0ID0gbmV3IERhdGUoKTtcbiAgICAgICAgb3B0cy5tYXhMZW5ndGggPSBvcHRzLmZpbGVMZW5ndGg7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgc2VsZi5fcHJlQ29sbGVjdGlvbi5pbnNlcnQoaGVscGVycy5vbWl0KG9wdHMsICdfX19zJykpO1xuICAgICAgICAgIHNlbGYuX2NyZWF0ZVN0cmVhbShyZXN1bHQuX2lkLCByZXN1bHQucGF0aCwgaGVscGVycy5vbWl0KG9wdHMsICdfX19zJykpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgc2VsZi5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtGaWxlIFN0YXJ0IE1ldGhvZF0gW0VYQ0VQVElPTjpdICR7b3B0cy5maWxlLm5hbWV9IC0gJHtvcHRzLmZpbGVJZH1gLCBlKTtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDUwMCwgJ0NhblxcJ3Qgc3RhcnQnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChyZXR1cm5NZXRhKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHVwbG9hZFJvdXRlOiBgJHtzZWxmLmRvd25sb2FkUm91dGV9LyR7c2VsZi5jb2xsZWN0aW9uTmFtZX0vX191cGxvYWRgLFxuICAgICAgICAgICAgZmlsZTogcmVzdWx0XG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH07XG5cblxuICAgICAgLy8gTWV0aG9kIHVzZWQgdG8gd3JpdGUgZmlsZSBjaHVua3NcbiAgICAgIC8vIGl0IHJlY2VpdmVzIHZlcnkgbGltaXRlZCBhbW91bnQgb2YgbWV0YS1kYXRhXG4gICAgICAvLyBUaGlzIG1ldGhvZCBhbHNvIHJlc3BvbnNpYmxlIGZvciBFT0ZcbiAgICAgIF9tZXRob2RzW3RoaXMuX21ldGhvZE5hbWVzLl9Xcml0ZV0gPSBmdW5jdGlvbiAoX29wdHMpIHtcbiAgICAgICAgbGV0IG9wdHMgPSBfb3B0cztcbiAgICAgICAgbGV0IHJlc3VsdDtcbiAgICAgICAgY2hlY2sob3B0cywge1xuICAgICAgICAgIGVvZjogTWF0Y2guT3B0aW9uYWwoQm9vbGVhbiksXG4gICAgICAgICAgZmlsZUlkOiBTdHJpbmcsXG4gICAgICAgICAgYmluRGF0YTogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcbiAgICAgICAgICBjaHVua0lkOiBNYXRjaC5PcHRpb25hbChOdW1iZXIpXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChvcHRzLmJpbkRhdGEpIHtcbiAgICAgICAgICBvcHRzLmJpbkRhdGEgPSBCdWZmZXIuZnJvbShvcHRzLmJpbkRhdGEsICdiYXNlNjQnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IF9jb250aW51ZVVwbG9hZCA9IHNlbGYuX2NvbnRpbnVlVXBsb2FkKG9wdHMuZmlsZUlkKTtcbiAgICAgICAgaWYgKCFfY29udGludWVVcGxvYWQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwOCwgJ0NhblxcJ3QgY29udGludWUgdXBsb2FkLCBzZXNzaW9uIGV4cGlyZWQuIFN0YXJ0IHVwbG9hZCBhZ2Fpbi4nKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICAoe3Jlc3VsdCwgb3B0c30gPSBzZWxmLl9wcmVwYXJlVXBsb2FkKE9iamVjdC5hc3NpZ24ob3B0cywgX2NvbnRpbnVlVXBsb2FkKSwgdGhpcy51c2VySWQsICdERFAnKSk7XG5cbiAgICAgICAgaWYgKG9wdHMuZW9mKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiBzZWxmLl9oYW5kbGVVcGxvYWRTeW5jKHJlc3VsdCwgb3B0cyk7XG4gICAgICAgICAgfSBjYXRjaCAoaGFuZGxlVXBsb2FkRXJyKSB7XG4gICAgICAgICAgICBzZWxmLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW1dyaXRlIE1ldGhvZF0gW0REUF0gRXhjZXB0aW9uOicsIGhhbmRsZVVwbG9hZEVycik7XG4gICAgICAgICAgICB0aHJvdyBoYW5kbGVVcGxvYWRFcnI7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNlbGYuZW1pdCgnX2hhbmRsZVVwbG9hZCcsIHJlc3VsdCwgb3B0cywgTk9PUCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9O1xuXG4gICAgICAvLyBNZXRob2QgdXNlZCB0byBBYm9ydCB1cGxvYWRcbiAgICAgIC8vIC0gRnJlZWluZyBtZW1vcnkgYnkgZW5kaW5nIHdyaXRhYmxlU3RyZWFtc1xuICAgICAgLy8gLSBSZW1vdmluZyB0ZW1wb3JhcnkgcmVjb3JkIGZyb20gQF9wcmVDb2xsZWN0aW9uXG4gICAgICAvLyAtIFJlbW92aW5nIHJlY29yZCBmcm9tIEBjb2xsZWN0aW9uXG4gICAgICAvLyAtIC51bmxpbmsoKWluZyBjaHVua3MgZnJvbSBGU1xuICAgICAgX21ldGhvZHNbdGhpcy5fbWV0aG9kTmFtZXMuX0Fib3J0XSA9IGZ1bmN0aW9uIChfaWQpIHtcbiAgICAgICAgY2hlY2soX2lkLCBTdHJpbmcpO1xuXG4gICAgICAgIGNvbnN0IF9jb250aW51ZVVwbG9hZCA9IHNlbGYuX2NvbnRpbnVlVXBsb2FkKF9pZCk7XG4gICAgICAgIHNlbGYuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbQWJvcnQgTWV0aG9kXTogJHtfaWR9IC0gJHsoaGVscGVycy5pc09iamVjdChfY29udGludWVVcGxvYWQuZmlsZSkgPyBfY29udGludWVVcGxvYWQuZmlsZS5wYXRoIDogJycpfWApO1xuXG4gICAgICAgIGlmIChzZWxmLl9jdXJyZW50VXBsb2FkcyAmJiBzZWxmLl9jdXJyZW50VXBsb2Fkc1tfaWRdKSB7XG4gICAgICAgICAgc2VsZi5fY3VycmVudFVwbG9hZHNbX2lkXS5zdG9wKCk7XG4gICAgICAgICAgc2VsZi5fY3VycmVudFVwbG9hZHNbX2lkXS5hYm9ydCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKF9jb250aW51ZVVwbG9hZCkge1xuICAgICAgICAgIHNlbGYuX3ByZUNvbGxlY3Rpb24ucmVtb3ZlKHtfaWR9KTtcbiAgICAgICAgICBzZWxmLnJlbW92ZSh7X2lkfSk7XG4gICAgICAgICAgaWYgKGhlbHBlcnMuaXNPYmplY3QoX2NvbnRpbnVlVXBsb2FkLmZpbGUpICYmIF9jb250aW51ZVVwbG9hZC5maWxlLnBhdGgpIHtcbiAgICAgICAgICAgIHNlbGYudW5saW5rKHtfaWQsIHBhdGg6IF9jb250aW51ZVVwbG9hZC5maWxlLnBhdGh9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9O1xuXG4gICAgICBNZXRlb3IubWV0aG9kcyhfbWV0aG9kcyk7XG4gICAgfVxuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIF9wcmVwYXJlVXBsb2FkXG4gICAqIEBzdW1tYXJ5IEludGVybmFsIG1ldGhvZC4gVXNlZCB0byBvcHRpbWl6ZSByZWNlaXZlZCBkYXRhIGFuZCBjaGVjayB1cGxvYWQgcGVybWlzc2lvblxuICAgKiBAcmV0dXJucyB7T2JqZWN0fVxuICAgKi9cbiAgX3ByZXBhcmVVcGxvYWQob3B0cyA9IHt9LCB1c2VySWQsIHRyYW5zcG9ydCkge1xuICAgIGxldCBjdHg7XG4gICAgaWYgKCFoZWxwZXJzLmlzQm9vbGVhbihvcHRzLmVvZikpIHtcbiAgICAgIG9wdHMuZW9mID0gZmFsc2U7XG4gICAgfVxuXG4gICAgaWYgKCFvcHRzLmJpbkRhdGEpIHtcbiAgICAgIG9wdHMuYmluRGF0YSA9ICdFT0YnO1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc051bWJlcihvcHRzLmNodW5rSWQpKSB7XG4gICAgICBvcHRzLmNodW5rSWQgPSAtMTtcbiAgICB9XG5cbiAgICBpZiAoIWhlbHBlcnMuaXNTdHJpbmcob3B0cy5GU05hbWUpKSB7XG4gICAgICBvcHRzLkZTTmFtZSA9IG9wdHMuZmlsZUlkO1xuICAgIH1cblxuICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbVXBsb2FkXSBbJHt0cmFuc3BvcnR9XSBHb3QgIyR7b3B0cy5jaHVua0lkfS8ke29wdHMuZmlsZUxlbmd0aH0gY2h1bmtzLCBkc3Q6ICR7b3B0cy5maWxlLm5hbWUgfHwgb3B0cy5maWxlLmZpbGVOYW1lfWApO1xuXG4gICAgY29uc3QgZmlsZU5hbWUgPSB0aGlzLl9nZXRGaWxlTmFtZShvcHRzLmZpbGUpO1xuICAgIGNvbnN0IHtleHRlbnNpb24sIGV4dGVuc2lvbldpdGhEb3R9ID0gdGhpcy5fZ2V0RXh0KGZpbGVOYW1lKTtcblxuICAgIGlmICghaGVscGVycy5pc09iamVjdChvcHRzLmZpbGUubWV0YSkpIHtcbiAgICAgIG9wdHMuZmlsZS5tZXRhID0ge307XG4gICAgfVxuXG4gICAgbGV0IHJlc3VsdCAgICAgICA9IG9wdHMuZmlsZTtcbiAgICByZXN1bHQubmFtZSAgICAgID0gZmlsZU5hbWU7XG4gICAgcmVzdWx0Lm1ldGEgICAgICA9IG9wdHMuZmlsZS5tZXRhO1xuICAgIHJlc3VsdC5leHRlbnNpb24gPSBleHRlbnNpb247XG4gICAgcmVzdWx0LmV4dCAgICAgICA9IGV4dGVuc2lvbjtcbiAgICByZXN1bHQuX2lkICAgICAgID0gb3B0cy5maWxlSWQ7XG4gICAgcmVzdWx0LnVzZXJJZCAgICA9IHVzZXJJZCB8fCBudWxsO1xuICAgIG9wdHMuRlNOYW1lICAgICAgPSBvcHRzLkZTTmFtZS5yZXBsYWNlKC8oW15hLXowLTlcXC1cXF9dKykvZ2ksICctJyk7XG4gICAgcmVzdWx0LnBhdGggICAgICA9IGAke3RoaXMuc3RvcmFnZVBhdGgocmVzdWx0KX0ke25vZGVQYXRoLnNlcH0ke29wdHMuRlNOYW1lfSR7ZXh0ZW5zaW9uV2l0aERvdH1gO1xuICAgIHJlc3VsdCAgICAgICAgICAgPSBPYmplY3QuYXNzaWduKHJlc3VsdCwgdGhpcy5fZGF0YVRvU2NoZW1hKHJlc3VsdCkpO1xuXG4gICAgaWYgKHRoaXMub25CZWZvcmVVcGxvYWQgJiYgaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMub25CZWZvcmVVcGxvYWQpKSB7XG4gICAgICBjdHggPSBPYmplY3QuYXNzaWduKHtcbiAgICAgICAgZmlsZTogb3B0cy5maWxlXG4gICAgICB9LCB7XG4gICAgICAgIGNodW5rSWQ6IG9wdHMuY2h1bmtJZCxcbiAgICAgICAgdXNlcklkOiByZXN1bHQudXNlcklkLFxuICAgICAgICB1c2VyKCkge1xuICAgICAgICAgIGlmIChNZXRlb3IudXNlcnMgJiYgcmVzdWx0LnVzZXJJZCkge1xuICAgICAgICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kT25lKHJlc3VsdC51c2VySWQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfSxcbiAgICAgICAgZW9mOiBvcHRzLmVvZlxuICAgICAgfSk7XG4gICAgICBjb25zdCBpc1VwbG9hZEFsbG93ZWQgPSB0aGlzLm9uQmVmb3JlVXBsb2FkLmNhbGwoY3R4LCByZXN1bHQpO1xuXG4gICAgICBpZiAoaXNVcGxvYWRBbGxvd2VkICE9PSB0cnVlKSB7XG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNDAzLCBoZWxwZXJzLmlzU3RyaW5nKGlzVXBsb2FkQWxsb3dlZCkgPyBpc1VwbG9hZEFsbG93ZWQgOiAnQG9uQmVmb3JlVXBsb2FkKCkgcmV0dXJuZWQgZmFsc2UnKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmICgob3B0cy5fX19zID09PSB0cnVlKSAmJiB0aGlzLm9uSW5pdGlhdGVVcGxvYWQgJiYgaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMub25Jbml0aWF0ZVVwbG9hZCkpIHtcbiAgICAgICAgICB0aGlzLm9uSW5pdGlhdGVVcGxvYWQuY2FsbChjdHgsIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKChvcHRzLl9fX3MgPT09IHRydWUpICYmIHRoaXMub25Jbml0aWF0ZVVwbG9hZCAmJiBoZWxwZXJzLmlzRnVuY3Rpb24odGhpcy5vbkluaXRpYXRlVXBsb2FkKSkge1xuICAgICAgY3R4ID0gT2JqZWN0LmFzc2lnbih7XG4gICAgICAgIGZpbGU6IG9wdHMuZmlsZVxuICAgICAgfSwge1xuICAgICAgICBjaHVua0lkOiBvcHRzLmNodW5rSWQsXG4gICAgICAgIHVzZXJJZDogcmVzdWx0LnVzZXJJZCxcbiAgICAgICAgdXNlcigpIHtcbiAgICAgICAgICBpZiAoTWV0ZW9yLnVzZXJzICYmIHJlc3VsdC51c2VySWQpIHtcbiAgICAgICAgICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZE9uZShyZXN1bHQudXNlcklkKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH0sXG4gICAgICAgIGVvZjogb3B0cy5lb2ZcbiAgICAgIH0pO1xuICAgICAgdGhpcy5vbkluaXRpYXRlVXBsb2FkLmNhbGwoY3R4LCByZXN1bHQpO1xuICAgIH1cblxuICAgIHJldHVybiB7cmVzdWx0LCBvcHRzfTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSBfZmluaXNoVXBsb2FkXG4gICAqIEBzdW1tYXJ5IEludGVybmFsIG1ldGhvZC4gRmluaXNoIHVwbG9hZCwgY2xvc2UgV3JpdGFibGUgc3RyZWFtLCBhZGQgcmVjb3JkIHRvIE1vbmdvREIgYW5kIGZsdXNoIHVzZWQgbWVtb3J5XG4gICAqIEByZXR1cm5zIHt1bmRlZmluZWR9XG4gICAqL1xuICBfZmluaXNoVXBsb2FkKHJlc3VsdCwgb3B0cywgY2IpIHtcbiAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW1VwbG9hZF0gW2ZpbmlzaChpbmcpVXBsb2FkXSAtPiAke3Jlc3VsdC5wYXRofWApO1xuICAgIGZzLmNobW9kKHJlc3VsdC5wYXRoLCB0aGlzLnBlcm1pc3Npb25zLCBOT09QKTtcbiAgICByZXN1bHQudHlwZSAgID0gdGhpcy5fZ2V0TWltZVR5cGUob3B0cy5maWxlKTtcbiAgICByZXN1bHQucHVibGljID0gdGhpcy5wdWJsaWM7XG4gICAgdGhpcy5fdXBkYXRlRmlsZVR5cGVzKHJlc3VsdCk7XG5cbiAgICB0aGlzLmNvbGxlY3Rpb24uaW5zZXJ0KGhlbHBlcnMuY2xvbmUocmVzdWx0KSwgKGNvbEluc2VydCwgX2lkKSA9PiB7XG4gICAgICBpZiAoY29sSW5zZXJ0KSB7XG4gICAgICAgIGNiICYmIGNiKGNvbEluc2VydCk7XG4gICAgICAgIHRoaXMuX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbVXBsb2FkXSBbX2ZpbmlzaFVwbG9hZF0gW2luc2VydF0gRXJyb3I6JywgY29sSW5zZXJ0KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3ByZUNvbGxlY3Rpb24udXBkYXRlKHtfaWQ6IG9wdHMuZmlsZUlkfSwgeyRzZXQ6IHtpc0ZpbmlzaGVkOiB0cnVlfX0sIChwcmVVcGRhdGVFcnJvcikgPT4ge1xuICAgICAgICAgIGlmIChwcmVVcGRhdGVFcnJvcikge1xuICAgICAgICAgICAgY2IgJiYgY2IocHJlVXBkYXRlRXJyb3IpO1xuICAgICAgICAgICAgdGhpcy5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtVcGxvYWRdIFtfZmluaXNoVXBsb2FkXSBbdXBkYXRlXSBFcnJvcjonLCBwcmVVcGRhdGVFcnJvcik7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlc3VsdC5faWQgPSBfaWQ7XG4gICAgICAgICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW1VwbG9hZF0gW2ZpbmlzaChlZClVcGxvYWRdIC0+ICR7cmVzdWx0LnBhdGh9YCk7XG4gICAgICAgICAgICB0aGlzLm9uQWZ0ZXJVcGxvYWQgJiYgdGhpcy5vbkFmdGVyVXBsb2FkLmNhbGwodGhpcywgcmVzdWx0KTtcbiAgICAgICAgICAgIHRoaXMuZW1pdCgnYWZ0ZXJVcGxvYWQnLCByZXN1bHQpO1xuICAgICAgICAgICAgY2IgJiYgY2IobnVsbCwgcmVzdWx0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIF9oYW5kbGVVcGxvYWRcbiAgICogQHN1bW1hcnkgSW50ZXJuYWwgbWV0aG9kIHRvIGhhbmRsZSB1cGxvYWQgcHJvY2VzcywgcGlwZSBpbmNvbWluZyBkYXRhIHRvIFdyaXRhYmxlIHN0cmVhbVxuICAgKiBAcmV0dXJucyB7dW5kZWZpbmVkfVxuICAgKi9cbiAgX2hhbmRsZVVwbG9hZChyZXN1bHQsIG9wdHMsIGNiKSB7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChvcHRzLmVvZikge1xuICAgICAgICB0aGlzLl9jdXJyZW50VXBsb2Fkc1tyZXN1bHQuX2lkXS5lbmQoKCkgPT4ge1xuICAgICAgICAgIHRoaXMuZW1pdCgnX2ZpbmlzaFVwbG9hZCcsIHJlc3VsdCwgb3B0cywgY2IpO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX2N1cnJlbnRVcGxvYWRzW3Jlc3VsdC5faWRdLndyaXRlKG9wdHMuY2h1bmtJZCwgb3B0cy5iaW5EYXRhLCBjYik7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdGhpcy5fZGVidWcoJ1tfaGFuZGxlVXBsb2FkXSBbRVhDRVBUSU9OOl0nLCBlKTtcbiAgICAgIGNiICYmIGNiKGUpO1xuICAgIH1cbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIF9nZXRNaW1lVHlwZVxuICAgKiBAcGFyYW0ge09iamVjdH0gZmlsZURhdGEgLSBGaWxlIE9iamVjdFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGZpbGUncyBtaW1lLXR5cGVcbiAgICogQHJldHVybnMge1N0cmluZ31cbiAgICovXG4gIF9nZXRNaW1lVHlwZShmaWxlRGF0YSkge1xuICAgIGxldCBtaW1lO1xuICAgIGNoZWNrKGZpbGVEYXRhLCBPYmplY3QpO1xuICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KGZpbGVEYXRhKSAmJiBmaWxlRGF0YS50eXBlKSB7XG4gICAgICBtaW1lID0gZmlsZURhdGEudHlwZTtcbiAgICB9XG5cbiAgICBpZiAoIW1pbWUgfHwgIWhlbHBlcnMuaXNTdHJpbmcobWltZSkpIHtcbiAgICAgIG1pbWUgPSAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJztcbiAgICB9XG4gICAgcmV0dXJuIG1pbWU7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSBfZ2V0VXNlcklkXG4gICAqIEBzdW1tYXJ5IFJldHVybnMgYHVzZXJJZGAgbWF0Y2hpbmcgdGhlIHhtdG9rIHRva2VuIGRlcml2ZWQgZnJvbSBNZXRlb3Iuc2VydmVyLnNlc3Npb25zXG4gICAqIEByZXR1cm5zIHtTdHJpbmd9XG4gICAqL1xuICBfZ2V0VXNlcklkKHhtdG9rKSB7XG4gICAgaWYgKCF4bXRvaykgcmV0dXJuIG51bGw7XG5cbiAgICAvLyB0aHJvdyBhbiBlcnJvciB1cG9uIGFuIHVuZXhwZWN0ZWQgdHlwZSBvZiBNZXRlb3Iuc2VydmVyLnNlc3Npb25zIGluIG9yZGVyIHRvIGlkZW50aWZ5IGJyZWFraW5nIGNoYW5nZXNcbiAgICBpZiAoIU1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnMgaW5zdGFuY2VvZiBNYXAgfHwgIWhlbHBlcnMuaXNPYmplY3QoTWV0ZW9yLnNlcnZlci5zZXNzaW9ucykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignUmVjZWl2ZWQgaW5jb21wYXRpYmxlIHR5cGUgb2YgTWV0ZW9yLnNlcnZlci5zZXNzaW9ucycpO1xuICAgIH1cblxuICAgIGlmIChNZXRlb3Iuc2VydmVyLnNlc3Npb25zIGluc3RhbmNlb2YgTWFwICYmIE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnMuaGFzKHhtdG9rKSAmJiBoZWxwZXJzLmlzT2JqZWN0KE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnMuZ2V0KHhtdG9rKSkpIHtcbiAgICAgIC8vIHRvIGJlIHVzZWQgd2l0aCA+PSBNZXRlb3IgMS44LjEgd2hlcmUgTWV0ZW9yLnNlcnZlci5zZXNzaW9ucyBpcyBhIE1hcFxuICAgICAgcmV0dXJuIE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnMuZ2V0KHhtdG9rKS51c2VySWQ7XG4gICAgfSBlbHNlIGlmIChoZWxwZXJzLmlzT2JqZWN0KE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnMpICYmIHhtdG9rIGluIE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnMgJiYgaGVscGVycy5pc09iamVjdChNZXRlb3Iuc2VydmVyLnNlc3Npb25zW3htdG9rXSkpIHtcbiAgICAgIC8vIHRvIGJlIHVzZWQgd2l0aCA8IE1ldGVvciAxLjguMSB3aGVyZSBNZXRlb3Iuc2VydmVyLnNlc3Npb25zIGlzIGFuIE9iamVjdFxuICAgICAgcmV0dXJuIE1ldGVvci5zZXJ2ZXIuc2Vzc2lvbnNbeG10b2tdLnVzZXJJZDtcbiAgICB9XG5cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIF9nZXRVc2VyXG4gICAqIEBzdW1tYXJ5IFJldHVybnMgb2JqZWN0IHdpdGggYHVzZXJJZGAgYW5kIGB1c2VyKClgIG1ldGhvZCB3aGljaCByZXR1cm4gdXNlcidzIG9iamVjdFxuICAgKiBAcmV0dXJucyB7T2JqZWN0fVxuICAgKi9cbiAgX2dldFVzZXIoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0VXNlciA/XG4gICAgICB0aGlzLmdldFVzZXIoLi4uYXJndW1lbnRzKSA6IHRoaXMuX2dldFVzZXJEZWZhdWx0KC4uLmFyZ3VtZW50cyk7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSBfZ2V0VXNlckRlZmF1bHRcbiAgICogQHN1bW1hcnkgRGVmYXVsdCB3YXkgb2YgcmVjb2duaXNpbmcgdXNlciBiYXNlZCBvbiAneF9tdG9rJyBjb29raWUsIGNhbiBiZSByZXBsYWNlZCBieSAnY29uZmlnLmdldFVzZXInIGlmIGRlZm5pZWQuIFJldHVybnMgb2JqZWN0IHdpdGggYHVzZXJJZGAgYW5kIGB1c2VyKClgIG1ldGhvZCB3aGljaCByZXR1cm4gdXNlcidzIG9iamVjdFxuICAgKiBAcmV0dXJucyB7T2JqZWN0fVxuICAgKi9cbiAgX2dldFVzZXJEZWZhdWx0KGh0dHApIHtcbiAgICBjb25zdCByZXN1bHQgPSB7XG4gICAgICB1c2VyKCkgeyByZXR1cm4gbnVsbDsgfSxcbiAgICAgIHVzZXJJZDogbnVsbFxuICAgIH07XG5cbiAgICBpZiAoaHR0cCkge1xuICAgICAgbGV0IG10b2sgPSBudWxsO1xuICAgICAgaWYgKGh0dHAucmVxdWVzdC5oZWFkZXJzWyd4LW10b2snXSkge1xuICAgICAgICBtdG9rID0gaHR0cC5yZXF1ZXN0LmhlYWRlcnNbJ3gtbXRvayddO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgY29va2llID0gaHR0cC5yZXF1ZXN0LkNvb2tpZXM7XG4gICAgICAgIGlmIChjb29raWUuaGFzKCd4X210b2snKSkge1xuICAgICAgICAgIG10b2sgPSBjb29raWUuZ2V0KCd4X210b2snKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAobXRvaykge1xuICAgICAgICBjb25zdCB1c2VySWQgPSB0aGlzLl9nZXRVc2VySWQobXRvayk7XG5cbiAgICAgICAgaWYgKHVzZXJJZCkge1xuICAgICAgICAgIHJlc3VsdC51c2VyICAgPSAoKSA9PiBNZXRlb3IudXNlcnMuZmluZE9uZSh1c2VySWQpO1xuICAgICAgICAgIHJlc3VsdC51c2VySWQgPSB1c2VySWQ7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIHdyaXRlXG4gICAqIEBwYXJhbSB7QnVmZmVyfSBidWZmZXIgLSBCaW5hcnkgRmlsZSdzIEJ1ZmZlclxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0cyAtIE9iamVjdCB3aXRoIGZpbGUtZGF0YVxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cy5uYW1lIC0gRmlsZSBuYW1lLCBhbGlhczogYGZpbGVOYW1lYFxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cy50eXBlIC0gRmlsZSBtaW1lLXR5cGVcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdHMubWV0YSAtIEZpbGUgYWRkaXRpb25hbCBtZXRhLWRhdGFcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMudXNlcklkIC0gVXNlcklkLCBkZWZhdWx0ICpudWxsKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cy5maWxlSWQgLSBfaWQsIGRlZmF1bHQgKm51bGwqXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrIC0gZnVuY3Rpb24oZXJyb3IsIGZpbGVPYmopey4uLn1cbiAgICogQHBhcmFtIHtCb29sZWFufSBwcm9jZWVkQWZ0ZXJVcGxvYWQgLSBQcm9jZWVkIG9uQWZ0ZXJVcGxvYWQgaG9va1xuICAgKiBAc3VtbWFyeSBXcml0ZSBidWZmZXIgdG8gRlMgYW5kIGFkZCB0byBGaWxlc0NvbGxlY3Rpb24gQ29sbGVjdGlvblxuICAgKiBAcmV0dXJucyB7RmlsZXNDb2xsZWN0aW9ufSBJbnN0YW5jZVxuICAgKi9cbiAgd3JpdGUoYnVmZmVyLCBfb3B0cyA9IHt9LCBfY2FsbGJhY2ssIF9wcm9jZWVkQWZ0ZXJVcGxvYWQpIHtcbiAgICB0aGlzLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW3dyaXRlKCldJyk7XG4gICAgbGV0IG9wdHMgPSBfb3B0cztcbiAgICBsZXQgY2FsbGJhY2sgPSBfY2FsbGJhY2s7XG4gICAgbGV0IHByb2NlZWRBZnRlclVwbG9hZCA9IF9wcm9jZWVkQWZ0ZXJVcGxvYWQ7XG5cbiAgICBpZiAoaGVscGVycy5pc0Z1bmN0aW9uKG9wdHMpKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBjYWxsYmFjaztcbiAgICAgIGNhbGxiYWNrID0gb3B0cztcbiAgICAgIG9wdHMgICAgID0ge307XG4gICAgfSBlbHNlIGlmIChoZWxwZXJzLmlzQm9vbGVhbihjYWxsYmFjaykpIHtcbiAgICAgIHByb2NlZWRBZnRlclVwbG9hZCA9IGNhbGxiYWNrO1xuICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc0Jvb2xlYW4ob3B0cykpIHtcbiAgICAgIHByb2NlZWRBZnRlclVwbG9hZCA9IG9wdHM7XG4gICAgfVxuXG4gICAgY2hlY2sob3B0cywgTWF0Y2guT3B0aW9uYWwoT2JqZWN0KSk7XG4gICAgY2hlY2soY2FsbGJhY2ssIE1hdGNoLk9wdGlvbmFsKEZ1bmN0aW9uKSk7XG4gICAgY2hlY2socHJvY2VlZEFmdGVyVXBsb2FkLCBNYXRjaC5PcHRpb25hbChCb29sZWFuKSk7XG5cbiAgICBjb25zdCBmaWxlSWQgICA9IG9wdHMuZmlsZUlkIHx8IFJhbmRvbS5pZCgpO1xuICAgIGNvbnN0IEZTTmFtZSAgID0gdGhpcy5uYW1pbmdGdW5jdGlvbiA/IHRoaXMubmFtaW5nRnVuY3Rpb24ob3B0cykgOiBmaWxlSWQ7XG4gICAgY29uc3QgZmlsZU5hbWUgPSAob3B0cy5uYW1lIHx8IG9wdHMuZmlsZU5hbWUpID8gKG9wdHMubmFtZSB8fCBvcHRzLmZpbGVOYW1lKSA6IEZTTmFtZTtcblxuICAgIGNvbnN0IHtleHRlbnNpb24sIGV4dGVuc2lvbldpdGhEb3R9ID0gdGhpcy5fZ2V0RXh0KGZpbGVOYW1lKTtcblxuICAgIG9wdHMucGF0aCA9IGAke3RoaXMuc3RvcmFnZVBhdGgob3B0cyl9JHtub2RlUGF0aC5zZXB9JHtGU05hbWV9JHtleHRlbnNpb25XaXRoRG90fWA7XG4gICAgb3B0cy50eXBlID0gdGhpcy5fZ2V0TWltZVR5cGUob3B0cyk7XG4gICAgaWYgKCFoZWxwZXJzLmlzT2JqZWN0KG9wdHMubWV0YSkpIHtcbiAgICAgIG9wdHMubWV0YSA9IHt9O1xuICAgIH1cblxuICAgIGlmICghaGVscGVycy5pc051bWJlcihvcHRzLnNpemUpKSB7XG4gICAgICBvcHRzLnNpemUgPSBidWZmZXIubGVuZ3RoO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuX2RhdGFUb1NjaGVtYSh7XG4gICAgICBuYW1lOiBmaWxlTmFtZSxcbiAgICAgIHBhdGg6IG9wdHMucGF0aCxcbiAgICAgIG1ldGE6IG9wdHMubWV0YSxcbiAgICAgIHR5cGU6IG9wdHMudHlwZSxcbiAgICAgIHNpemU6IG9wdHMuc2l6ZSxcbiAgICAgIHVzZXJJZDogb3B0cy51c2VySWQsXG4gICAgICBleHRlbnNpb25cbiAgICB9KTtcblxuICAgIHJlc3VsdC5faWQgPSBmaWxlSWQ7XG5cbiAgICBmcy5lbnN1cmVGaWxlKG9wdHMucGF0aCwgKGVmRXJyb3IpID0+IHtcbiAgICAgIGJvdW5kKCgpID0+IHtcbiAgICAgICAgaWYgKGVmRXJyb3IpIHtcbiAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhlZkVycm9yKTtcbiAgICAgICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW3dyaXRlXSBbZW5zdXJlRmlsZV0gW0Vycm9yOl0gJHtmaWxlTmFtZX0gLT4gJHtvcHRzLnBhdGh9YCwgZWZFcnJvcik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3Qgc3RyZWFtID0gZnMuY3JlYXRlV3JpdGVTdHJlYW0ob3B0cy5wYXRoLCB7ZmxhZ3M6ICd3JywgbW9kZTogdGhpcy5wZXJtaXNzaW9uc30pO1xuICAgICAgICAgIHN0cmVhbS5lbmQoYnVmZmVyLCAoc3RyZWFtRXJyKSA9PiB7XG4gICAgICAgICAgICBib3VuZCgoKSA9PiB7XG4gICAgICAgICAgICAgIGlmIChzdHJlYW1FcnIpIHtcbiAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhzdHJlYW1FcnIpO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMuY29sbGVjdGlvbi5pbnNlcnQocmVzdWx0LCAoaW5zZXJ0RXJyLCBfaWQpID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChpbnNlcnRFcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soaW5zZXJ0RXJyKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFt3cml0ZV0gW2luc2VydF0gRXJyb3I6ICR7ZmlsZU5hbWV9IC0+ICR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gLCBpbnNlcnRFcnIpO1xuICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmlsZVJlZiA9IHRoaXMuY29sbGVjdGlvbi5maW5kT25lKF9pZCk7XG4gICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKG51bGwsIGZpbGVSZWYpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocHJvY2VlZEFmdGVyVXBsb2FkID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgdGhpcy5vbkFmdGVyVXBsb2FkICYmIHRoaXMub25BZnRlclVwbG9hZC5jYWxsKHRoaXMsIGZpbGVSZWYpO1xuICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgnYWZ0ZXJVcGxvYWQnLCBmaWxlUmVmKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW3dyaXRlXTogJHtmaWxlTmFtZX0gLT4gJHt0aGlzLmNvbGxlY3Rpb25OYW1lfWApO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgbG9hZFxuICAgKiBAcGFyYW0ge1N0cmluZ30gdXJsIC0gVVJMIHRvIGZpbGVcbiAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRzXSAtIE9iamVjdCB3aXRoIGZpbGUtZGF0YVxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0cy5oZWFkZXJzIC0gSFRUUCBoZWFkZXJzIHRvIHVzZSB3aGVuIHJlcXVlc3RpbmcgdGhlIGZpbGVcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMubmFtZSAtIEZpbGUgbmFtZSwgYWxpYXM6IGBmaWxlTmFtZWBcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMudHlwZSAtIEZpbGUgbWltZS10eXBlXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRzLm1ldGEgLSBGaWxlIGFkZGl0aW9uYWwgbWV0YS1kYXRhXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBvcHRzLnVzZXJJZCAtIFVzZXJJZCwgZGVmYXVsdCAqbnVsbCpcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdHMuZmlsZUlkIC0gX2lkLCBkZWZhdWx0ICpudWxsKlxuICAgKiBAcGFyYW0ge051bWJlcn0gb3B0cy50aW1lb3V0IC0gVGltZW91dCBpbiBtaWxsaXNlY29uZHMsIGRlZmF1bHQ6IDM2MDAwMCAoNiBtaW5zKVxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayAtIGZ1bmN0aW9uKGVycm9yLCBmaWxlT2JqKXsuLi59XG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gW3Byb2NlZWRBZnRlclVwbG9hZF0gLSBQcm9jZWVkIG9uQWZ0ZXJVcGxvYWQgaG9va1xuICAgKiBAc3VtbWFyeSBEb3dubG9hZCBmaWxlIG92ZXIgSFRUUCwgd3JpdGUgc3RyZWFtIHRvIEZTLCBhbmQgYWRkIHRvIEZpbGVzQ29sbGVjdGlvbiBDb2xsZWN0aW9uXG4gICAqIEByZXR1cm5zIHtGaWxlc0NvbGxlY3Rpb259IEluc3RhbmNlXG4gICAqL1xuICBsb2FkKHVybCwgX29wdHMgPSB7fSwgX2NhbGxiYWNrLCBfcHJvY2VlZEFmdGVyVXBsb2FkID0gZmFsc2UpIHtcbiAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW2xvYWQoJHt1cmx9LCAke0pTT04uc3RyaW5naWZ5KF9vcHRzKX0sIGNhbGxiYWNrKV1gKTtcbiAgICBsZXQgb3B0cyA9IF9vcHRzO1xuICAgIGxldCBjYWxsYmFjayA9IF9jYWxsYmFjaztcbiAgICBsZXQgcHJvY2VlZEFmdGVyVXBsb2FkID0gX3Byb2NlZWRBZnRlclVwbG9hZDtcblxuICAgIGlmIChoZWxwZXJzLmlzRnVuY3Rpb24ob3B0cykpIHtcbiAgICAgIHByb2NlZWRBZnRlclVwbG9hZCA9IGNhbGxiYWNrO1xuICAgICAgY2FsbGJhY2sgPSBvcHRzO1xuICAgICAgb3B0cyA9IHt9O1xuICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc0Jvb2xlYW4oY2FsbGJhY2spKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBjYWxsYmFjaztcbiAgICB9IGVsc2UgaWYgKGhlbHBlcnMuaXNCb29sZWFuKG9wdHMpKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBvcHRzO1xuICAgIH1cblxuICAgIGNoZWNrKHVybCwgU3RyaW5nKTtcbiAgICBjaGVjayhvcHRzLCBNYXRjaC5PcHRpb25hbChPYmplY3QpKTtcbiAgICBjaGVjayhjYWxsYmFjaywgTWF0Y2guT3B0aW9uYWwoRnVuY3Rpb24pKTtcbiAgICBjaGVjayhwcm9jZWVkQWZ0ZXJVcGxvYWQsIE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pKTtcblxuICAgIGlmICghaGVscGVycy5pc09iamVjdChvcHRzKSkge1xuICAgICAgb3B0cyA9IHtcbiAgICAgICAgdGltZW91dDogMzYwMDAwXG4gICAgICB9O1xuICAgIH1cblxuICAgIGlmICghb3B0cy50aW1lb3V0KSB7XG4gICAgICBvcHRzLnRpbWVvdXQgPSAzNjAwMDA7XG4gICAgfVxuXG4gICAgY29uc3QgZmlsZUlkID0gb3B0cy5maWxlSWQgfHwgUmFuZG9tLmlkKCk7XG4gICAgY29uc3QgRlNOYW1lID0gdGhpcy5uYW1pbmdGdW5jdGlvbiA/IHRoaXMubmFtaW5nRnVuY3Rpb24ob3B0cykgOiBmaWxlSWQ7XG4gICAgY29uc3QgcGF0aFBhcnRzID0gdXJsLnNwbGl0KCcvJyk7XG4gICAgY29uc3QgZmlsZU5hbWUgPSAob3B0cy5uYW1lIHx8IG9wdHMuZmlsZU5hbWUpID8gKG9wdHMubmFtZSB8fCBvcHRzLmZpbGVOYW1lKSA6IHBhdGhQYXJ0c1twYXRoUGFydHMubGVuZ3RoIC0gMV0uc3BsaXQoJz8nKVswXSB8fCBGU05hbWU7XG5cbiAgICBjb25zdCB7ZXh0ZW5zaW9uLCBleHRlbnNpb25XaXRoRG90fSA9IHRoaXMuX2dldEV4dChmaWxlTmFtZSk7XG4gICAgb3B0cy5wYXRoICA9IGAke3RoaXMuc3RvcmFnZVBhdGgob3B0cyl9JHtub2RlUGF0aC5zZXB9JHtGU05hbWV9JHtleHRlbnNpb25XaXRoRG90fWA7XG5cbiAgICBjb25zdCBzdG9yZVJlc3VsdCA9IChyZXN1bHQsIGNiKSA9PiB7XG4gICAgICByZXN1bHQuX2lkID0gZmlsZUlkO1xuXG4gICAgICB0aGlzLmNvbGxlY3Rpb24uaW5zZXJ0KHJlc3VsdCwgKGVycm9yLCBfaWQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgY2IgJiYgY2IoZXJyb3IpO1xuICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbG9hZF0gW2luc2VydF0gRXJyb3I6ICR7ZmlsZU5hbWV9IC0+ICR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gLCBlcnJvcik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgZmlsZVJlZiA9IHRoaXMuY29sbGVjdGlvbi5maW5kT25lKF9pZCk7XG4gICAgICAgICAgY2IgJiYgY2IobnVsbCwgZmlsZVJlZik7XG4gICAgICAgICAgaWYgKHByb2NlZWRBZnRlclVwbG9hZCA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgdGhpcy5vbkFmdGVyVXBsb2FkICYmIHRoaXMub25BZnRlclVwbG9hZC5jYWxsKHRoaXMsIGZpbGVSZWYpO1xuICAgICAgICAgICAgdGhpcy5lbWl0KCdhZnRlclVwbG9hZCcsIGZpbGVSZWYpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW2xvYWRdIFtpbnNlcnRdICR7ZmlsZU5hbWV9IC0+ICR7dGhpcy5jb2xsZWN0aW9uTmFtZX1gKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfTtcblxuICAgIGZzLmVuc3VyZUZpbGUob3B0cy5wYXRoLCAoZWZFcnJvcikgPT4ge1xuICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICBpZiAoZWZFcnJvcikge1xuICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKGVmRXJyb3IpO1xuICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbG9hZF0gW2Vuc3VyZUZpbGVdIFtFcnJvcjpdICR7ZmlsZU5hbWV9IC0+ICR7b3B0cy5wYXRofWAsIGVmRXJyb3IpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGxldCBpc0VuZGVkID0gZmFsc2U7XG4gICAgICAgICAgbGV0IHRpbWVyID0gbnVsbDtcbiAgICAgICAgICBjb25zdCB3U3RyZWFtID0gZnMuY3JlYXRlV3JpdGVTdHJlYW0ob3B0cy5wYXRoLCB7ZmxhZ3M6ICd3JywgbW9kZTogdGhpcy5wZXJtaXNzaW9ucywgYXV0b0Nsb3NlOiB0cnVlLCBlbWl0Q2xvc2U6IGZhbHNlIH0pO1xuICAgICAgICAgIGNvbnN0IG9uRW5kID0gKF9lcnJvciwgcmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgIGlmICghaXNFbmRlZCkge1xuICAgICAgICAgICAgICBpZiAodGltZXIpIHtcbiAgICAgICAgICAgICAgICBNZXRlb3IuY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICAgICAgICAgICAgICB0aW1lciA9IG51bGw7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBpc0VuZGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlICYmIHJlc3BvbnNlLnN0YXR1cyA9PT0gMjAwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtsb2FkXSBSZWNlaXZlZDogJHt1cmx9YCk7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5fZGF0YVRvU2NoZW1hKHtcbiAgICAgICAgICAgICAgICAgIG5hbWU6IGZpbGVOYW1lLFxuICAgICAgICAgICAgICAgICAgcGF0aDogb3B0cy5wYXRoLFxuICAgICAgICAgICAgICAgICAgbWV0YTogb3B0cy5tZXRhLFxuICAgICAgICAgICAgICAgICAgdHlwZTogb3B0cy50eXBlIHx8IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KCdjb250ZW50LXR5cGUnKSB8fCB0aGlzLl9nZXRNaW1lVHlwZSh7cGF0aDogb3B0cy5wYXRofSksXG4gICAgICAgICAgICAgICAgICBzaXplOiBvcHRzLnNpemUgfHwgcGFyc2VJbnQocmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtbGVuZ3RoJykgfHwgMCksXG4gICAgICAgICAgICAgICAgICB1c2VySWQ6IG9wdHMudXNlcklkLFxuICAgICAgICAgICAgICAgICAgZXh0ZW5zaW9uXG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICBpZiAoIXJlc3VsdC5zaXplKSB7XG4gICAgICAgICAgICAgICAgICBmcy5zdGF0KG9wdHMucGF0aCwgKHN0YXRFcnJvciwgc3RhdHMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChzdGF0RXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKHN0YXRFcnJvcik7XG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC52ZXJzaW9ucy5vcmlnaW5hbC5zaXplID0gKHJlc3VsdC5zaXplID0gc3RhdHMuc2l6ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdG9yZVJlc3VsdChyZXN1bHQsIGNhbGxiYWNrKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIHN0b3JlUmVzdWx0KHJlc3VsdCwgY2FsbGJhY2spO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCBlcnJvciA9IF9lcnJvciB8fCBuZXcgTWV0ZW9yLkVycm9yKHJlc3BvbnNlPy5zdGF0dXMgfHwgNDA4LCByZXNwb25zZT8uc3RhdHVzVGV4dCB8fCAnQmFkIHJlc3BvbnNlIHdpdGggZW1wdHkgZGV0YWlscycpO1xuICAgICAgICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbG9hZF0gW2ZldGNoKCR7dXJsfSldIEVycm9yOmAsIGVycm9yKTtcblxuICAgICAgICAgICAgICAgIGlmICghd1N0cmVhbS5kZXN0cm95ZWQpIHtcbiAgICAgICAgICAgICAgICAgIHdTdHJlYW0uZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGZzLnJlbW92ZShvcHRzLnBhdGgsIChyZW1vdmVFcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhlcnJvcik7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZW1vdmVFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbbG9hZF0gW2ZldGNoKCR7dXJsfSldIFtmcy5yZW1vdmUoJHtvcHRzLnBhdGh9KV0gcmVtb3ZlRXJyb3I6YCwgcmVtb3ZlRXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH07XG5cbiAgICAgICAgICBsZXQgcmVzcCA9IHZvaWQgMDtcbiAgICAgICAgICB3U3RyZWFtLm9uKCdlcnJvcicsIChlcnJvcikgPT4ge1xuICAgICAgICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICAgICAgICBvbkVuZChlcnJvcik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB3U3RyZWFtLm9uKCdjbG9zZScsICgpID0+IHtcbiAgICAgICAgICAgIGJvdW5kKCgpID0+IHtcbiAgICAgICAgICAgICAgb25FbmQodm9pZCAwLCByZXNwKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIHdTdHJlYW0ub24oJ2ZpbmlzaCcsICgpID0+IHtcbiAgICAgICAgICAgIGJvdW5kKCgpID0+IHtcbiAgICAgICAgICAgICAgb25FbmQodm9pZCAwLCByZXNwKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgICAgICBmZXRjaCh1cmwsIHtcbiAgICAgICAgICAgIGhlYWRlcnM6IG9wdHMuaGVhZGVycyB8fCB7fSxcbiAgICAgICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWxcbiAgICAgICAgICB9KS50aGVuKChyZXMpID0+IHtcbiAgICAgICAgICAgIHJlc3AgPSByZXM7XG4gICAgICAgICAgICByZXMuYm9keS5vbignZXJyb3InLCAoZXJyb3IpID0+IHtcbiAgICAgICAgICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIG9uRW5kKGVycm9yKTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJlcy5ib2R5LnBpcGUod1N0cmVhbSk7XG4gICAgICAgICAgfSkuY2F0Y2goKGZldGNoRXJyb3IpID0+IHtcbiAgICAgICAgICAgIG9uRW5kKGZldGNoRXJyb3IpO1xuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgaWYgKG9wdHMudGltZW91dCA+IDApIHtcbiAgICAgICAgICAgIHRpbWVyID0gTWV0ZW9yLnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICBvbkVuZChuZXcgTWV0ZW9yLkVycm9yKDQwOCwgYFJlcXVlc3QgdGltZW91dCBhZnRlciAke29wdHMudGltZW91dH1tc2ApKTtcbiAgICAgICAgICAgICAgY29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgICAgICAgfSwgb3B0cy50aW1lb3V0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgYWRkRmlsZVxuICAgKiBAcGFyYW0ge1N0cmluZ30gcGF0aCAgICAgICAgICAtIFBhdGggdG8gZmlsZVxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cyAgICAgICAgICAtIFtPcHRpb25hbF0gT2JqZWN0IHdpdGggZmlsZS1kYXRhXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBvcHRzLnR5cGUgICAgIC0gW09wdGlvbmFsXSBGaWxlIG1pbWUtdHlwZVxuICAgKiBAcGFyYW0ge09iamVjdH0gb3B0cy5tZXRhICAgICAtIFtPcHRpb25hbF0gRmlsZSBhZGRpdGlvbmFsIG1ldGEtZGF0YVxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cy5maWxlSWQgICAtIF9pZCwgZGVmYXVsdCAqbnVsbCpcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdHMuZmlsZU5hbWUgLSBbT3B0aW9uYWxdIEZpbGUgbmFtZSwgaWYgbm90IHNwZWNpZmllZCBmaWxlIG5hbWUgYW5kIGV4dGVuc2lvbiB3aWxsIGJlIHRha2VuIGZyb20gcGF0aFxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0cy51c2VySWQgICAtIFtPcHRpb25hbF0gVXNlcklkLCBkZWZhdWx0ICpudWxsKlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayAgICAtIFtPcHRpb25hbF0gZnVuY3Rpb24oZXJyb3IsIGZpbGVPYmopey4uLn1cbiAgICogQHBhcmFtIHtCb29sZWFufSBwcm9jZWVkQWZ0ZXJVcGxvYWQgLSBQcm9jZWVkIG9uQWZ0ZXJVcGxvYWQgaG9va1xuICAgKiBAc3VtbWFyeSBBZGQgZmlsZSBmcm9tIEZTIHRvIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAcmV0dXJucyB7RmlsZXNDb2xsZWN0aW9ufSBJbnN0YW5jZVxuICAgKi9cbiAgYWRkRmlsZShwYXRoLCBfb3B0cyA9IHt9LCBfY2FsbGJhY2ssIF9wcm9jZWVkQWZ0ZXJVcGxvYWQpIHtcbiAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW2FkZEZpbGUoJHtwYXRofSldYCk7XG4gICAgbGV0IG9wdHMgPSBfb3B0cztcbiAgICBsZXQgY2FsbGJhY2sgPSBfY2FsbGJhY2s7XG4gICAgbGV0IHByb2NlZWRBZnRlclVwbG9hZCA9IF9wcm9jZWVkQWZ0ZXJVcGxvYWQ7XG5cbiAgICBpZiAoaGVscGVycy5pc0Z1bmN0aW9uKG9wdHMpKSB7XG4gICAgICBwcm9jZWVkQWZ0ZXJVcGxvYWQgPSBjYWxsYmFjaztcbiAgICAgIGNhbGxiYWNrID0gb3B0cztcbiAgICAgIG9wdHMgICAgID0ge307XG4gICAgfSBlbHNlIGlmIChoZWxwZXJzLmlzQm9vbGVhbihjYWxsYmFjaykpIHtcbiAgICAgIHByb2NlZWRBZnRlclVwbG9hZCA9IGNhbGxiYWNrO1xuICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc0Jvb2xlYW4ob3B0cykpIHtcbiAgICAgIHByb2NlZWRBZnRlclVwbG9hZCA9IG9wdHM7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMucHVibGljKSB7XG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKDQwMywgJ0NhbiBub3QgcnVuIFthZGRGaWxlXSBvbiBwdWJsaWMgY29sbGVjdGlvbiEgSnVzdCBNb3ZlIGZpbGUgdG8gcm9vdCBvZiB5b3VyIHNlcnZlciwgdGhlbiBhZGQgcmVjb3JkIHRvIENvbGxlY3Rpb24nKTtcbiAgICB9XG5cbiAgICBjaGVjayhwYXRoLCBTdHJpbmcpO1xuICAgIGNoZWNrKG9wdHMsIE1hdGNoLk9wdGlvbmFsKE9iamVjdCkpO1xuICAgIGNoZWNrKGNhbGxiYWNrLCBNYXRjaC5PcHRpb25hbChGdW5jdGlvbikpO1xuICAgIGNoZWNrKHByb2NlZWRBZnRlclVwbG9hZCwgTWF0Y2guT3B0aW9uYWwoQm9vbGVhbikpO1xuXG4gICAgZnMuc3RhdChwYXRoLCAoc3RhdEVyciwgc3RhdHMpID0+IGJvdW5kKCgpID0+IHtcbiAgICAgIGlmIChzdGF0RXJyKSB7XG4gICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKHN0YXRFcnIpO1xuICAgICAgfSBlbHNlIGlmIChzdGF0cy5pc0ZpbGUoKSkge1xuICAgICAgICBpZiAoIWhlbHBlcnMuaXNPYmplY3Qob3B0cykpIHtcbiAgICAgICAgICBvcHRzID0ge307XG4gICAgICAgIH1cbiAgICAgICAgb3B0cy5wYXRoICA9IHBhdGg7XG5cbiAgICAgICAgaWYgKCFvcHRzLmZpbGVOYW1lKSB7XG4gICAgICAgICAgY29uc3QgcGF0aFBhcnRzID0gcGF0aC5zcGxpdChub2RlUGF0aC5zZXApO1xuICAgICAgICAgIG9wdHMuZmlsZU5hbWUgICA9IHBhdGguc3BsaXQobm9kZVBhdGguc2VwKVtwYXRoUGFydHMubGVuZ3RoIC0gMV07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB7ZXh0ZW5zaW9ufSA9IHRoaXMuX2dldEV4dChvcHRzLmZpbGVOYW1lKTtcblxuICAgICAgICBpZiAoIWhlbHBlcnMuaXNTdHJpbmcob3B0cy50eXBlKSkge1xuICAgICAgICAgIG9wdHMudHlwZSA9IHRoaXMuX2dldE1pbWVUeXBlKG9wdHMpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFoZWxwZXJzLmlzT2JqZWN0KG9wdHMubWV0YSkpIHtcbiAgICAgICAgICBvcHRzLm1ldGEgPSB7fTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghaGVscGVycy5pc051bWJlcihvcHRzLnNpemUpKSB7XG4gICAgICAgICAgb3B0cy5zaXplID0gc3RhdHMuc2l6ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuX2RhdGFUb1NjaGVtYSh7XG4gICAgICAgICAgbmFtZTogb3B0cy5maWxlTmFtZSxcbiAgICAgICAgICBwYXRoLFxuICAgICAgICAgIG1ldGE6IG9wdHMubWV0YSxcbiAgICAgICAgICB0eXBlOiBvcHRzLnR5cGUsXG4gICAgICAgICAgc2l6ZTogb3B0cy5zaXplLFxuICAgICAgICAgIHVzZXJJZDogb3B0cy51c2VySWQsXG4gICAgICAgICAgZXh0ZW5zaW9uLFxuICAgICAgICAgIF9zdG9yYWdlUGF0aDogcGF0aC5yZXBsYWNlKGAke25vZGVQYXRoLnNlcH0ke29wdHMuZmlsZU5hbWV9YCwgJycpLFxuICAgICAgICAgIGZpbGVJZDogb3B0cy5maWxlSWQgfHwgbnVsbFxuICAgICAgICB9KTtcblxuXG4gICAgICAgIHRoaXMuY29sbGVjdGlvbi5pbnNlcnQocmVzdWx0LCAoaW5zZXJ0RXJyLCBfaWQpID0+IHtcbiAgICAgICAgICBpZiAoaW5zZXJ0RXJyKSB7XG4gICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhpbnNlcnRFcnIpO1xuICAgICAgICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFthZGRGaWxlXSBbaW5zZXJ0XSBFcnJvcjogJHtyZXN1bHQubmFtZX0gLT4gJHt0aGlzLmNvbGxlY3Rpb25OYW1lfWAsIGluc2VydEVycik7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGZpbGVSZWYgPSB0aGlzLmNvbGxlY3Rpb24uZmluZE9uZShfaWQpO1xuICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2sobnVsbCwgZmlsZVJlZik7XG4gICAgICAgICAgICBpZiAocHJvY2VlZEFmdGVyVXBsb2FkID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgIHRoaXMub25BZnRlclVwbG9hZCAmJiB0aGlzLm9uQWZ0ZXJVcGxvYWQuY2FsbCh0aGlzLCBmaWxlUmVmKTtcbiAgICAgICAgICAgICAgdGhpcy5lbWl0KCdhZnRlclVwbG9hZCcsIGZpbGVSZWYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFthZGRGaWxlXTogJHtyZXN1bHQubmFtZX0gLT4gJHt0aGlzLmNvbGxlY3Rpb25OYW1lfWApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhuZXcgTWV0ZW9yLkVycm9yKDQwMCwgYFtGaWxlc0NvbGxlY3Rpb25dIFthZGRGaWxlKCR7cGF0aH0pXTogRmlsZSBkb2VzIG5vdCBleGlzdGApKTtcbiAgICAgIH1cbiAgICB9KSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSByZW1vdmVcbiAgICogQHBhcmFtIHtTdHJpbmd8T2JqZWN0fSBzZWxlY3RvciAtIE1vbmdvLVN0eWxlIHNlbGVjdG9yIChodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9jb2xsZWN0aW9ucy5odG1sI3NlbGVjdG9ycylcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgLSBDYWxsYmFjayB3aXRoIG9uZSBgZXJyb3JgIGFyZ3VtZW50XG4gICAqIEBzdW1tYXJ5IFJlbW92ZSBkb2N1bWVudHMgZnJvbSB0aGUgY29sbGVjdGlvblxuICAgKiBAcmV0dXJucyB7RmlsZXNDb2xsZWN0aW9ufSBJbnN0YW5jZVxuICAgKi9cbiAgcmVtb3ZlKHNlbGVjdG9yLCBjYWxsYmFjaykge1xuICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbcmVtb3ZlKCR7SlNPTi5zdHJpbmdpZnkoc2VsZWN0b3IpfSldYCk7XG4gICAgaWYgKHNlbGVjdG9yID09PSB2b2lkIDApIHtcbiAgICAgIHJldHVybiAwO1xuICAgIH1cbiAgICBjaGVjayhjYWxsYmFjaywgTWF0Y2guT3B0aW9uYWwoRnVuY3Rpb24pKTtcblxuICAgIGNvbnN0IGZpbGVzID0gdGhpcy5jb2xsZWN0aW9uLmZpbmQoc2VsZWN0b3IpO1xuICAgIGlmIChmaWxlcy5jb3VudCgpID4gMCkge1xuICAgICAgZmlsZXMuZm9yRWFjaCgoZmlsZSkgPT4ge1xuICAgICAgICB0aGlzLnVubGluayhmaWxlKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayhuZXcgTWV0ZW9yLkVycm9yKDQwNCwgJ0N1cnNvciBpcyBlbXB0eSwgbm8gZmlsZXMgaXMgcmVtb3ZlZCcpKTtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIGlmICh0aGlzLm9uQWZ0ZXJSZW1vdmUpIHtcbiAgICAgIGNvbnN0IGRvY3MgPSBmaWxlcy5mZXRjaCgpO1xuICAgICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgICB0aGlzLmNvbGxlY3Rpb24ucmVtb3ZlKHNlbGVjdG9yLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgIHNlbGYub25BZnRlclJlbW92ZShkb2NzKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmNvbGxlY3Rpb24ucmVtb3ZlKHNlbGVjdG9yLCAoY2FsbGJhY2sgfHwgTk9PUCkpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSBkZW55XG4gICAqIEBwYXJhbSB7T2JqZWN0fSBydWxlc1xuICAgKiBAc2VlICBodHRwczovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNNb25nby1Db2xsZWN0aW9uLWRlbnlcbiAgICogQHN1bW1hcnkgbGluayBNb25nby5Db2xsZWN0aW9uIGRlbnkgbWV0aG9kc1xuICAgKiBAcmV0dXJucyB7TW9uZ28uQ29sbGVjdGlvbn0gSW5zdGFuY2VcbiAgICovXG4gIGRlbnkocnVsZXMpIHtcbiAgICB0aGlzLmNvbGxlY3Rpb24uZGVueShydWxlcyk7XG4gICAgcmV0dXJuIHRoaXMuY29sbGVjdGlvbjtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSBhbGxvd1xuICAgKiBAcGFyYW0ge09iamVjdH0gcnVsZXNcbiAgICogQHNlZSBodHRwczovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNNb25nby1Db2xsZWN0aW9uLWFsbG93XG4gICAqIEBzdW1tYXJ5IGxpbmsgTW9uZ28uQ29sbGVjdGlvbiBhbGxvdyBtZXRob2RzXG4gICAqIEByZXR1cm5zIHtNb25nby5Db2xsZWN0aW9ufSBJbnN0YW5jZVxuICAgKi9cbiAgYWxsb3cocnVsZXMpIHtcbiAgICB0aGlzLmNvbGxlY3Rpb24uYWxsb3cocnVsZXMpO1xuICAgIHJldHVybiB0aGlzLmNvbGxlY3Rpb247XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgZGVueUNsaWVudFxuICAgKiBAc2VlIGh0dHBzOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9jb2xsZWN0aW9ucy5odG1sI01vbmdvLUNvbGxlY3Rpb24tZGVueVxuICAgKiBAc3VtbWFyeSBTaG9ydGhhbmRzIGZvciBNb25nby5Db2xsZWN0aW9uIGRlbnkgbWV0aG9kXG4gICAqIEByZXR1cm5zIHtNb25nby5Db2xsZWN0aW9ufSBJbnN0YW5jZVxuICAgKi9cbiAgZGVueUNsaWVudCgpIHtcbiAgICB0aGlzLmNvbGxlY3Rpb24uZGVueSh7XG4gICAgICBpbnNlcnQoKSB7IHJldHVybiB0cnVlOyB9LFxuICAgICAgdXBkYXRlKCkgeyByZXR1cm4gdHJ1ZTsgfSxcbiAgICAgIHJlbW92ZSgpIHsgcmV0dXJuIHRydWU7IH1cbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcy5jb2xsZWN0aW9uO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIGFsbG93Q2xpZW50XG4gICAqIEBzZWUgaHR0cHM6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjTW9uZ28tQ29sbGVjdGlvbi1hbGxvd1xuICAgKiBAc3VtbWFyeSBTaG9ydGhhbmRzIGZvciBNb25nby5Db2xsZWN0aW9uIGFsbG93IG1ldGhvZFxuICAgKiBAcmV0dXJucyB7TW9uZ28uQ29sbGVjdGlvbn0gSW5zdGFuY2VcbiAgICovXG4gIGFsbG93Q2xpZW50KCkge1xuICAgIHRoaXMuY29sbGVjdGlvbi5hbGxvdyh7XG4gICAgICBpbnNlcnQoKSB7IHJldHVybiB0cnVlOyB9LFxuICAgICAgdXBkYXRlKCkgeyByZXR1cm4gdHJ1ZTsgfSxcbiAgICAgIHJlbW92ZSgpIHsgcmV0dXJuIHRydWU7IH1cbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcy5jb2xsZWN0aW9uO1xuICB9XG5cblxuICAvKlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgdW5saW5rXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBmaWxlUmVmIC0gZmlsZU9ialxuICAgKiBAcGFyYW0ge1N0cmluZ30gdmVyc2lvbiAtIFtPcHRpb25hbF0gZmlsZSdzIHZlcnNpb25cbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgLSBbT3B0aW9uYWxdIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAqIEBzdW1tYXJ5IFVubGluayBmaWxlcyBhbmQgaXQncyB2ZXJzaW9ucyBmcm9tIEZTXG4gICAqIEByZXR1cm5zIHtGaWxlc0NvbGxlY3Rpb259IEluc3RhbmNlXG4gICAqL1xuICB1bmxpbmsoZmlsZVJlZiwgdmVyc2lvbiwgY2FsbGJhY2spIHtcbiAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW3VubGluaygke2ZpbGVSZWYuX2lkfSwgJHt2ZXJzaW9ufSldYCk7XG4gICAgaWYgKHZlcnNpb24pIHtcbiAgICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KGZpbGVSZWYudmVyc2lvbnMpICYmIGhlbHBlcnMuaXNPYmplY3QoZmlsZVJlZi52ZXJzaW9uc1t2ZXJzaW9uXSkgJiYgZmlsZVJlZi52ZXJzaW9uc1t2ZXJzaW9uXS5wYXRoKSB7XG4gICAgICAgIGZzLnVubGluayhmaWxlUmVmLnZlcnNpb25zW3ZlcnNpb25dLnBhdGgsIChjYWxsYmFjayB8fCBOT09QKSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KGZpbGVSZWYudmVyc2lvbnMpKSB7XG4gICAgICAgIGZvcihsZXQgdktleSBpbiBmaWxlUmVmLnZlcnNpb25zKSB7XG4gICAgICAgICAgaWYgKGZpbGVSZWYudmVyc2lvbnNbdktleV0gJiYgZmlsZVJlZi52ZXJzaW9uc1t2S2V5XS5wYXRoKSB7XG4gICAgICAgICAgICBmcy51bmxpbmsoZmlsZVJlZi52ZXJzaW9uc1t2S2V5XS5wYXRoLCAoY2FsbGJhY2sgfHwgTk9PUCkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZnMudW5saW5rKGZpbGVSZWYucGF0aCwgKGNhbGxiYWNrIHx8IE5PT1ApKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25cbiAgICogQG5hbWUgXzQwNFxuICAgKiBAc3VtbWFyeSBJbnRlcm5hbCBtZXRob2QsIHVzZWQgdG8gcmV0dXJuIDQwNCBlcnJvclxuICAgKiBAcmV0dXJucyB7dW5kZWZpbmVkfVxuICAgKi9cbiAgXzQwNChodHRwKSB7XG4gICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtkb3dubG9hZCgke2h0dHAucmVxdWVzdC5vcmlnaW5hbFVybH0pXSBbXzQwNF0gRmlsZSBub3QgZm91bmRgKTtcbiAgICBjb25zdCB0ZXh0ID0gJ0ZpbGUgTm90IEZvdW5kIDooJztcblxuICAgIGlmICghaHR0cC5yZXNwb25zZS5oZWFkZXJzU2VudCkge1xuICAgICAgaHR0cC5yZXNwb25zZS53cml0ZUhlYWQoNDA0LCB7XG4gICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC9wbGFpbicsXG4gICAgICAgICdDb250ZW50LUxlbmd0aCc6IHRleHQubGVuZ3RoXG4gICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICBpZiAoIWh0dHAucmVzcG9uc2UuZmluaXNoZWQpIHtcbiAgICAgIGh0dHAucmVzcG9uc2UuZW5kKHRleHQpO1xuICAgIH1cbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBTZXJ2ZXJcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvblxuICAgKiBAbmFtZSBkb3dubG9hZFxuICAgKiBAcGFyYW0ge09iamVjdH0gaHR0cCAgICAtIFNlcnZlciBIVFRQIG9iamVjdFxuICAgKiBAcGFyYW0ge1N0cmluZ30gdmVyc2lvbiAtIFJlcXVlc3RlZCBmaWxlIHZlcnNpb25cbiAgICogQHBhcmFtIHtPYmplY3R9IGZpbGVSZWYgLSBSZXF1ZXN0ZWQgZmlsZSBPYmplY3RcbiAgICogQHN1bW1hcnkgSW5pdGlhdGVzIHRoZSBIVFRQIHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHt1bmRlZmluZWR9XG4gICAqL1xuICBkb3dubG9hZChodHRwLCB2ZXJzaW9uID0gJ29yaWdpbmFsJywgZmlsZVJlZikge1xuICAgIGxldCB2UmVmO1xuICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbZG93bmxvYWQoJHtodHRwLnJlcXVlc3Qub3JpZ2luYWxVcmx9LCAke3ZlcnNpb259KV1gKTtcblxuICAgIGlmIChmaWxlUmVmKSB7XG4gICAgICBpZiAoaGVscGVycy5oYXMoZmlsZVJlZiwgJ3ZlcnNpb25zJykgJiYgaGVscGVycy5oYXMoZmlsZVJlZi52ZXJzaW9ucywgdmVyc2lvbikpIHtcbiAgICAgICAgdlJlZiA9IGZpbGVSZWYudmVyc2lvbnNbdmVyc2lvbl07XG4gICAgICAgIHZSZWYuX2lkID0gZmlsZVJlZi5faWQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2UmVmID0gZmlsZVJlZjtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdlJlZiA9IGZhbHNlO1xuICAgIH1cblxuICAgIGlmICghdlJlZiB8fCAhaGVscGVycy5pc09iamVjdCh2UmVmKSkge1xuICAgICAgcmV0dXJuIHRoaXMuXzQwNChodHRwKTtcbiAgICB9IGVsc2UgaWYgKGZpbGVSZWYpIHtcbiAgICAgIGlmICh0aGlzLmRvd25sb2FkQ2FsbGJhY2spIHtcbiAgICAgICAgaWYgKCF0aGlzLmRvd25sb2FkQ2FsbGJhY2suY2FsbChPYmplY3QuYXNzaWduKGh0dHAsIHRoaXMuX2dldFVzZXIoaHR0cCkpLCBmaWxlUmVmKSkge1xuICAgICAgICAgIHJldHVybiB0aGlzLl80MDQoaHR0cCk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHRoaXMuaW50ZXJjZXB0RG93bmxvYWQgJiYgaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMuaW50ZXJjZXB0RG93bmxvYWQpICYmIHRoaXMuaW50ZXJjZXB0RG93bmxvYWQoaHR0cCwgZmlsZVJlZiwgdmVyc2lvbikgPT09IHRydWUpIHtcbiAgICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICAgIH1cblxuICAgICAgZnMuc3RhdCh2UmVmLnBhdGgsIChzdGF0RXJyLCBzdGF0cykgPT4gYm91bmQoKCkgPT4ge1xuICAgICAgICBsZXQgcmVzcG9uc2VUeXBlO1xuICAgICAgICBpZiAoc3RhdEVyciB8fCAhc3RhdHMuaXNGaWxlKCkpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fNDA0KGh0dHApO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKChzdGF0cy5zaXplICE9PSB2UmVmLnNpemUpICYmICF0aGlzLmludGVncml0eUNoZWNrKSB7XG4gICAgICAgICAgdlJlZi5zaXplID0gc3RhdHMuc2l6ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICgoc3RhdHMuc2l6ZSAhPT0gdlJlZi5zaXplKSAmJiB0aGlzLmludGVncml0eUNoZWNrKSB7XG4gICAgICAgICAgcmVzcG9uc2VUeXBlID0gJzQwMCc7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpcy5zZXJ2ZShodHRwLCBmaWxlUmVmLCB2UmVmLCB2ZXJzaW9uLCBudWxsLCAocmVzcG9uc2VUeXBlIHx8ICcyMDAnKSk7XG4gICAgICB9KSk7XG4gICAgICByZXR1cm4gdm9pZCAwO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fNDA0KGh0dHApO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uXG4gICAqIEBuYW1lIHNlcnZlXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBodHRwICAgIC0gU2VydmVyIEhUVFAgb2JqZWN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSBmaWxlUmVmIC0gUmVxdWVzdGVkIGZpbGUgT2JqZWN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSB2UmVmICAgIC0gUmVxdWVzdGVkIGZpbGUgdmVyc2lvbiBPYmplY3RcbiAgICogQHBhcmFtIHtTdHJpbmd9IHZlcnNpb24gLSBSZXF1ZXN0ZWQgZmlsZSB2ZXJzaW9uXG4gICAqIEBwYXJhbSB7c3RyZWFtLlJlYWRhYmxlfG51bGx9IHJlYWRhYmxlU3RyZWFtIC0gUmVhZGFibGUgc3RyZWFtLCB3aGljaCBzZXJ2ZXMgYmluYXJ5IGZpbGUgZGF0YVxuICAgKiBAcGFyYW0ge1N0cmluZ30gcmVzcG9uc2VUeXBlIC0gUmVzcG9uc2UgY29kZVxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IGZvcmNlMjAwIC0gRm9yY2UgMjAwIHJlc3BvbnNlIGNvZGUgb3ZlciAyMDZcbiAgICogQHN1bW1hcnkgSGFuZGxlIGFuZCByZXBseSB0byBpbmNvbWluZyByZXF1ZXN0XG4gICAqIEByZXR1cm5zIHt1bmRlZmluZWR9XG4gICAqL1xuICBzZXJ2ZShodHRwLCBmaWxlUmVmLCB2UmVmLCB2ZXJzaW9uID0gJ29yaWdpbmFsJywgcmVhZGFibGVTdHJlYW0gPSBudWxsLCBfcmVzcG9uc2VUeXBlID0gJzIwMCcsIGZvcmNlMjAwID0gZmFsc2UpIHtcbiAgICBsZXQgcGFydGlyYWwgPSBmYWxzZTtcbiAgICBsZXQgcmVxUmFuZ2UgPSBmYWxzZTtcbiAgICBsZXQgZGlzcG9zaXRpb25UeXBlID0gJyc7XG4gICAgbGV0IHN0YXJ0O1xuICAgIGxldCBlbmQ7XG4gICAgbGV0IHRha2U7XG4gICAgbGV0IHJlc3BvbnNlVHlwZSA9IF9yZXNwb25zZVR5cGU7XG5cbiAgICBpZiAoaHR0cC5wYXJhbXMucXVlcnkuZG93bmxvYWQgJiYgKGh0dHAucGFyYW1zLnF1ZXJ5LmRvd25sb2FkID09PSAndHJ1ZScpKSB7XG4gICAgICBkaXNwb3NpdGlvblR5cGUgPSAnYXR0YWNobWVudDsgJztcbiAgICB9IGVsc2Uge1xuICAgICAgZGlzcG9zaXRpb25UeXBlID0gJ2lubGluZTsgJztcbiAgICB9XG5cbiAgICBjb25zdCBkaXNwb3NpdGlvbk5hbWUgPSBgZmlsZW5hbWU9XFxcIiR7ZW5jb2RlVVJJKHZSZWYubmFtZSB8fCBmaWxlUmVmLm5hbWUpLnJlcGxhY2UoL1xcLC9nLCAnJTJDJyl9XFxcIjsgZmlsZW5hbWUqPVVURi04Jycke2VuY29kZVVSSUNvbXBvbmVudCh2UmVmLm5hbWUgfHwgZmlsZVJlZi5uYW1lKX07IGA7XG4gICAgY29uc3QgZGlzcG9zaXRpb25FbmNvZGluZyA9ICdjaGFyc2V0PVVURi04JztcblxuICAgIGlmICghaHR0cC5yZXNwb25zZS5oZWFkZXJzU2VudCkge1xuICAgICAgaHR0cC5yZXNwb25zZS5zZXRIZWFkZXIoJ0NvbnRlbnQtRGlzcG9zaXRpb24nLCBkaXNwb3NpdGlvblR5cGUgKyBkaXNwb3NpdGlvbk5hbWUgKyBkaXNwb3NpdGlvbkVuY29kaW5nKTtcbiAgICB9XG5cbiAgICBpZiAoaHR0cC5yZXF1ZXN0LmhlYWRlcnMucmFuZ2UgJiYgIWZvcmNlMjAwKSB7XG4gICAgICBwYXJ0aXJhbCA9IHRydWU7XG4gICAgICBjb25zdCBhcnJheSA9IGh0dHAucmVxdWVzdC5oZWFkZXJzLnJhbmdlLnNwbGl0KC9ieXRlcz0oWzAtOV0qKS0oWzAtOV0qKS8pO1xuICAgICAgc3RhcnQgPSBwYXJzZUludChhcnJheVsxXSk7XG4gICAgICBlbmQgPSBwYXJzZUludChhcnJheVsyXSk7XG4gICAgICBpZiAoaXNOYU4oZW5kKSkge1xuICAgICAgICBlbmQgPSB2UmVmLnNpemUgLSAxO1xuICAgICAgfVxuICAgICAgdGFrZSA9IGVuZCAtIHN0YXJ0O1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGFydCA9IDA7XG4gICAgICBlbmQgPSB2UmVmLnNpemUgLSAxO1xuICAgICAgdGFrZSA9IHZSZWYuc2l6ZTtcbiAgICB9XG5cbiAgICBpZiAocGFydGlyYWwgfHwgKGh0dHAucGFyYW1zLnF1ZXJ5LnBsYXkgJiYgKGh0dHAucGFyYW1zLnF1ZXJ5LnBsYXkgPT09ICd0cnVlJykpKSB7XG4gICAgICByZXFSYW5nZSA9IHtzdGFydCwgZW5kfTtcbiAgICAgIGlmIChpc05hTihzdGFydCkgJiYgIWlzTmFOKGVuZCkpIHtcbiAgICAgICAgcmVxUmFuZ2Uuc3RhcnQgPSBlbmQgLSB0YWtlO1xuICAgICAgICByZXFSYW5nZS5lbmQgICA9IGVuZDtcbiAgICAgIH1cbiAgICAgIGlmICghaXNOYU4oc3RhcnQpICYmIGlzTmFOKGVuZCkpIHtcbiAgICAgICAgcmVxUmFuZ2Uuc3RhcnQgPSBzdGFydDtcbiAgICAgICAgcmVxUmFuZ2UuZW5kICAgPSBzdGFydCArIHRha2U7XG4gICAgICB9XG5cbiAgICAgIGlmICgoc3RhcnQgKyB0YWtlKSA+PSB2UmVmLnNpemUpIHtcbiAgICAgICAgcmVxUmFuZ2UuZW5kID0gdlJlZi5zaXplIC0gMTtcbiAgICAgIH1cblxuICAgICAgaWYgKHRoaXMuc3RyaWN0ICYmICgocmVxUmFuZ2Uuc3RhcnQgPj0gKHZSZWYuc2l6ZSAtIDEpKSB8fCAocmVxUmFuZ2UuZW5kID4gKHZSZWYuc2l6ZSAtIDEpKSkpIHtcbiAgICAgICAgcmVzcG9uc2VUeXBlID0gJzQxNic7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXNwb25zZVR5cGUgPSAnMjA2JztcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcmVzcG9uc2VUeXBlID0gJzIwMCc7XG4gICAgfVxuXG4gICAgY29uc3Qgc3RyZWFtRXJyb3JIYW5kbGVyID0gKGVycm9yKSA9PiB7XG4gICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW3NlcnZlKCR7dlJlZi5wYXRofSwgJHt2ZXJzaW9ufSldIFs1MDBdYCwgZXJyb3IpO1xuICAgICAgaWYgKCFodHRwLnJlc3BvbnNlLmZpbmlzaGVkKSB7XG4gICAgICAgIGh0dHAucmVzcG9uc2UuZW5kKGVycm9yLnRvU3RyaW5nKCkpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBjb25zdCBoZWFkZXJzID0gaGVscGVycy5pc0Z1bmN0aW9uKHRoaXMucmVzcG9uc2VIZWFkZXJzKSA/IHRoaXMucmVzcG9uc2VIZWFkZXJzKHJlc3BvbnNlVHlwZSwgZmlsZVJlZiwgdlJlZiwgdmVyc2lvbiwgaHR0cCkgOiB0aGlzLnJlc3BvbnNlSGVhZGVycztcblxuICAgIGlmICghaGVhZGVyc1snQ2FjaGUtQ29udHJvbCddKSB7XG4gICAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgaHR0cC5yZXNwb25zZS5zZXRIZWFkZXIoJ0NhY2hlLUNvbnRyb2wnLCB0aGlzLmNhY2hlQ29udHJvbCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgZm9yIChsZXQga2V5IGluIGhlYWRlcnMpIHtcbiAgICAgIGlmICghaHR0cC5yZXNwb25zZS5oZWFkZXJzU2VudCkge1xuICAgICAgICBodHRwLnJlc3BvbnNlLnNldEhlYWRlcihrZXksIGhlYWRlcnNba2V5XSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgcmVzcG9uZCA9IChzdHJlYW0sIGNvZGUpID0+IHtcbiAgICAgIHN0cmVhbS5faXNFbmRlZCA9IGZhbHNlO1xuICAgICAgY29uc3QgY2xvc2VTdHJlYW1DYiA9IChjbG9zZUVycm9yKSA9PiB7XG4gICAgICAgIGlmICghY2xvc2VFcnJvcikge1xuICAgICAgICAgIHN0cmVhbS5faXNFbmRlZCA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtzZXJ2ZSgke3ZSZWYucGF0aH0sICR7dmVyc2lvbn0pXSBbcmVzcG9uZF0gW2Nsb3NlU3RyZWFtQ2JdIEVycm9yOmAsIGNsb3NlRXJyb3IpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICBjb25zdCBjbG9zZVN0cmVhbSA9ICgpID0+IHtcbiAgICAgICAgaWYgKCFzdHJlYW0uX2lzRW5kZWQpIHtcbiAgICAgICAgICBpZiAodHlwZW9mIHN0cmVhbS5jbG9zZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgc3RyZWFtLmNsb3NlKGNsb3NlU3RyZWFtQ2IpO1xuICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHN0cmVhbS5lbmQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHN0cmVhbS5lbmQoY2xvc2VTdHJlYW1DYik7XG4gICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2Ygc3RyZWFtLmRlc3Ryb3kgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHN0cmVhbS5kZXN0cm95KCdHb3QgdG8gY2xvc2UgdGhpcyBzdHJlYW0nLCBjbG9zZVN0cmVhbUNiKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIGlmICghaHR0cC5yZXNwb25zZS5oZWFkZXJzU2VudCAmJiByZWFkYWJsZVN0cmVhbSkge1xuICAgICAgICBodHRwLnJlc3BvbnNlLndyaXRlSGVhZChjb2RlKTtcbiAgICAgIH1cblxuICAgICAgaHR0cC5yZXNwb25zZS5vbignY2xvc2UnLCBjbG9zZVN0cmVhbSk7XG4gICAgICBodHRwLnJlcXVlc3Qub24oJ2Fib3J0ZWQnLCAoKSA9PiB7XG4gICAgICAgIGh0dHAucmVxdWVzdC5hYm9ydGVkID0gdHJ1ZTtcbiAgICAgICAgY2xvc2VTdHJlYW0oKTtcbiAgICAgIH0pO1xuXG4gICAgICBzdHJlYW0ub24oJ29wZW4nLCAoKSA9PiB7XG4gICAgICAgIGlmICghaHR0cC5yZXNwb25zZS5oZWFkZXJzU2VudCkge1xuICAgICAgICAgIGh0dHAucmVzcG9uc2Uud3JpdGVIZWFkKGNvZGUpO1xuICAgICAgICB9XG4gICAgICB9KS5vbignYWJvcnQnLCAoKSA9PiB7XG4gICAgICAgIGNsb3NlU3RyZWFtKCk7XG4gICAgICAgIGlmICghaHR0cC5yZXNwb25zZS5maW5pc2hlZCkge1xuICAgICAgICAgIGh0dHAucmVzcG9uc2UuZW5kKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFodHRwLnJlcXVlc3QuYWJvcnRlZCkge1xuICAgICAgICAgIGh0dHAucmVxdWVzdC5kZXN0cm95KCk7XG4gICAgICAgIH1cbiAgICAgIH0pLm9uKCdlcnJvcicsIChlcnIpID0+IHtcbiAgICAgICAgY2xvc2VTdHJlYW0oKTtcbiAgICAgICAgc3RyZWFtRXJyb3JIYW5kbGVyKGVycik7XG4gICAgICB9KS5vbignZW5kJywgKCkgPT4ge1xuICAgICAgICBjbG9zZVN0cmVhbSgpO1xuICAgICAgICBpZiAoIWh0dHAucmVzcG9uc2UuZmluaXNoZWQpIHtcbiAgICAgICAgICBodHRwLnJlc3BvbnNlLmVuZCgpO1xuICAgICAgICB9XG4gICAgICB9KS5waXBlKGh0dHAucmVzcG9uc2UpO1xuICAgIH07XG5cbiAgICBzd2l0Y2ggKHJlc3BvbnNlVHlwZSkge1xuICAgIGNhc2UgJzQwMCc6XG4gICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW3NlcnZlKCR7dlJlZi5wYXRofSwgJHt2ZXJzaW9ufSldIFs0MDBdIENvbnRlbnQtTGVuZ3RoIG1pc21hdGNoIWApO1xuICAgICAgdmFyIHRleHQgPSAnQ29udGVudC1MZW5ndGggbWlzbWF0Y2ghJztcblxuICAgICAgaWYgKCFodHRwLnJlc3BvbnNlLmhlYWRlcnNTZW50KSB7XG4gICAgICAgIGh0dHAucmVzcG9uc2Uud3JpdGVIZWFkKDQwMCwge1xuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAndGV4dC9wbGFpbicsXG4gICAgICAgICAgJ0NvbnRlbnQtTGVuZ3RoJzogdGV4dC5sZW5ndGhcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGlmICghaHR0cC5yZXNwb25zZS5maW5pc2hlZCkge1xuICAgICAgICBodHRwLnJlc3BvbnNlLmVuZCh0ZXh0KTtcbiAgICAgIH1cbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJzQwNCc6XG4gICAgICB0aGlzLl80MDQoaHR0cCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICc0MTYnOlxuICAgICAgdGhpcy5fZGVidWcoYFtGaWxlc0NvbGxlY3Rpb25dIFtzZXJ2ZSgke3ZSZWYucGF0aH0sICR7dmVyc2lvbn0pXSBbNDE2XSBDb250ZW50LVJhbmdlIGlzIG5vdCBzcGVjaWZpZWQhYCk7XG4gICAgICBpZiAoIWh0dHAucmVzcG9uc2UuaGVhZGVyc1NlbnQpIHtcbiAgICAgICAgaHR0cC5yZXNwb25zZS53cml0ZUhlYWQoNDE2KTtcbiAgICAgIH1cbiAgICAgIGlmICghaHR0cC5yZXNwb25zZS5maW5pc2hlZCkge1xuICAgICAgICBodHRwLnJlc3BvbnNlLmVuZCgpO1xuICAgICAgfVxuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnMjA2JzpcbiAgICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbc2VydmUoJHt2UmVmLnBhdGh9LCAke3ZlcnNpb259KV0gWzIwNl1gKTtcbiAgICAgIGlmICghaHR0cC5yZXNwb25zZS5oZWFkZXJzU2VudCkge1xuICAgICAgICBodHRwLnJlc3BvbnNlLnNldEhlYWRlcignQ29udGVudC1SYW5nZScsIGBieXRlcyAke3JlcVJhbmdlLnN0YXJ0fS0ke3JlcVJhbmdlLmVuZH0vJHt2UmVmLnNpemV9YCk7XG4gICAgICB9XG4gICAgICByZXNwb25kKHJlYWRhYmxlU3RyZWFtIHx8IGZzLmNyZWF0ZVJlYWRTdHJlYW0odlJlZi5wYXRoLCB7c3RhcnQ6IHJlcVJhbmdlLnN0YXJ0LCBlbmQ6IHJlcVJhbmdlLmVuZH0pLCAyMDYpO1xuICAgICAgYnJlYWs7XG4gICAgZGVmYXVsdDpcbiAgICAgIGlmICghaHR0cC5yZXNwb25zZS5oZWFkZXJzU2VudCkge1xuICAgICAgICBodHRwLnJlc3BvbnNlLnNldEhlYWRlcignQ29udGVudC1MZW5ndGgnLCBgJHt2UmVmLnNpemV9YCk7XG4gICAgICB9XG4gICAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW3NlcnZlKCR7dlJlZi5wYXRofSwgJHt2ZXJzaW9ufSldIFsyMDBdYCk7XG4gICAgICByZXNwb25kKHJlYWRhYmxlU3RyZWFtIHx8IGZzLmNyZWF0ZVJlYWRTdHJlYW0odlJlZi5wYXRoKSwgMjAwKTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxufVxuIiwiaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRlbWl0dGVyMyc7XG5pbXBvcnQgeyBjaGVjaywgTWF0Y2ggfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuaW1wb3J0IHsgZm9ybWF0RmxlVVJMLCBoZWxwZXJzIH0gZnJvbSAnLi9saWIuanMnO1xuaW1wb3J0IHsgRmlsZXNDdXJzb3IsIEZpbGVDdXJzb3IgfSBmcm9tICcuL2N1cnNvci5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEZpbGVzQ29sbGVjdGlvbkNvcmUgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpO1xuICB9XG5cbiAgc3RhdGljIF9faGVscGVycyA9IGhlbHBlcnM7XG5cbiAgc3RhdGljIHNjaGVtYSA9IHtcbiAgICBfaWQ6IHtcbiAgICAgIHR5cGU6IFN0cmluZ1xuICAgIH0sXG4gICAgc2l6ZToge1xuICAgICAgdHlwZTogTnVtYmVyXG4gICAgfSxcbiAgICBuYW1lOiB7XG4gICAgICB0eXBlOiBTdHJpbmdcbiAgICB9LFxuICAgIHR5cGU6IHtcbiAgICAgIHR5cGU6IFN0cmluZ1xuICAgIH0sXG4gICAgcGF0aDoge1xuICAgICAgdHlwZTogU3RyaW5nXG4gICAgfSxcbiAgICBpc1ZpZGVvOiB7XG4gICAgICB0eXBlOiBCb29sZWFuXG4gICAgfSxcbiAgICBpc0F1ZGlvOiB7XG4gICAgICB0eXBlOiBCb29sZWFuXG4gICAgfSxcbiAgICBpc0ltYWdlOiB7XG4gICAgICB0eXBlOiBCb29sZWFuXG4gICAgfSxcbiAgICBpc1RleHQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW5cbiAgICB9LFxuICAgIGlzSlNPTjoge1xuICAgICAgdHlwZTogQm9vbGVhblxuICAgIH0sXG4gICAgaXNQREY6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW5cbiAgICB9LFxuICAgIGV4dGVuc2lvbjoge1xuICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGV4dDoge1xuICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9LFxuICAgIGV4dGVuc2lvbldpdGhEb3Q6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBtaW1lOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgJ21pbWUtdHlwZSc6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBfc3RvcmFnZVBhdGg6IHtcbiAgICAgIHR5cGU6IFN0cmluZ1xuICAgIH0sXG4gICAgX2Rvd25sb2FkUm91dGU6IHtcbiAgICAgIHR5cGU6IFN0cmluZ1xuICAgIH0sXG4gICAgX2NvbGxlY3Rpb25OYW1lOiB7XG4gICAgICB0eXBlOiBTdHJpbmdcbiAgICB9LFxuICAgIHB1YmxpYzoge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICBtZXRhOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBibGFja2JveDogdHJ1ZSxcbiAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICB1c2VySWQ6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSxcbiAgICB1cGRhdGVkQXQ6IHtcbiAgICAgIHR5cGU6IERhdGUsXG4gICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0sXG4gICAgdmVyc2lvbnM6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIGJsYWNrYm94OiB0cnVlXG4gICAgfVxuICB9O1xuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uQ29yZVxuICAgKiBAbmFtZSBfZGVidWdcbiAgICogQHN1bW1hcnkgUHJpbnQgbG9ncyBpbiBkZWJ1ZyBtb2RlXG4gICAqIEByZXR1cm5zIHt2b2lkfVxuICAgKi9cbiAgX2RlYnVnKCkge1xuICAgIGlmICh0aGlzLmRlYnVnKSB7XG4gICAgICAoY29uc29sZS5pbmZvIHx8IGNvbnNvbGUubG9nIHx8IGZ1bmN0aW9uICgpIHsgfSkuYXBwbHkodm9pZCAwLCBhcmd1bWVudHMpO1xuICAgIH1cbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uQ29yZVxuICAgKiBAbmFtZSBfZ2V0RmlsZU5hbWVcbiAgICogQHBhcmFtIHtPYmplY3R9IGZpbGVEYXRhIC0gRmlsZSBPYmplY3RcbiAgICogQHN1bW1hcnkgUmV0dXJucyBmaWxlJ3MgbmFtZVxuICAgKiBAcmV0dXJucyB7U3RyaW5nfVxuICAgKi9cbiAgX2dldEZpbGVOYW1lKGZpbGVEYXRhKSB7XG4gICAgY29uc3QgZmlsZU5hbWUgPSBmaWxlRGF0YS5uYW1lIHx8IGZpbGVEYXRhLmZpbGVOYW1lO1xuICAgIGlmIChoZWxwZXJzLmlzU3RyaW5nKGZpbGVOYW1lKSAmJiAoZmlsZU5hbWUubGVuZ3RoID4gMCkpIHtcbiAgICAgIHJldHVybiAoZmlsZURhdGEubmFtZSB8fCBmaWxlRGF0YS5maWxlTmFtZSkucmVwbGFjZSgvXlxcLlxcLisvLCAnJykucmVwbGFjZSgvXFwuezIsfS9nLCAnLicpLnJlcGxhY2UoL1xcLy9nLCAnJyk7XG4gICAgfVxuICAgIHJldHVybiAnJztcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDb2xsZWN0aW9uQ29yZVxuICAgKiBAbmFtZSBfZ2V0RXh0XG4gICAqIEBwYXJhbSB7U3RyaW5nfSBGaWxlTmFtZSAtIEZpbGUgbmFtZVxuICAgKiBAc3VtbWFyeSBHZXQgZXh0ZW5zaW9uIGZyb20gRmlsZU5hbWVcbiAgICogQHJldHVybnMge09iamVjdH1cbiAgICovXG4gIF9nZXRFeHQoZmlsZU5hbWUpIHtcbiAgICBpZiAoZmlsZU5hbWUuaW5jbHVkZXMoJy4nKSkge1xuICAgICAgY29uc3QgZXh0ZW5zaW9uID0gKGZpbGVOYW1lLnNwbGl0KCcuJykucG9wKCkuc3BsaXQoJz8nKVswXSB8fCAnJykudG9Mb3dlckNhc2UoKTtcbiAgICAgIHJldHVybiB7IGV4dDogZXh0ZW5zaW9uLCBleHRlbnNpb24sIGV4dGVuc2lvbldpdGhEb3Q6IGAuJHtleHRlbnNpb259YCB9O1xuICAgIH1cbiAgICByZXR1cm4geyBleHQ6ICcnLCBleHRlbnNpb246ICcnLCBleHRlbnNpb25XaXRoRG90OiAnJyB9O1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25Db3JlXG4gICAqIEBuYW1lIF91cGRhdGVGaWxlVHlwZXNcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEgLSBGaWxlIGRhdGFcbiAgICogQHN1bW1hcnkgSW50ZXJuYWwgbWV0aG9kLiBDbGFzc2lmeSBmaWxlIGJhc2VkIG9uICd0eXBlJyBmaWVsZFxuICAgKi9cbiAgX3VwZGF0ZUZpbGVUeXBlcyhkYXRhKSB7XG4gICAgZGF0YS5pc1ZpZGVvID0gL152aWRlb1xcLy9pLnRlc3QoZGF0YS50eXBlKTtcbiAgICBkYXRhLmlzQXVkaW8gPSAvXmF1ZGlvXFwvL2kudGVzdChkYXRhLnR5cGUpO1xuICAgIGRhdGEuaXNJbWFnZSA9IC9eaW1hZ2VcXC8vaS50ZXN0KGRhdGEudHlwZSk7XG4gICAgZGF0YS5pc1RleHQgPSAvXnRleHRcXC8vaS50ZXN0KGRhdGEudHlwZSk7XG4gICAgZGF0YS5pc0pTT04gPSAvXmFwcGxpY2F0aW9uXFwvanNvbiQvaS50ZXN0KGRhdGEudHlwZSk7XG4gICAgZGF0YS5pc1BERiA9IC9eYXBwbGljYXRpb25cXC8oeC0pP3BkZiQvaS50ZXN0KGRhdGEudHlwZSk7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvbkNvcmVcbiAgICogQG5hbWUgX2RhdGFUb1NjaGVtYVxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSAtIEZpbGUgZGF0YVxuICAgKiBAc3VtbWFyeSBJbnRlcm5hbCBtZXRob2QuIEJ1aWxkIG9iamVjdCBpbiBhY2NvcmRhbmNlIHdpdGggZGVmYXVsdCBzY2hlbWEgZnJvbSBGaWxlIGRhdGFcbiAgICogQHJldHVybnMge09iamVjdH1cbiAgICovXG4gIF9kYXRhVG9TY2hlbWEoZGF0YSkge1xuICAgIGNvbnN0IGRzID0ge1xuICAgICAgbmFtZTogZGF0YS5uYW1lLFxuICAgICAgZXh0ZW5zaW9uOiBkYXRhLmV4dGVuc2lvbixcbiAgICAgIGV4dDogZGF0YS5leHRlbnNpb24sXG4gICAgICBleHRlbnNpb25XaXRoRG90OiAnLicgKyBkYXRhLmV4dGVuc2lvbixcbiAgICAgIHBhdGg6IGRhdGEucGF0aCxcbiAgICAgIG1ldGE6IGRhdGEubWV0YSxcbiAgICAgIHR5cGU6IGRhdGEudHlwZSxcbiAgICAgIG1pbWU6IGRhdGEudHlwZSxcbiAgICAgICdtaW1lLXR5cGUnOiBkYXRhLnR5cGUsXG4gICAgICBzaXplOiBkYXRhLnNpemUsXG4gICAgICB1c2VySWQ6IGRhdGEudXNlcklkIHx8IG51bGwsXG4gICAgICB2ZXJzaW9uczoge1xuICAgICAgICBvcmlnaW5hbDoge1xuICAgICAgICAgIHBhdGg6IGRhdGEucGF0aCxcbiAgICAgICAgICBzaXplOiBkYXRhLnNpemUsXG4gICAgICAgICAgdHlwZTogZGF0YS50eXBlLFxuICAgICAgICAgIGV4dGVuc2lvbjogZGF0YS5leHRlbnNpb25cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIF9kb3dubG9hZFJvdXRlOiBkYXRhLl9kb3dubG9hZFJvdXRlIHx8IHRoaXMuZG93bmxvYWRSb3V0ZSxcbiAgICAgIF9jb2xsZWN0aW9uTmFtZTogZGF0YS5fY29sbGVjdGlvbk5hbWUgfHwgdGhpcy5jb2xsZWN0aW9uTmFtZVxuICAgIH07XG5cbiAgICAvL09wdGlvbmFsIGZpbGVJZFxuICAgIGlmIChkYXRhLmZpbGVJZCkge1xuICAgICAgZHMuX2lkID0gZGF0YS5maWxlSWQ7XG4gICAgfVxuXG4gICAgdGhpcy5fdXBkYXRlRmlsZVR5cGVzKGRzKTtcbiAgICBkcy5fc3RvcmFnZVBhdGggPSBkYXRhLl9zdG9yYWdlUGF0aCB8fCB0aGlzLnN0b3JhZ2VQYXRoKE9iamVjdC5hc3NpZ24oe30sIGRhdGEsIGRzKSk7XG4gICAgcmV0dXJuIGRzO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25Db3JlXG4gICAqIEBuYW1lIGZpbmRPbmVcbiAgICogQHBhcmFtIHtTdHJpbmd8T2JqZWN0fSBzZWxlY3RvciAtIE1vbmdvLVN0eWxlIHNlbGVjdG9yIChodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9jb2xsZWN0aW9ucy5odG1sI3NlbGVjdG9ycylcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgLSBNb25nby1TdHlsZSBzZWxlY3RvciBPcHRpb25zIChodHRwOi8vZG9jcy5tZXRlb3IuY29tL2FwaS9jb2xsZWN0aW9ucy5odG1sI3NvcnRzcGVjaWZpZXJzKVxuICAgKiBAc3VtbWFyeSBGaW5kIGFuZCByZXR1cm4gQ3Vyc29yIGZvciBtYXRjaGluZyBkb2N1bWVudCBPYmplY3RcbiAgICogQHJldHVybnMge0ZpbGVDdXJzb3J9IEluc3RhbmNlXG4gICAqL1xuICBmaW5kT25lKHNlbGVjdG9yID0ge30sIG9wdGlvbnMpIHtcbiAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW2ZpbmRPbmUoJHtKU09OLnN0cmluZ2lmeShzZWxlY3Rvcil9LCAke0pTT04uc3RyaW5naWZ5KG9wdGlvbnMpfSldYCk7XG4gICAgY2hlY2soc2VsZWN0b3IsIE1hdGNoLk9wdGlvbmFsKE1hdGNoLk9uZU9mKE9iamVjdCwgU3RyaW5nLCBCb29sZWFuLCBOdW1iZXIsIG51bGwpKSk7XG4gICAgY2hlY2sob3B0aW9ucywgTWF0Y2guT3B0aW9uYWwoT2JqZWN0KSk7XG5cbiAgICBjb25zdCBkb2MgPSB0aGlzLmNvbGxlY3Rpb24uZmluZE9uZShzZWxlY3Rvciwgb3B0aW9ucyk7XG4gICAgaWYgKGRvYykge1xuICAgICAgcmV0dXJuIG5ldyBGaWxlQ3Vyc29yKGRvYywgdGhpcyk7XG4gICAgfVxuICAgIHJldHVybiBkb2M7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ29sbGVjdGlvbkNvcmVcbiAgICogQG5hbWUgZmluZFxuICAgKiBAcGFyYW0ge1N0cmluZ3xPYmplY3R9IHNlbGVjdG9yIC0gTW9uZ28tU3R5bGUgc2VsZWN0b3IgKGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjc2VsZWN0b3JzKVxuICAgKiBAcGFyYW0ge09iamVjdH0gICAgICAgIG9wdGlvbnMgIC0gTW9uZ28tU3R5bGUgc2VsZWN0b3IgT3B0aW9ucyAoaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNzb3J0c3BlY2lmaWVycylcbiAgICogQHN1bW1hcnkgRmluZCBhbmQgcmV0dXJuIEN1cnNvciBmb3IgbWF0Y2hpbmcgZG9jdW1lbnRzXG4gICAqIEByZXR1cm5zIHtGaWxlc0N1cnNvcn0gSW5zdGFuY2VcbiAgICovXG4gIGZpbmQoc2VsZWN0b3IgPSB7fSwgb3B0aW9ucykge1xuICAgIHRoaXMuX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbZmluZCgke0pTT04uc3RyaW5naWZ5KHNlbGVjdG9yKX0sICR7SlNPTi5zdHJpbmdpZnkob3B0aW9ucyl9KV1gKTtcbiAgICBjaGVjayhzZWxlY3RvciwgTWF0Y2guT3B0aW9uYWwoTWF0Y2guT25lT2YoT2JqZWN0LCBTdHJpbmcsIEJvb2xlYW4sIE51bWJlciwgbnVsbCkpKTtcbiAgICBjaGVjayhvcHRpb25zLCBNYXRjaC5PcHRpb25hbChPYmplY3QpKTtcblxuICAgIHJldHVybiBuZXcgRmlsZXNDdXJzb3Ioc2VsZWN0b3IsIG9wdGlvbnMsIHRoaXMpO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25Db3JlXG4gICAqIEBuYW1lIHVwZGF0ZVxuICAgKiBAc2VlIGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vIy9mdWxsL3VwZGF0ZVxuICAgKiBAc3VtbWFyeSBsaW5rIE1vbmdvLkNvbGxlY3Rpb24gdXBkYXRlIG1ldGhvZFxuICAgKiBAcmV0dXJucyB7TW9uZ28uQ29sbGVjdGlvbn0gSW5zdGFuY2VcbiAgICovXG4gIHVwZGF0ZSgpIHtcbiAgICB0aGlzLmNvbGxlY3Rpb24udXBkYXRlLmFwcGx5KHRoaXMuY29sbGVjdGlvbiwgYXJndW1lbnRzKTtcbiAgICByZXR1cm4gdGhpcy5jb2xsZWN0aW9uO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0NvbGxlY3Rpb25Db3JlXG4gICAqIEBuYW1lIGxpbmtcbiAgICogQHBhcmFtIHtPYmplY3R9IGZpbGVSZWYgLSBGaWxlIHJlZmVyZW5jZSBvYmplY3RcbiAgICogQHBhcmFtIHtTdHJpbmd9IHZlcnNpb24gLSBWZXJzaW9uIG9mIGZpbGUgeW91IHdvdWxkIGxpa2UgdG8gcmVxdWVzdFxuICAgKiBAcGFyYW0ge1N0cmluZ30gVVJJQmFzZSAtIFtPcHRpb25hbF0gVVJJIGJhc2UsIHNlZSAtIGh0dHBzOi8vZ2l0aHViLmNvbS9WZWxpb3ZHcm91cC9NZXRlb3ItRmlsZXMvaXNzdWVzLzYyNlxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGRvd25sb2FkYWJsZSBVUkxcbiAgICogQHJldHVybnMge1N0cmluZ30gRW1wdHkgc3RyaW5nIHJldHVybmVkIGluIGNhc2UgaWYgZmlsZSBub3QgZm91bmQgaW4gREJcbiAgICovXG4gIGxpbmsoZmlsZVJlZiwgdmVyc2lvbiA9ICdvcmlnaW5hbCcsIFVSSUJhc2UpIHtcbiAgICB0aGlzLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW2xpbmsoJHsoaGVscGVycy5pc09iamVjdChmaWxlUmVmKSA/IGZpbGVSZWYuX2lkIDogdm9pZCAwKX0sICR7dmVyc2lvbn0pXWApO1xuICAgIGNoZWNrKGZpbGVSZWYsIE9iamVjdCk7XG5cbiAgICBpZiAoIWZpbGVSZWYpIHtcbiAgICAgIHJldHVybiAnJztcbiAgICB9XG4gICAgcmV0dXJuIGZvcm1hdEZsZVVSTChmaWxlUmVmLCB2ZXJzaW9uLCBVUklCYXNlKTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbi8qXG4gKiBAcHJpdmF0ZVxuICogQGxvY3VzIEFueXdoZXJlXG4gKiBAY2xhc3MgRmlsZUN1cnNvclxuICogQHBhcmFtIF9maWxlUmVmICAgIHtPYmplY3R9IC0gTW9uZ28tU3R5bGUgc2VsZWN0b3IgKGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjc2VsZWN0b3JzKVxuICogQHBhcmFtIF9jb2xsZWN0aW9uIHtGaWxlc0NvbGxlY3Rpb259IC0gRmlsZXNDb2xsZWN0aW9uIEluc3RhbmNlXG4gKiBAc3VtbWFyeSBJbnRlcm5hbCBjbGFzcywgcmVwcmVzZW50cyBlYWNoIHJlY29yZCBpbiBgRmlsZXNDdXJzb3IuZWFjaCgpYCBvciBkb2N1bWVudCByZXR1cm5lZCBmcm9tIGAuZmluZE9uZSgpYCBtZXRob2RcbiAqL1xuZXhwb3J0IGNsYXNzIEZpbGVDdXJzb3Ige1xuICBjb25zdHJ1Y3RvcihfZmlsZVJlZiwgX2NvbGxlY3Rpb24pIHtcbiAgICB0aGlzLl9maWxlUmVmICAgID0gX2ZpbGVSZWY7XG4gICAgdGhpcy5fY29sbGVjdGlvbiA9IF9jb2xsZWN0aW9uO1xuICAgIE9iamVjdC5hc3NpZ24odGhpcywgX2ZpbGVSZWYpO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlQ3Vyc29yXG4gICAqIEBuYW1lIHJlbW92ZVxuICAgKiBAcGFyYW0gY2FsbGJhY2sge0Z1bmN0aW9ufSAtIFRyaWdnZXJlZCBhc3luY2hyb25vdXNseSBhZnRlciBpdGVtIGlzIHJlbW92ZWQgb3IgZmFpbGVkIHRvIGJlIHJlbW92ZWRcbiAgICogQHN1bW1hcnkgUmVtb3ZlIGRvY3VtZW50XG4gICAqIEByZXR1cm5zIHtGaWxlQ3Vyc29yfVxuICAgKi9cbiAgcmVtb3ZlKGNhbGxiYWNrKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlQ3Vyc29yXSBbcmVtb3ZlKCldJyk7XG4gICAgaWYgKHRoaXMuX2ZpbGVSZWYpIHtcbiAgICAgIHRoaXMuX2NvbGxlY3Rpb24ucmVtb3ZlKHRoaXMuX2ZpbGVSZWYuX2lkLCBjYWxsYmFjayk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNhbGxiYWNrICYmIGNhbGxiYWNrKG5ldyBNZXRlb3IuRXJyb3IoNDA0LCAnTm8gc3VjaCBmaWxlJykpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZUN1cnNvclxuICAgKiBAbmFtZSBsaW5rXG4gICAqIEBwYXJhbSB2ZXJzaW9uIHtTdHJpbmd9IC0gTmFtZSBvZiBmaWxlJ3Mgc3VidmVyc2lvblxuICAgKiBAcGFyYW0gVVJJQmFzZSB7U3RyaW5nfSAtIFtPcHRpb25hbF0gVVJJIGJhc2UsIHNlZSAtIGh0dHBzOi8vZ2l0aHViLmNvbS9WZWxpb3ZHcm91cC9NZXRlb3ItRmlsZXMvaXNzdWVzLzYyNlxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGRvd25sb2FkYWJsZSBVUkwgdG8gRmlsZVxuICAgKiBAcmV0dXJucyB7U3RyaW5nfVxuICAgKi9cbiAgbGluayh2ZXJzaW9uID0gJ29yaWdpbmFsJywgVVJJQmFzZSkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKGBbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZUN1cnNvcl0gW2xpbmsoJHt2ZXJzaW9ufSldYCk7XG4gICAgaWYgKHRoaXMuX2ZpbGVSZWYpIHtcbiAgICAgIHJldHVybiB0aGlzLl9jb2xsZWN0aW9uLmxpbmsodGhpcy5fZmlsZVJlZiwgdmVyc2lvbiwgVVJJQmFzZSk7XG4gICAgfVxuICAgIHJldHVybiAnJztcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZUN1cnNvclxuICAgKiBAbmFtZSBnZXRcbiAgICogQHBhcmFtIHByb3BlcnR5IHtTdHJpbmd9IC0gTmFtZSBvZiBzdWItb2JqZWN0IHByb3BlcnR5XG4gICAqIEBzdW1tYXJ5IFJldHVybnMgY3VycmVudCBkb2N1bWVudCBhcyBhIHBsYWluIE9iamVjdCwgaWYgYHByb3BlcnR5YCBpcyBzcGVjaWZpZWQgLSByZXR1cm5zIHZhbHVlIG9mIHN1Yi1vYmplY3QgcHJvcGVydHlcbiAgICogQHJldHVybnMge09iamVjdHxtaXh9XG4gICAqL1xuICBnZXQocHJvcGVydHkpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZyhgW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVDdXJzb3JdIFtnZXQoJHtwcm9wZXJ0eX0pXWApO1xuICAgIGlmIChwcm9wZXJ0eSkge1xuICAgICAgcmV0dXJuIHRoaXMuX2ZpbGVSZWZbcHJvcGVydHldO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fZmlsZVJlZjtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZUN1cnNvclxuICAgKiBAbmFtZSBmZXRjaFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGRvY3VtZW50IGFzIHBsYWluIE9iamVjdCBpbiBBcnJheVxuICAgKiBAcmV0dXJucyB7W09iamVjdF19XG4gICAqL1xuICBmZXRjaCgpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVDdXJzb3JdIFtmZXRjaCgpXScpO1xuICAgIHJldHVybiBbdGhpcy5fZmlsZVJlZl07XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVDdXJzb3JcbiAgICogQG5hbWUgd2l0aFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIHJlYWN0aXZlIHZlcnNpb24gb2YgY3VycmVudCBGaWxlQ3Vyc29yLCB1c2VmdWwgdG8gdXNlIHdpdGggYHt7I3dpdGh9fS4uLnt7L3dpdGh9fWAgYmxvY2sgdGVtcGxhdGUgaGVscGVyXG4gICAqIEByZXR1cm5zIHtbT2JqZWN0XX1cbiAgICovXG4gIHdpdGgoKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlQ3Vyc29yXSBbd2l0aCgpXScpO1xuICAgIHJldHVybiBPYmplY3QuYXNzaWduKHRoaXMsIHRoaXMuX2NvbGxlY3Rpb24uY29sbGVjdGlvbi5maW5kT25lKHRoaXMuX2ZpbGVSZWYuX2lkKSk7XG4gIH1cbn1cblxuLypcbiAqIEBwcml2YXRlXG4gKiBAbG9jdXMgQW55d2hlcmVcbiAqIEBjbGFzcyBGaWxlc0N1cnNvclxuICogQHBhcmFtIF9zZWxlY3RvciAgIHtTdHJpbmd8T2JqZWN0fSAgIC0gTW9uZ28tU3R5bGUgc2VsZWN0b3IgKGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjc2VsZWN0b3JzKVxuICogQHBhcmFtIG9wdGlvbnMgICAgIHtPYmplY3R9ICAgICAgICAgIC0gTW9uZ28tU3R5bGUgc2VsZWN0b3IgT3B0aW9ucyAoaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNzZWxlY3RvcnMpXG4gKiBAcGFyYW0gX2NvbGxlY3Rpb24ge0ZpbGVzQ29sbGVjdGlvbn0gLSBGaWxlc0NvbGxlY3Rpb24gSW5zdGFuY2VcbiAqIEBzdW1tYXJ5IEltcGxlbWVudGF0aW9uIG9mIEN1cnNvciBmb3IgRmlsZXNDb2xsZWN0aW9uXG4gKi9cbmV4cG9ydCBjbGFzcyBGaWxlc0N1cnNvciB7XG4gIGNvbnN0cnVjdG9yKF9zZWxlY3RvciA9IHt9LCBvcHRpb25zLCBfY29sbGVjdGlvbikge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24gPSBfY29sbGVjdGlvbjtcbiAgICB0aGlzLl9zZWxlY3RvciAgID0gX3NlbGVjdG9yO1xuICAgIHRoaXMuX2N1cnJlbnQgICAgPSAtMTtcbiAgICB0aGlzLmN1cnNvciAgICAgID0gdGhpcy5fY29sbGVjdGlvbi5jb2xsZWN0aW9uLmZpbmQodGhpcy5fc2VsZWN0b3IsIG9wdGlvbnMpO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBnZXRcbiAgICogQHN1bW1hcnkgUmV0dXJucyBhbGwgbWF0Y2hpbmcgZG9jdW1lbnQocykgYXMgYW4gQXJyYXkuIEFsaWFzIG9mIGAuZmV0Y2goKWBcbiAgICogQHJldHVybnMge1tPYmplY3RdfVxuICAgKi9cbiAgZ2V0KCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtnZXQoKV0nKTtcbiAgICByZXR1cm4gdGhpcy5jdXJzb3IuZmV0Y2goKTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgaGFzTmV4dFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGB0cnVlYCBpZiB0aGVyZSBpcyBuZXh0IGl0ZW0gYXZhaWxhYmxlIG9uIEN1cnNvclxuICAgKiBAcmV0dXJucyB7Qm9vbGVhbn1cbiAgICovXG4gIGhhc05leHQoKSB7XG4gICAgdGhpcy5fY29sbGVjdGlvbi5fZGVidWcoJ1tGaWxlc0NvbGxlY3Rpb25dIFtGaWxlc0N1cnNvcl0gW2hhc05leHQoKV0nKTtcbiAgICByZXR1cm4gdGhpcy5fY3VycmVudCA8ICh0aGlzLmN1cnNvci5jb3VudCgpIC0gMSk7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIG5leHRcbiAgICogQHN1bW1hcnkgUmV0dXJucyBuZXh0IGl0ZW0gb24gQ3Vyc29yLCBpZiBhdmFpbGFibGVcbiAgICogQHJldHVybnMge09iamVjdHx1bmRlZmluZWR9XG4gICAqL1xuICBuZXh0KCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtuZXh0KCldJyk7XG4gICAgdGhpcy5jdXJzb3IuZmV0Y2goKVsrK3RoaXMuX2N1cnJlbnRdO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBoYXNQcmV2aW91c1xuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGB0cnVlYCBpZiB0aGVyZSBpcyBwcmV2aW91cyBpdGVtIGF2YWlsYWJsZSBvbiBDdXJzb3JcbiAgICogQHJldHVybnMge0Jvb2xlYW59XG4gICAqL1xuICBoYXNQcmV2aW91cygpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVzQ3Vyc29yXSBbaGFzUHJldmlvdXMoKV0nKTtcbiAgICByZXR1cm4gdGhpcy5fY3VycmVudCAhPT0gLTE7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIHByZXZpb3VzXG4gICAqIEBzdW1tYXJ5IFJldHVybnMgcHJldmlvdXMgaXRlbSBvbiBDdXJzb3IsIGlmIGF2YWlsYWJsZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fHVuZGVmaW5lZH1cbiAgICovXG4gIHByZXZpb3VzKCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtwcmV2aW91cygpXScpO1xuICAgIHRoaXMuY3Vyc29yLmZldGNoKClbLS10aGlzLl9jdXJyZW50XTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgZmV0Y2hcbiAgICogQHN1bW1hcnkgUmV0dXJucyBhbGwgbWF0Y2hpbmcgZG9jdW1lbnQocykgYXMgYW4gQXJyYXkuXG4gICAqIEByZXR1cm5zIHtbT2JqZWN0XX1cbiAgICovXG4gIGZldGNoKCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtmZXRjaCgpXScpO1xuICAgIHJldHVybiB0aGlzLmN1cnNvci5mZXRjaCgpIHx8IFtdO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBmaXJzdFxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIGZpcnN0IGl0ZW0gb24gQ3Vyc29yLCBpZiBhdmFpbGFibGVcbiAgICogQHJldHVybnMge09iamVjdHx1bmRlZmluZWR9XG4gICAqL1xuICBmaXJzdCgpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVzQ3Vyc29yXSBbZmlyc3QoKV0nKTtcbiAgICB0aGlzLl9jdXJyZW50ID0gMDtcbiAgICByZXR1cm4gdGhpcy5mZXRjaCgpW3RoaXMuX2N1cnJlbnRdO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBsYXN0XG4gICAqIEBzdW1tYXJ5IFJldHVybnMgbGFzdCBpdGVtIG9uIEN1cnNvciwgaWYgYXZhaWxhYmxlXG4gICAqIEByZXR1cm5zIHtPYmplY3R8dW5kZWZpbmVkfVxuICAgKi9cbiAgbGFzdCgpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVzQ3Vyc29yXSBbbGFzdCgpXScpO1xuICAgIHRoaXMuX2N1cnJlbnQgPSB0aGlzLmNvdW50KCkgLSAxO1xuICAgIHJldHVybiB0aGlzLmZldGNoKClbdGhpcy5fY3VycmVudF07XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIGNvdW50XG4gICAqIEBzdW1tYXJ5IFJldHVybnMgdGhlIG51bWJlciBvZiBkb2N1bWVudHMgdGhhdCBtYXRjaCBhIHF1ZXJ5XG4gICAqIEByZXR1cm5zIHtOdW1iZXJ9XG4gICAqL1xuICBjb3VudCgpIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVzQ3Vyc29yXSBbY291bnQoKV0nKTtcbiAgICByZXR1cm4gdGhpcy5jdXJzb3IuY291bnQoKTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgcmVtb3ZlXG4gICAqIEBwYXJhbSBjYWxsYmFjayB7RnVuY3Rpb259IC0gVHJpZ2dlcmVkIGFzeW5jaHJvbm91c2x5IGFmdGVyIGl0ZW0gaXMgcmVtb3ZlZCBvciBmYWlsZWQgdG8gYmUgcmVtb3ZlZFxuICAgKiBAc3VtbWFyeSBSZW1vdmVzIGFsbCBkb2N1bWVudHMgdGhhdCBtYXRjaCBhIHF1ZXJ5XG4gICAqIEByZXR1cm5zIHtGaWxlc0N1cnNvcn1cbiAgICovXG4gIHJlbW92ZShjYWxsYmFjaykge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtyZW1vdmUoKV0nKTtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLnJlbW92ZSh0aGlzLl9zZWxlY3RvciwgY2FsbGJhY2spO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBmb3JFYWNoXG4gICAqIEBwYXJhbSBjYWxsYmFjayB7RnVuY3Rpb259IC0gRnVuY3Rpb24gdG8gY2FsbC4gSXQgd2lsbCBiZSBjYWxsZWQgd2l0aCB0aHJlZSBhcmd1bWVudHM6IHRoZSBgZmlsZWAsIGEgMC1iYXNlZCBpbmRleCwgYW5kIGN1cnNvciBpdHNlbGZcbiAgICogQHBhcmFtIGNvbnRleHQge09iamVjdH0gLSBBbiBvYmplY3Qgd2hpY2ggd2lsbCBiZSB0aGUgdmFsdWUgb2YgYHRoaXNgIGluc2lkZSBgY2FsbGJhY2tgXG4gICAqIEBzdW1tYXJ5IENhbGwgYGNhbGxiYWNrYCBvbmNlIGZvciBlYWNoIG1hdGNoaW5nIGRvY3VtZW50LCBzZXF1ZW50aWFsbHkgYW5kIHN5bmNocm9ub3VzbHkuXG4gICAqIEByZXR1cm5zIHt1bmRlZmluZWR9XG4gICAqL1xuICBmb3JFYWNoKGNhbGxiYWNrLCBjb250ZXh0ID0ge30pIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVzQ3Vyc29yXSBbZm9yRWFjaCgpXScpO1xuICAgIHRoaXMuY3Vyc29yLmZvckVhY2goY2FsbGJhY2ssIGNvbnRleHQpO1xuICB9XG5cbiAgLypcbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZW1iZXJPZiBGaWxlc0N1cnNvclxuICAgKiBAbmFtZSBlYWNoXG4gICAqIEBzdW1tYXJ5IFJldHVybnMgYW4gQXJyYXkgb2YgRmlsZUN1cnNvciBtYWRlIGZvciBlYWNoIGRvY3VtZW50IG9uIGN1cnJlbnQgY3Vyc29yXG4gICAqICAgICAgICAgIFVzZWZ1bCB3aGVuIHVzaW5nIGluIHt7I2VhY2ggRmlsZXNDdXJzb3IjZWFjaH19Li4ue3svZWFjaH19IGJsb2NrIHRlbXBsYXRlIGhlbHBlclxuICAgKiBAcmV0dXJucyB7W0ZpbGVDdXJzb3JdfVxuICAgKi9cbiAgZWFjaCgpIHtcbiAgICByZXR1cm4gdGhpcy5tYXAoKGZpbGUpID0+IHtcbiAgICAgIHJldHVybiBuZXcgRmlsZUN1cnNvcihmaWxlLCB0aGlzLl9jb2xsZWN0aW9uKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgbWFwXG4gICAqIEBwYXJhbSBjYWxsYmFjayB7RnVuY3Rpb259IC0gRnVuY3Rpb24gdG8gY2FsbC4gSXQgd2lsbCBiZSBjYWxsZWQgd2l0aCB0aHJlZSBhcmd1bWVudHM6IHRoZSBgZmlsZWAsIGEgMC1iYXNlZCBpbmRleCwgYW5kIGN1cnNvciBpdHNlbGZcbiAgICogQHBhcmFtIGNvbnRleHQge09iamVjdH0gLSBBbiBvYmplY3Qgd2hpY2ggd2lsbCBiZSB0aGUgdmFsdWUgb2YgYHRoaXNgIGluc2lkZSBgY2FsbGJhY2tgXG4gICAqIEBzdW1tYXJ5IE1hcCBgY2FsbGJhY2tgIG92ZXIgYWxsIG1hdGNoaW5nIGRvY3VtZW50cy4gUmV0dXJucyBhbiBBcnJheS5cbiAgICogQHJldHVybnMge0FycmF5fVxuICAgKi9cbiAgbWFwKGNhbGxiYWNrLCBjb250ZXh0ID0ge30pIHtcbiAgICB0aGlzLl9jb2xsZWN0aW9uLl9kZWJ1ZygnW0ZpbGVzQ29sbGVjdGlvbl0gW0ZpbGVzQ3Vyc29yXSBbbWFwKCldJyk7XG4gICAgcmV0dXJuIHRoaXMuY3Vyc29yLm1hcChjYWxsYmFjaywgY29udGV4dCk7XG4gIH1cblxuICAvKlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIEZpbGVzQ3Vyc29yXG4gICAqIEBuYW1lIGN1cnJlbnRcbiAgICogQHN1bW1hcnkgUmV0dXJucyBjdXJyZW50IGl0ZW0gb24gQ3Vyc29yLCBpZiBhdmFpbGFibGVcbiAgICogQHJldHVybnMge09iamVjdHx1bmRlZmluZWR9XG4gICAqL1xuICBjdXJyZW50KCkge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtjdXJyZW50KCldJyk7XG4gICAgaWYgKHRoaXMuX2N1cnJlbnQgPCAwKSB7XG4gICAgICB0aGlzLl9jdXJyZW50ID0gMDtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZmV0Y2goKVt0aGlzLl9jdXJyZW50XTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgb2JzZXJ2ZVxuICAgKiBAcGFyYW0gY2FsbGJhY2tzIHtPYmplY3R9IC0gRnVuY3Rpb25zIHRvIGNhbGwgdG8gZGVsaXZlciB0aGUgcmVzdWx0IHNldCBhcyBpdCBjaGFuZ2VzXG4gICAqIEBzdW1tYXJ5IFdhdGNoIGEgcXVlcnkuIFJlY2VpdmUgY2FsbGJhY2tzIGFzIHRoZSByZXN1bHQgc2V0IGNoYW5nZXMuXG4gICAqIEB1cmwgaHR0cDovL2RvY3MubWV0ZW9yLmNvbS9hcGkvY29sbGVjdGlvbnMuaHRtbCNNb25nby1DdXJzb3Itb2JzZXJ2ZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSAtIGxpdmUgcXVlcnkgaGFuZGxlXG4gICAqL1xuICBvYnNlcnZlKGNhbGxiYWNrcykge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtvYnNlcnZlKCldJyk7XG4gICAgcmV0dXJuIHRoaXMuY3Vyc29yLm9ic2VydmUoY2FsbGJhY2tzKTtcbiAgfVxuXG4gIC8qXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWVtYmVyT2YgRmlsZXNDdXJzb3JcbiAgICogQG5hbWUgb2JzZXJ2ZUNoYW5nZXNcbiAgICogQHBhcmFtIGNhbGxiYWNrcyB7T2JqZWN0fSAtIEZ1bmN0aW9ucyB0byBjYWxsIHRvIGRlbGl2ZXIgdGhlIHJlc3VsdCBzZXQgYXMgaXQgY2hhbmdlc1xuICAgKiBAc3VtbWFyeSBXYXRjaCBhIHF1ZXJ5LiBSZWNlaXZlIGNhbGxiYWNrcyBhcyB0aGUgcmVzdWx0IHNldCBjaGFuZ2VzLiBPbmx5IHRoZSBkaWZmZXJlbmNlcyBiZXR3ZWVuIHRoZSBvbGQgYW5kIG5ldyBkb2N1bWVudHMgYXJlIHBhc3NlZCB0byB0aGUgY2FsbGJhY2tzLlxuICAgKiBAdXJsIGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vYXBpL2NvbGxlY3Rpb25zLmh0bWwjTW9uZ28tQ3Vyc29yLW9ic2VydmVDaGFuZ2VzXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IC0gbGl2ZSBxdWVyeSBoYW5kbGVcbiAgICovXG4gIG9ic2VydmVDaGFuZ2VzKGNhbGxiYWNrcykge1xuICAgIHRoaXMuX2NvbGxlY3Rpb24uX2RlYnVnKCdbRmlsZXNDb2xsZWN0aW9uXSBbRmlsZXNDdXJzb3JdIFtvYnNlcnZlQ2hhbmdlcygpXScpO1xuICAgIHJldHVybiB0aGlzLmN1cnNvci5vYnNlcnZlQ2hhbmdlcyhjYWxsYmFja3MpO1xuICB9XG59XG4iLCJpbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5cbmNvbnN0IGhlbHBlcnMgPSB7XG4gIGlzVW5kZWZpbmVkKG9iaikge1xuICAgIHJldHVybiBvYmogPT09IHZvaWQgMDtcbiAgfSxcbiAgaXNPYmplY3Qob2JqKSB7XG4gICAgaWYgKHRoaXMuaXNBcnJheShvYmopIHx8IHRoaXMuaXNGdW5jdGlvbihvYmopKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiBvYmogPT09IE9iamVjdChvYmopO1xuICB9LFxuICBpc0FycmF5KG9iaikge1xuICAgIHJldHVybiBBcnJheS5pc0FycmF5KG9iaik7XG4gIH0sXG4gIGlzQm9vbGVhbihvYmopIHtcbiAgICByZXR1cm4gb2JqID09PSB0cnVlIHx8IG9iaiA9PT0gZmFsc2UgfHwgT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9iaikgPT09ICdbb2JqZWN0IEJvb2xlYW5dJztcbiAgfSxcbiAgaXNGdW5jdGlvbihvYmopIHtcbiAgICByZXR1cm4gdHlwZW9mIG9iaiA9PT0gJ2Z1bmN0aW9uJyB8fCBmYWxzZTtcbiAgfSxcbiAgaXNFbXB0eShvYmopIHtcbiAgICBpZiAodGhpcy5pc0RhdGUob2JqKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAodGhpcy5pc09iamVjdChvYmopKSB7XG4gICAgICByZXR1cm4gIU9iamVjdC5rZXlzKG9iaikubGVuZ3RoO1xuICAgIH1cbiAgICBpZiAodGhpcy5pc0FycmF5KG9iaikgfHwgdGhpcy5pc1N0cmluZyhvYmopKSB7XG4gICAgICByZXR1cm4gIW9iai5sZW5ndGg7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfSxcbiAgY2xvbmUob2JqKSB7XG4gICAgaWYgKCF0aGlzLmlzT2JqZWN0KG9iaikpIHJldHVybiBvYmo7XG4gICAgcmV0dXJuIHRoaXMuaXNBcnJheShvYmopID8gb2JqLnNsaWNlKCkgOiBPYmplY3QuYXNzaWduKHt9LCBvYmopO1xuICB9LFxuICBoYXMoX29iaiwgcGF0aCkge1xuICAgIGxldCBvYmogPSBfb2JqO1xuICAgIGlmICghdGhpcy5pc09iamVjdChvYmopKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICghdGhpcy5pc0FycmF5KHBhdGgpKSB7XG4gICAgICByZXR1cm4gdGhpcy5pc09iamVjdChvYmopICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHBhdGgpO1xuICAgIH1cblxuICAgIGNvbnN0IGxlbmd0aCA9IHBhdGgubGVuZ3RoO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmICghT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcGF0aFtpXSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgb2JqID0gb2JqW3BhdGhbaV1dO1xuICAgIH1cbiAgICByZXR1cm4gISFsZW5ndGg7XG4gIH0sXG4gIG9taXQob2JqLCAuLi5rZXlzKSB7XG4gICAgY29uc3QgY2xlYXIgPSBPYmplY3QuYXNzaWduKHt9LCBvYmopO1xuICAgIGZvciAobGV0IGkgPSBrZXlzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICBkZWxldGUgY2xlYXJba2V5c1tpXV07XG4gICAgfVxuXG4gICAgcmV0dXJuIGNsZWFyO1xuICB9LFxuICBub3c6IERhdGUubm93LFxuICB0aHJvdHRsZShmdW5jLCB3YWl0LCBvcHRpb25zID0ge30pIHtcbiAgICBsZXQgcHJldmlvdXMgPSAwO1xuICAgIGxldCB0aW1lb3V0ID0gbnVsbDtcbiAgICBsZXQgcmVzdWx0O1xuICAgIGNvbnN0IHRoYXQgPSB0aGlzO1xuICAgIGxldCBzZWxmO1xuICAgIGxldCBhcmdzO1xuXG4gICAgY29uc3QgbGF0ZXIgPSAoKSA9PiB7XG4gICAgICBwcmV2aW91cyA9IG9wdGlvbnMubGVhZGluZyA9PT0gZmFsc2UgPyAwIDogdGhhdC5ub3coKTtcbiAgICAgIHRpbWVvdXQgPSBudWxsO1xuICAgICAgcmVzdWx0ID0gZnVuYy5hcHBseShzZWxmLCBhcmdzKTtcbiAgICAgIGlmICghdGltZW91dCkge1xuICAgICAgICBzZWxmID0gYXJncyA9IG51bGw7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IHRocm90dGxlZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgIGNvbnN0IG5vdyA9IHRoYXQubm93KCk7XG4gICAgICBpZiAoIXByZXZpb3VzICYmIG9wdGlvbnMubGVhZGluZyA9PT0gZmFsc2UpIHByZXZpb3VzID0gbm93O1xuICAgICAgY29uc3QgcmVtYWluaW5nID0gd2FpdCAtIChub3cgLSBwcmV2aW91cyk7XG4gICAgICBzZWxmID0gdGhpcztcbiAgICAgIGFyZ3MgPSBhcmd1bWVudHM7XG4gICAgICBpZiAocmVtYWluaW5nIDw9IDAgfHwgcmVtYWluaW5nID4gd2FpdCkge1xuICAgICAgICBpZiAodGltZW91dCkge1xuICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcbiAgICAgICAgICB0aW1lb3V0ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBwcmV2aW91cyA9IG5vdztcbiAgICAgICAgcmVzdWx0ID0gZnVuYy5hcHBseShzZWxmLCBhcmdzKTtcbiAgICAgICAgaWYgKCF0aW1lb3V0KSB7XG4gICAgICAgICAgc2VsZiA9IGFyZ3MgPSBudWxsO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKCF0aW1lb3V0ICYmIG9wdGlvbnMudHJhaWxpbmcgIT09IGZhbHNlKSB7XG4gICAgICAgIHRpbWVvdXQgPSBzZXRUaW1lb3V0KGxhdGVyLCByZW1haW5pbmcpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9O1xuXG4gICAgdGhyb3R0bGVkLmNhbmNlbCA9ICgpID0+IHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcbiAgICAgIHByZXZpb3VzID0gMDtcbiAgICAgIHRpbWVvdXQgPSBzZWxmID0gYXJncyA9IG51bGw7XG4gICAgfTtcblxuICAgIHJldHVybiB0aHJvdHRsZWQ7XG4gIH1cbn07XG5cbmNvbnN0IF9oZWxwZXJzID0gWydTdHJpbmcnLCAnTnVtYmVyJywgJ0RhdGUnXTtcbmZvciAobGV0IGkgPSAwOyBpIDwgX2hlbHBlcnMubGVuZ3RoOyBpKyspIHtcbiAgaGVscGVyc1snaXMnICsgX2hlbHBlcnNbaV1dID0gZnVuY3Rpb24gKG9iaikge1xuICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwob2JqKSA9PT0gJ1tvYmplY3QgJyArIF9oZWxwZXJzW2ldICsgJ10nO1xuICB9O1xufVxuXG4vKlxuICogQGNvbnN0IHtGdW5jdGlvbn0gZml4SlNPTlBhcnNlIC0gRml4IGlzc3VlIHdpdGggRGF0ZSBwYXJzZVxuICovXG5jb25zdCBmaXhKU09OUGFyc2UgPSBmdW5jdGlvbihvYmopIHtcbiAgZm9yIChsZXQga2V5IGluIG9iaikge1xuICAgIGlmIChoZWxwZXJzLmlzU3RyaW5nKG9ialtrZXldKSAmJiBvYmpba2V5XS5pbmNsdWRlcygnPS0tSlNPTi1EQVRFLS09JykpIHtcbiAgICAgIG9ialtrZXldID0gb2JqW2tleV0ucmVwbGFjZSgnPS0tSlNPTi1EQVRFLS09JywgJycpO1xuICAgICAgb2JqW2tleV0gPSBuZXcgRGF0ZShwYXJzZUludChvYmpba2V5XSkpO1xuICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc09iamVjdChvYmpba2V5XSkpIHtcbiAgICAgIG9ialtrZXldID0gZml4SlNPTlBhcnNlKG9ialtrZXldKTtcbiAgICB9IGVsc2UgaWYgKGhlbHBlcnMuaXNBcnJheShvYmpba2V5XSkpIHtcbiAgICAgIGxldCB2O1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBvYmpba2V5XS5sZW5ndGg7IGkrKykge1xuICAgICAgICB2ID0gb2JqW2tleV1baV07XG4gICAgICAgIGlmIChoZWxwZXJzLmlzT2JqZWN0KHYpKSB7XG4gICAgICAgICAgb2JqW2tleV1baV0gPSBmaXhKU09OUGFyc2Uodik7XG4gICAgICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc1N0cmluZyh2KSAmJiB2LmluY2x1ZGVzKCc9LS1KU09OLURBVEUtLT0nKSkge1xuICAgICAgICAgIHYgPSB2LnJlcGxhY2UoJz0tLUpTT04tREFURS0tPScsICcnKTtcbiAgICAgICAgICBvYmpba2V5XVtpXSA9IG5ldyBEYXRlKHBhcnNlSW50KHYpKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gb2JqO1xufTtcblxuLypcbiAqIEBjb25zdCB7RnVuY3Rpb259IGZpeEpTT05TdHJpbmdpZnkgLSBGaXggaXNzdWUgd2l0aCBEYXRlIHN0cmluZ2lmeVxuICovXG5jb25zdCBmaXhKU09OU3RyaW5naWZ5ID0gZnVuY3Rpb24ob2JqKSB7XG4gIGZvciAobGV0IGtleSBpbiBvYmopIHtcbiAgICBpZiAoaGVscGVycy5pc0RhdGUob2JqW2tleV0pKSB7XG4gICAgICBvYmpba2V5XSA9IGA9LS1KU09OLURBVEUtLT0keytvYmpba2V5XX1gO1xuICAgIH0gZWxzZSBpZiAoaGVscGVycy5pc09iamVjdChvYmpba2V5XSkpIHtcbiAgICAgIG9ialtrZXldID0gZml4SlNPTlN0cmluZ2lmeShvYmpba2V5XSk7XG4gICAgfSBlbHNlIGlmIChoZWxwZXJzLmlzQXJyYXkob2JqW2tleV0pKSB7XG4gICAgICBsZXQgdjtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb2JqW2tleV0ubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdiA9IG9ialtrZXldW2ldO1xuICAgICAgICBpZiAoaGVscGVycy5pc09iamVjdCh2KSkge1xuICAgICAgICAgIG9ialtrZXldW2ldID0gZml4SlNPTlN0cmluZ2lmeSh2KTtcbiAgICAgICAgfSBlbHNlIGlmIChoZWxwZXJzLmlzRGF0ZSh2KSkge1xuICAgICAgICAgIG9ialtrZXldW2ldID0gYD0tLUpTT04tREFURS0tPSR7K3Z9YDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gb2JqO1xufTtcblxuLypcbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQHByaXZhdGVcbiAqIEBuYW1lIGZvcm1hdEZsZVVSTFxuICogQHBhcmFtIHtPYmplY3R9IGZpbGVSZWYgLSBGaWxlIHJlZmVyZW5jZSBvYmplY3RcbiAqIEBwYXJhbSB7U3RyaW5nfSB2ZXJzaW9uIC0gW09wdGlvbmFsXSBWZXJzaW9uIG9mIGZpbGUgeW91IHdvdWxkIGxpa2UgYnVpbGQgVVJMIGZvclxuICogQHBhcmFtIHtTdHJpbmd9IFVSSUJhc2UgLSBbT3B0aW9uYWxdIFVSSSBiYXNlLCBzZWUgLSBodHRwczovL2dpdGh1Yi5jb20vVmVsaW92R3JvdXAvTWV0ZW9yLUZpbGVzL2lzc3Vlcy82MjZcbiAqIEBzdW1tYXJ5IFJldHVybnMgZm9ybWF0dGVkIFVSTCBmb3IgZmlsZVxuICogQHJldHVybnMge1N0cmluZ30gRG93bmxvYWRhYmxlIGxpbmtcbiAqL1xuY29uc3QgZm9ybWF0RmxlVVJMID0gKGZpbGVSZWYsIHZlcnNpb24gPSAnb3JpZ2luYWwnLCBfVVJJQmFzZSA9IChfX21ldGVvcl9ydW50aW1lX2NvbmZpZ19fIHx8IHt9KS5ST09UX1VSTCkgPT4ge1xuICBjaGVjayhmaWxlUmVmLCBPYmplY3QpO1xuICBjaGVjayh2ZXJzaW9uLCBTdHJpbmcpO1xuICBsZXQgVVJJQmFzZSA9IF9VUklCYXNlO1xuXG4gIGlmICghaGVscGVycy5pc1N0cmluZyhVUklCYXNlKSkge1xuICAgIFVSSUJhc2UgPSAoX19tZXRlb3JfcnVudGltZV9jb25maWdfXyB8fCB7fSkuUk9PVF9VUkwgfHwgJy8nO1xuICB9XG5cbiAgY29uc3QgX3Jvb3QgPSBVUklCYXNlLnJlcGxhY2UoL1xcLyskLywgJycpO1xuICBjb25zdCB2UmVmID0gKGZpbGVSZWYudmVyc2lvbnMgJiYgZmlsZVJlZi52ZXJzaW9uc1t2ZXJzaW9uXSkgfHwgZmlsZVJlZiB8fCB7fTtcblxuICBsZXQgZXh0O1xuICBpZiAoaGVscGVycy5pc1N0cmluZyh2UmVmLmV4dGVuc2lvbikpIHtcbiAgICBleHQgPSBgLiR7dlJlZi5leHRlbnNpb24ucmVwbGFjZSgvXlxcLi8sICcnKX1gO1xuICB9IGVsc2Uge1xuICAgIGV4dCA9ICcnO1xuICB9XG5cbiAgaWYgKGZpbGVSZWYucHVibGljID09PSB0cnVlKSB7XG4gICAgcmV0dXJuIF9yb290ICsgKHZlcnNpb24gPT09ICdvcmlnaW5hbCcgPyBgJHtmaWxlUmVmLl9kb3dubG9hZFJvdXRlfS8ke2ZpbGVSZWYuX2lkfSR7ZXh0fWAgOiBgJHtmaWxlUmVmLl9kb3dubG9hZFJvdXRlfS8ke3ZlcnNpb259LSR7ZmlsZVJlZi5faWR9JHtleHR9YCk7XG4gIH1cbiAgcmV0dXJuIGAke19yb290fSR7ZmlsZVJlZi5fZG93bmxvYWRSb3V0ZX0vJHtmaWxlUmVmLl9jb2xsZWN0aW9uTmFtZX0vJHtmaWxlUmVmLl9pZH0vJHt2ZXJzaW9ufS8ke2ZpbGVSZWYuX2lkfSR7ZXh0fWA7XG59O1xuXG5leHBvcnQgeyBmaXhKU09OUGFyc2UsIGZpeEpTT05TdHJpbmdpZnksIGZvcm1hdEZsZVVSTCwgaGVscGVycyB9O1xuIiwiaW1wb3J0IGZzICAgICAgICAgIGZyb20gJ2ZzLWV4dHJhJztcbmltcG9ydCB7IE1ldGVvciB9ICBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGhlbHBlcnMgfSBmcm9tICcuL2xpYi5qcyc7XG5jb25zdCBOT09QID0gKCkgPT4ge307XG5cbi8qXG4gKiBAY29uc3Qge09iamVjdH0gYm91bmQgICAtIE1ldGVvci5iaW5kRW52aXJvbm1lbnQgKEZpYmVyIHdyYXBwZXIpXG4gKiBAY29uc3Qge09iamVjdH0gZmRDYWNoZSAtIEZpbGUgRGVzY3JpcHRvcnMgQ2FjaGVcbiAqL1xuY29uc3QgYm91bmQgICA9IE1ldGVvci5iaW5kRW52aXJvbm1lbnQoY2FsbGJhY2sgPT4gY2FsbGJhY2soKSk7XG5jb25zdCBmZENhY2hlID0ge307XG5cbi8qXG4gKiBAcHJpdmF0ZVxuICogQGxvY3VzIFNlcnZlclxuICogQGNsYXNzIFdyaXRlU3RyZWFtXG4gKiBAcGFyYW0gcGF0aCAgICAgICAge1N0cmluZ30gLSBQYXRoIHRvIGZpbGUgb24gRlNcbiAqIEBwYXJhbSBtYXhMZW5ndGggICB7TnVtYmVyfSAtIE1heCBhbW91bnQgb2YgY2h1bmtzIGluIHN0cmVhbVxuICogQHBhcmFtIGZpbGUgICAgICAgIHtPYmplY3R9IC0gZmlsZVJlZiBPYmplY3RcbiAqIEBwYXJhbSBwZXJtaXNzaW9ucyB7U3RyaW5nfSAtIFBlcm1pc3Npb25zIHdoaWNoIHdpbGwgYmUgc2V0IHRvIG9wZW4gZGVzY3JpcHRvciAob2N0YWwpLCBsaWtlOiBgNjExYCBvciBgMG83NzdgLiBEZWZhdWx0OiAwNzU1XG4gKiBAc3VtbWFyeSB3cml0YWJsZVN0cmVhbSB3cmFwcGVyIGNsYXNzLCBtYWtlcyBzdXJlIGNodW5rcyBpcyB3cml0dGVuIGluIGdpdmVuIG9yZGVyLiBJbXBsZW1lbnRhdGlvbiBvZiBxdWV1ZSBzdHJlYW0uXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFdyaXRlU3RyZWFtIHtcbiAgY29uc3RydWN0b3IocGF0aCwgbWF4TGVuZ3RoLCBmaWxlLCBwZXJtaXNzaW9ucykge1xuICAgIHRoaXMucGF0aCA9IHBhdGg7XG4gICAgdGhpcy5tYXhMZW5ndGggPSBtYXhMZW5ndGg7XG4gICAgdGhpcy5maWxlID0gZmlsZTtcbiAgICB0aGlzLnBlcm1pc3Npb25zID0gcGVybWlzc2lvbnM7XG4gICAgaWYgKCF0aGlzLnBhdGggfHwgIWhlbHBlcnMuaXNTdHJpbmcodGhpcy5wYXRoKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMuZmQgICAgICAgICAgICA9IG51bGw7XG4gICAgdGhpcy53cml0dGVuQ2h1bmtzID0gMDtcbiAgICB0aGlzLmVuZGVkICAgICAgICAgPSBmYWxzZTtcbiAgICB0aGlzLmFib3J0ZWQgICAgICAgPSBmYWxzZTtcblxuICAgIGlmIChmZENhY2hlW3RoaXMucGF0aF0gJiYgIWZkQ2FjaGVbdGhpcy5wYXRoXS5lbmRlZCAmJiAhZmRDYWNoZVt0aGlzLnBhdGhdLmFib3J0ZWQpIHtcbiAgICAgIHRoaXMuZmQgPSBmZENhY2hlW3RoaXMucGF0aF0uZmQ7XG4gICAgICB0aGlzLndyaXR0ZW5DaHVua3MgPSBmZENhY2hlW3RoaXMucGF0aF0ud3JpdHRlbkNodW5rcztcbiAgICB9IGVsc2Uge1xuICAgICAgZnMuZW5zdXJlRmlsZSh0aGlzLnBhdGgsIChlZkVycm9yKSA9PiB7XG4gICAgICAgIGJvdW5kKCgpID0+IHtcbiAgICAgICAgICBpZiAoZWZFcnJvcikge1xuICAgICAgICAgICAgdGhpcy5hYm9ydCgpO1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsICdbRmlsZXNDb2xsZWN0aW9uXSBbd3JpdGVTdHJlYW1dIFtlbnN1cmVGaWxlXSBbRXJyb3I6XSAnICsgZWZFcnJvcik7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGZzLm9wZW4odGhpcy5wYXRoLCAncisnLCB0aGlzLnBlcm1pc3Npb25zLCAob0Vycm9yLCBmZCkgPT4ge1xuICAgICAgICAgICAgICBib3VuZCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKG9FcnJvcikge1xuICAgICAgICAgICAgICAgICAgdGhpcy5hYm9ydCgpO1xuICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig1MDAsICdbRmlsZXNDb2xsZWN0aW9uXSBbd3JpdGVTdHJlYW1dIFtlbnN1cmVGaWxlXSBbb3Blbl0gW0Vycm9yOl0gJyArIG9FcnJvcik7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIHRoaXMuZmQgPSBmZDtcbiAgICAgICAgICAgICAgICAgIGZkQ2FjaGVbdGhpcy5wYXRoXSA9IHRoaXM7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICAvKlxuICAgKiBAbWVtYmVyT2Ygd3JpdGVTdHJlYW1cbiAgICogQG5hbWUgd3JpdGVcbiAgICogQHBhcmFtIHtOdW1iZXJ9IG51bSAtIENodW5rIHBvc2l0aW9uIGluIGEgc3RyZWFtXG4gICAqIEBwYXJhbSB7QnVmZmVyfSBjaHVuayAtIEJ1ZmZlciAoY2h1bmsgYmluYXJ5IGRhdGEpXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrIC0gQ2FsbGJhY2tcbiAgICogQHN1bW1hcnkgV3JpdGUgY2h1bmsgaW4gZ2l2ZW4gb3JkZXJcbiAgICogQHJldHVybnMge0Jvb2xlYW59IC0gVHJ1ZSBpZiBjaHVuayBpcyBzZW50IHRvIHN0cmVhbSwgZmFsc2UgaWYgY2h1bmsgaXMgc2V0IGludG8gcXVldWVcbiAgICovXG4gIHdyaXRlKG51bSwgY2h1bmssIGNhbGxiYWNrKSB7XG4gICAgaWYgKCF0aGlzLmFib3J0ZWQgJiYgIXRoaXMuZW5kZWQpIHtcbiAgICAgIGlmICh0aGlzLmZkKSB7XG4gICAgICAgIGZzLndyaXRlKHRoaXMuZmQsIGNodW5rLCAwLCBjaHVuay5sZW5ndGgsIChudW0gLSAxKSAqIHRoaXMuZmlsZS5jaHVua1NpemUsIChlcnJvciwgd3JpdHRlbiwgYnVmZmVyKSA9PiB7XG4gICAgICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICAgICAgY2FsbGJhY2sgJiYgY2FsbGJhY2soZXJyb3IsIHdyaXR0ZW4sIGJ1ZmZlcik7XG4gICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgY29uc29sZS53YXJuKCdbRmlsZXNDb2xsZWN0aW9uXSBbd3JpdGVTdHJlYW1dIFt3cml0ZV0gW0Vycm9yOl0nLCBlcnJvcik7XG4gICAgICAgICAgICAgIHRoaXMuYWJvcnQoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICsrdGhpcy53cml0dGVuQ2h1bmtzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIE1ldGVvci5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICB0aGlzLndyaXRlKG51bSwgY2h1bmssIGNhbGxiYWNrKTtcbiAgICAgICAgfSwgMjUpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICAvKlxuICAgKiBAbWVtYmVyT2Ygd3JpdGVTdHJlYW1cbiAgICogQG5hbWUgZW5kXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrIC0gQ2FsbGJhY2tcbiAgICogQHN1bW1hcnkgRmluaXNoZXMgd3JpdGluZyB0byB3cml0YWJsZVN0cmVhbSwgb25seSBhZnRlciBhbGwgY2h1bmtzIGluIHF1ZXVlIGlzIHdyaXR0ZW5cbiAgICogQHJldHVybnMge0Jvb2xlYW59IC0gVHJ1ZSBpZiBzdHJlYW0gaXMgZnVsZmlsbGVkLCBmYWxzZSBpZiBxdWV1ZSBpcyBpbiBwcm9ncmVzc1xuICAgKi9cbiAgZW5kKGNhbGxiYWNrKSB7XG4gICAgaWYgKCF0aGlzLmFib3J0ZWQgJiYgIXRoaXMuZW5kZWQpIHtcbiAgICAgIGlmICh0aGlzLndyaXR0ZW5DaHVua3MgPT09IHRoaXMubWF4TGVuZ3RoKSB7XG4gICAgICAgIGZzLmNsb3NlKHRoaXMuZmQsICgpID0+IHtcbiAgICAgICAgICBib3VuZCgoKSA9PiB7XG4gICAgICAgICAgICBkZWxldGUgZmRDYWNoZVt0aGlzLnBhdGhdO1xuICAgICAgICAgICAgdGhpcy5lbmRlZCA9IHRydWU7XG4gICAgICAgICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayh2b2lkIDAsIHRydWUpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG5cbiAgICAgIGZzLnN0YXQodGhpcy5wYXRoLCAoZXJyb3IsIHN0YXQpID0+IHtcbiAgICAgICAgYm91bmQoKCkgPT4ge1xuICAgICAgICAgIGlmICghZXJyb3IgJiYgc3RhdCkge1xuICAgICAgICAgICAgdGhpcy53cml0dGVuQ2h1bmtzID0gTWF0aC5jZWlsKHN0YXQuc2l6ZSAvIHRoaXMuZmlsZS5jaHVua1NpemUpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBNZXRlb3Iuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmVuZChjYWxsYmFjayk7XG4gICAgICAgICAgfSwgMjUpO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBjYWxsYmFjayAmJiBjYWxsYmFjayh2b2lkIDAsIHRoaXMuZW5kZWQpO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICAvKlxuICAgKiBAbWVtYmVyT2Ygd3JpdGVTdHJlYW1cbiAgICogQG5hbWUgYWJvcnRcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgLSBDYWxsYmFja1xuICAgKiBAc3VtbWFyeSBBYm9ydHMgd3JpdGluZyB0byB3cml0YWJsZVN0cmVhbSwgcmVtb3ZlcyBjcmVhdGVkIGZpbGVcbiAgICogQHJldHVybnMge0Jvb2xlYW59IC0gVHJ1ZVxuICAgKi9cbiAgYWJvcnQoY2FsbGJhY2spIHtcbiAgICB0aGlzLmFib3J0ZWQgPSB0cnVlO1xuICAgIGRlbGV0ZSBmZENhY2hlW3RoaXMucGF0aF07XG4gICAgZnMudW5saW5rKHRoaXMucGF0aCwgKGNhbGxiYWNrIHx8IE5PT1ApKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIC8qXG4gICAqIEBtZW1iZXJPZiB3cml0ZVN0cmVhbVxuICAgKiBAbmFtZSBzdG9wXG4gICAqIEBzdW1tYXJ5IFN0b3Agd3JpdGluZyB0byB3cml0YWJsZVN0cmVhbVxuICAgKiBAcmV0dXJucyB7Qm9vbGVhbn0gLSBUcnVlXG4gICAqL1xuICBzdG9wKCkge1xuICAgIHRoaXMuYWJvcnRlZCA9IHRydWU7XG4gICAgZGVsZXRlIGZkQ2FjaGVbdGhpcy5wYXRoXTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufVxuIl19
