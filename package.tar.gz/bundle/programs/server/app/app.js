var require = meteorInstall({"imports":{"api":{"CategoriesMethods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/CategoriesMethods.js                                                                //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let check, Match;
module.link("meteor/check", {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 0);
let CategoriesCollection;
module.link("/imports/db/CategoriesCollection", {
  CategoriesCollection(v) {
    CategoriesCollection = v;
  }

}, 1);
let slug;
module.link("slug", {
  default(v) {
    slug = v;
  }

}, 2);
Meteor.methods({
  'categories.insert'(category) {
    console.log('==>', category.name); // check(name, String);
    // check(category.keyword, Match.Maybe(String));
    // check(category.description, String);
    // check(category.icon, String);

    if (!this.userId) {
      throw new Meteor.Error('Not authorized');
    }

    return CategoriesCollection.insert({
      name: category.name,
      slug: slug(category.name),
      description: category.description,
      icon: category.icon,
      keyword: category.keyword,
      userId: this.userId,
      createAt: Date.now()
    }, function (error, result) {
      console.log(error, result);
      return result;
    });
  },

  'categories.getall'() {
    console.log('vao roi');
    return CategoriesCollection.find({}).fetch();
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"CategoriesPublications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/CategoriesPublications.js                                                           //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CategoriesCollection;
module.link("/imports/db/CategoriesCollection", {
  CategoriesCollection(v) {
    CategoriesCollection = v;
  }

}, 1);
Meteor.publish('categories', function publishTasks() {
  return CategoriesCollection.find({});
});
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"PostsMethods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/PostsMethods.js                                                                     //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let check, Match;
module.link("meteor/check", {
  check(v) {
    check = v;
  },

  Match(v) {
    Match = v;
  }

}, 0);
let PostsCollection;
module.link("/imports/db/PostsCollection", {
  PostsCollection(v) {
    PostsCollection = v;
  }

}, 1);
Meteor.methods({
  'posts.insert'(post) {
    // console.log(post);
    check(post.post_title, String);
    check(post.post_description, Match.Maybe(String));
    check(post.post_images, Array);
    check(post.post_category, Array);
    check(post.post_type, String);
    check(post.cover_uid, String);

    if (!this.userId) {
      throw new Meteor.Error('Not authorized');
    }

    return PostsCollection.insert({
      title: post.post_title,
      description: post.post_description,
      images: post.post_images,
      category: post.post_category,
      type: post.post_type,
      cover_uid: post.cover_uid,
      userId: this.userId,
      like: 0,
      dislike: 0,
      share: 0,
      createAt: Date.now()
    }, function (error, result) {
      console.log(error, result);
      return result;
    });
  },

  'tasks.remove'(taskId) {
    check(taskId, String);

    if (!this.userId) {
      throw new Meteor.Error('Not authorized');
    }

    const task = TasksCollection.findOne({
      _id: taskId,
      userId: this.userId
    });

    if (!task) {
      throw new Meteor.Error('Access denied.');
    }

    TasksCollection.remove(taskId);
  },

  'tasks.setIsChecked'(taskId, isChecked) {
    check(taskId, String);
    check(isChecked, Boolean);

    if (!this.userId) {
      throw new Meteor.Error('Not authorized');
    }

    const task = TasksCollection.findOne({
      _id: taskId,
      userId: this.userId
    });

    if (!task) {
      throw new Meteor.Error('Access denied.');
    }

    TaskCollection.update(taskId, {
      $set: {
        isChecked
      }
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"PostsPublications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/PostsPublications.js                                                                //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let PostsCollection;
module.link("/imports/db/PostsCollection", {
  PostsCollection(v) {
    PostsCollection = v;
  }

}, 1);
Meteor.publish('posts', function publishTasks() {
  return PostsCollection.find({});
});
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"UploadShare.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/UploadShare.js                                                                      //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let FilesCollection;
module.link("meteor/ostrio:files", {
  FilesCollection(v) {
    FilesCollection = v;
  }

}, 1);
const Images = new FilesCollection({
  collectionName: 'Images',
  storagePath: '/Users/phamkha/Desktop/Meteor/images',
  allowClientCode: true,

  // Disallow remove files from Client
  onBeforeUpload(file) {
    if (this.userId) {
      const user = this.user(); // Allow upload files under 10MB, and only in png/jpg/jpeg formats

      if (file.size <= 10485760 && /png|jpg|jpeg/i.test(file.extension)) {
        return true;
      } else return 'Please upload image, with size equal or less than 10MB';
    } else {
      return 'You are not logged in';
    }
  },

  onBeforeRemove(cursor) {
    const records = cursor.fetch();

    if (records && records.length) {
      if (this.userId) {
        const user = this.user(); // Assuming user.profile.docs is array
        // with file's records _id(s)

        for (let i = 0, len = records.length; i < len; i++) {
          const file = records[i];

          if (file.userId !== user._id) {
            //kiểm tra xem phải chủ bức hình xoá không
            return false;
          }
        }
      }
    }

    return true;
  }

});
module.exportDefault(Images);

if (Meteor.isClient) {
  Meteor.subscribe('files.images.all');
}

if (Meteor.isServer) {
  Meteor.publish('files.images.all', function () {
    return Images.find().cursor;
  });
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"UsersMethods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/api/UsersMethods.js                                                                     //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
Meteor.methods({
  'users.Insert': function (data) {
    let prepare_data = {
      email: data.email,
      password: data.password,
      profile: {
        name: data.name,
        agreement: data.agreement
      }
    };
    return Accounts.createUser(prepare_data);
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////

}},"db":{"CategoriesCollection.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/db/CategoriesCollection.js                                                              //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({
  CategoriesCollection: () => CategoriesCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const CategoriesCollection = new Mongo.Collection('categories');
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"PostsCollection.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/db/PostsCollection.js                                                                   //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({
  PostsCollection: () => PostsCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const PostsCollection = new Mongo.Collection('posts');
/////////////////////////////////////////////////////////////////////////////////////////////////////

},"TaskCollection.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// imports/db/TaskCollection.js                                                                    //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
module.export({
  TaskCollection: () => TaskCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const TaskCollection = new Mongo.Collection('tasks');
/////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// server/main.js                                                                                  //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Accounts;
module.link("meteor/accounts-base", {
  Accounts(v) {
    Accounts = v;
  }

}, 1);
let PostsCollection;
module.link("/imports/db/PostsCollection", {
  PostsCollection(v) {
    PostsCollection = v;
  }

}, 2);
let TaskCollection;
module.link("/imports/db/TaskCollection", {
  TaskCollection(v) {
    TaskCollection = v;
  }

}, 3);
let bodyParser;
module.link("body-parser", {
  default(v) {
    bodyParser = v;
  }

}, 4);
module.link("/imports/api/PostsPublications");
module.link("/imports/api/PostsMethods");
module.link("/imports/api/UsersMethods");
module.link("/imports/api/UploadShare");
module.link("/imports/api/CategoriesMethods");
module.link("/imports/api/CategoriesPublications");
// const insertTask = (taskText, user) => {
//   TaskCollection.insert({
//     text: taskText,
//     userId: user._id,
//     createAt: new Date(),
//   })
// };
Meteor.startup(() => {
  WebApp.connectHandlers.use(bodyParser.urlencoded({
    extended: true
  }));
  WebApp.connectHandlers.use('/hello', (req, res, next) => {
    console.log(req.query);
    console.log(req.body);
    res.writeHead(200);
    res.end(JSON.stringify({
      hello: 123
    }));
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs",
    ".tsx",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvQ2F0ZWdvcmllc01ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL0NhdGVnb3JpZXNQdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1Bvc3RzTWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvUG9zdHNQdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL1VwbG9hZFNoYXJlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9Vc2Vyc01ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvZGIvQ2F0ZWdvcmllc0NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvZGIvUG9zdHNDb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2RiL1Rhc2tDb2xsZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyJdLCJuYW1lcyI6WyJjaGVjayIsIk1hdGNoIiwibW9kdWxlIiwibGluayIsInYiLCJDYXRlZ29yaWVzQ29sbGVjdGlvbiIsInNsdWciLCJkZWZhdWx0IiwiTWV0ZW9yIiwibWV0aG9kcyIsImNhdGVnb3J5IiwiY29uc29sZSIsImxvZyIsIm5hbWUiLCJ1c2VySWQiLCJFcnJvciIsImluc2VydCIsImRlc2NyaXB0aW9uIiwiaWNvbiIsImtleXdvcmQiLCJjcmVhdGVBdCIsIkRhdGUiLCJub3ciLCJlcnJvciIsInJlc3VsdCIsImZpbmQiLCJmZXRjaCIsInB1Ymxpc2giLCJwdWJsaXNoVGFza3MiLCJQb3N0c0NvbGxlY3Rpb24iLCJwb3N0IiwicG9zdF90aXRsZSIsIlN0cmluZyIsInBvc3RfZGVzY3JpcHRpb24iLCJNYXliZSIsInBvc3RfaW1hZ2VzIiwiQXJyYXkiLCJwb3N0X2NhdGVnb3J5IiwicG9zdF90eXBlIiwiY292ZXJfdWlkIiwidGl0bGUiLCJpbWFnZXMiLCJ0eXBlIiwibGlrZSIsImRpc2xpa2UiLCJzaGFyZSIsInRhc2tJZCIsInRhc2siLCJUYXNrc0NvbGxlY3Rpb24iLCJmaW5kT25lIiwiX2lkIiwicmVtb3ZlIiwiaXNDaGVja2VkIiwiQm9vbGVhbiIsIlRhc2tDb2xsZWN0aW9uIiwidXBkYXRlIiwiJHNldCIsIkZpbGVzQ29sbGVjdGlvbiIsIkltYWdlcyIsImNvbGxlY3Rpb25OYW1lIiwic3RvcmFnZVBhdGgiLCJhbGxvd0NsaWVudENvZGUiLCJvbkJlZm9yZVVwbG9hZCIsImZpbGUiLCJ1c2VyIiwic2l6ZSIsInRlc3QiLCJleHRlbnNpb24iLCJvbkJlZm9yZVJlbW92ZSIsImN1cnNvciIsInJlY29yZHMiLCJsZW5ndGgiLCJpIiwibGVuIiwiZXhwb3J0RGVmYXVsdCIsImlzQ2xpZW50Iiwic3Vic2NyaWJlIiwiaXNTZXJ2ZXIiLCJBY2NvdW50cyIsImRhdGEiLCJwcmVwYXJlX2RhdGEiLCJlbWFpbCIsInBhc3N3b3JkIiwicHJvZmlsZSIsImFncmVlbWVudCIsImNyZWF0ZVVzZXIiLCJleHBvcnQiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJib2R5UGFyc2VyIiwic3RhcnR1cCIsIldlYkFwcCIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsInVybGVuY29kZWQiLCJleHRlbmRlZCIsInJlcSIsInJlcyIsIm5leHQiLCJxdWVyeSIsImJvZHkiLCJ3cml0ZUhlYWQiLCJlbmQiLCJKU09OIiwic3RyaW5naWZ5IiwiaGVsbG8iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsS0FBSixFQUFVQyxLQUFWO0FBQWdCQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNILE9BQUssQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNKLFNBQUssR0FBQ0ksQ0FBTjtBQUFRLEdBQWxCOztBQUFtQkgsT0FBSyxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsU0FBSyxHQUFDRyxDQUFOO0FBQVE7O0FBQXBDLENBQTNCLEVBQWlFLENBQWpFO0FBQW9FLElBQUlDLG9CQUFKO0FBQXlCSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxrQ0FBWixFQUErQztBQUFDRSxzQkFBb0IsQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLHdCQUFvQixHQUFDRCxDQUFyQjtBQUF1Qjs7QUFBaEQsQ0FBL0MsRUFBaUcsQ0FBakc7QUFBb0csSUFBSUUsSUFBSjtBQUFTSixNQUFNLENBQUNDLElBQVAsQ0FBWSxNQUFaLEVBQW1CO0FBQUNJLFNBQU8sQ0FBQ0gsQ0FBRCxFQUFHO0FBQUNFLFFBQUksR0FBQ0YsQ0FBTDtBQUFPOztBQUFuQixDQUFuQixFQUF3QyxDQUF4QztBQUkxTkksTUFBTSxDQUFDQyxPQUFQLENBQWU7QUFDWCxzQkFBb0JDLFFBQXBCLEVBQThCO0FBQzFCQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaLEVBQW1CRixRQUFRLENBQUNHLElBQTVCLEVBRDBCLENBRTFCO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQUksQ0FBQyxLQUFLQyxNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJTixNQUFNLENBQUNPLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFDRCxXQUFPVixvQkFBb0IsQ0FBQ1csTUFBckIsQ0FBNEI7QUFDL0JILFVBQUksRUFBRUgsUUFBUSxDQUFDRyxJQURnQjtBQUUvQlAsVUFBSSxFQUFFQSxJQUFJLENBQUNJLFFBQVEsQ0FBQ0csSUFBVixDQUZxQjtBQUcvQkksaUJBQVcsRUFBRVAsUUFBUSxDQUFDTyxXQUhTO0FBSS9CQyxVQUFJLEVBQUVSLFFBQVEsQ0FBQ1EsSUFKZ0I7QUFLL0JDLGFBQU8sRUFBRVQsUUFBUSxDQUFDUyxPQUxhO0FBTS9CTCxZQUFNLEVBQUUsS0FBS0EsTUFOa0I7QUFPL0JNLGNBQVEsRUFBRUMsSUFBSSxDQUFDQyxHQUFMO0FBUHFCLEtBQTVCLEVBUUosVUFBVUMsS0FBVixFQUFpQkMsTUFBakIsRUFBeUI7QUFDeEJiLGFBQU8sQ0FBQ0MsR0FBUixDQUFZVyxLQUFaLEVBQW1CQyxNQUFuQjtBQUNBLGFBQU9BLE1BQVA7QUFDSCxLQVhNLENBQVA7QUFZSCxHQXRCVTs7QUF1Qlgsd0JBQXNCO0FBQ2xCYixXQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaO0FBQ0EsV0FBT1Asb0JBQW9CLENBQUNvQixJQUFyQixDQUEwQixFQUExQixFQUE4QkMsS0FBOUIsRUFBUDtBQUNIOztBQTFCVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSWxCLE1BQUo7QUFBV04sTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDSyxRQUFNLENBQUNKLENBQUQsRUFBRztBQUFDSSxVQUFNLEdBQUNKLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsb0JBQUo7QUFBeUJILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUNFLHNCQUFvQixDQUFDRCxDQUFELEVBQUc7QUFBQ0Msd0JBQW9CLEdBQUNELENBQXJCO0FBQXVCOztBQUFoRCxDQUEvQyxFQUFpRyxDQUFqRztBQUd6RkksTUFBTSxDQUFDbUIsT0FBUCxDQUFlLFlBQWYsRUFBNkIsU0FBU0MsWUFBVCxHQUF3QjtBQUNqRCxTQUFPdkIsb0JBQW9CLENBQUNvQixJQUFyQixDQUEwQixFQUExQixDQUFQO0FBQ0gsQ0FGRCxFOzs7Ozs7Ozs7OztBQ0hBLElBQUl6QixLQUFKLEVBQVVDLEtBQVY7QUFBZ0JDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0gsT0FBSyxDQUFDSSxDQUFELEVBQUc7QUFBQ0osU0FBSyxHQUFDSSxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CSCxPQUFLLENBQUNHLENBQUQsRUFBRztBQUFDSCxTQUFLLEdBQUNHLENBQU47QUFBUTs7QUFBcEMsQ0FBM0IsRUFBaUUsQ0FBakU7QUFBb0UsSUFBSXlCLGVBQUo7QUFBb0IzQixNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDMEIsaUJBQWUsQ0FBQ3pCLENBQUQsRUFBRztBQUFDeUIsbUJBQWUsR0FBQ3pCLENBQWhCO0FBQWtCOztBQUF0QyxDQUExQyxFQUFrRixDQUFsRjtBQUl4R0ksTUFBTSxDQUFDQyxPQUFQLENBQWU7QUFDWCxpQkFBZXFCLElBQWYsRUFBcUI7QUFDakI7QUFDQTlCLFNBQUssQ0FBQzhCLElBQUksQ0FBQ0MsVUFBTixFQUFrQkMsTUFBbEIsQ0FBTDtBQUNBaEMsU0FBSyxDQUFDOEIsSUFBSSxDQUFDRyxnQkFBTixFQUF3QmhDLEtBQUssQ0FBQ2lDLEtBQU4sQ0FBWUYsTUFBWixDQUF4QixDQUFMO0FBQ0FoQyxTQUFLLENBQUM4QixJQUFJLENBQUNLLFdBQU4sRUFBbUJDLEtBQW5CLENBQUw7QUFDQXBDLFNBQUssQ0FBQzhCLElBQUksQ0FBQ08sYUFBTixFQUFxQkQsS0FBckIsQ0FBTDtBQUNBcEMsU0FBSyxDQUFDOEIsSUFBSSxDQUFDUSxTQUFOLEVBQWlCTixNQUFqQixDQUFMO0FBQ0FoQyxTQUFLLENBQUM4QixJQUFJLENBQUNTLFNBQU4sRUFBaUJQLE1BQWpCLENBQUw7O0FBQ0EsUUFBSSxDQUFDLEtBQUtsQixNQUFWLEVBQWtCO0FBQ2QsWUFBTSxJQUFJTixNQUFNLENBQUNPLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFDRCxXQUFPYyxlQUFlLENBQUNiLE1BQWhCLENBQXVCO0FBQzFCd0IsV0FBSyxFQUFFVixJQUFJLENBQUNDLFVBRGM7QUFFMUJkLGlCQUFXLEVBQUVhLElBQUksQ0FBQ0csZ0JBRlE7QUFHMUJRLFlBQU0sRUFBRVgsSUFBSSxDQUFDSyxXQUhhO0FBSTFCekIsY0FBUSxFQUFFb0IsSUFBSSxDQUFDTyxhQUpXO0FBSzFCSyxVQUFJLEVBQUVaLElBQUksQ0FBQ1EsU0FMZTtBQU0xQkMsZUFBUyxFQUFFVCxJQUFJLENBQUNTLFNBTlU7QUFPMUJ6QixZQUFNLEVBQUUsS0FBS0EsTUFQYTtBQVExQjZCLFVBQUksRUFBRSxDQVJvQjtBQVMxQkMsYUFBTyxFQUFFLENBVGlCO0FBVTFCQyxXQUFLLEVBQUMsQ0FWb0I7QUFXMUJ6QixjQUFRLEVBQUVDLElBQUksQ0FBQ0MsR0FBTDtBQVhnQixLQUF2QixFQVlKLFVBQVVDLEtBQVYsRUFBaUJDLE1BQWpCLEVBQXlCO0FBQ3hCYixhQUFPLENBQUNDLEdBQVIsQ0FBWVcsS0FBWixFQUFtQkMsTUFBbkI7QUFDQSxhQUFPQSxNQUFQO0FBQ0gsS0FmTSxDQUFQO0FBZ0JILEdBNUJVOztBQTZCWCxpQkFBZXNCLE1BQWYsRUFBdUI7QUFDbkI5QyxTQUFLLENBQUM4QyxNQUFELEVBQVNkLE1BQVQsQ0FBTDs7QUFDQSxRQUFJLENBQUMsS0FBS2xCLE1BQVYsRUFBa0I7QUFDZCxZQUFNLElBQUlOLE1BQU0sQ0FBQ08sS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNELFVBQU1nQyxJQUFJLEdBQUdDLGVBQWUsQ0FBQ0MsT0FBaEIsQ0FBd0I7QUFBRUMsU0FBRyxFQUFFSixNQUFQO0FBQWVoQyxZQUFNLEVBQUUsS0FBS0E7QUFBNUIsS0FBeEIsQ0FBYjs7QUFDQSxRQUFJLENBQUNpQyxJQUFMLEVBQVc7QUFDUCxZQUFNLElBQUl2QyxNQUFNLENBQUNPLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFFRGlDLG1CQUFlLENBQUNHLE1BQWhCLENBQXVCTCxNQUF2QjtBQUNILEdBeENVOztBQXlDWCx1QkFBcUJBLE1BQXJCLEVBQTZCTSxTQUE3QixFQUF3QztBQUNwQ3BELFNBQUssQ0FBQzhDLE1BQUQsRUFBU2QsTUFBVCxDQUFMO0FBQ0FoQyxTQUFLLENBQUNvRCxTQUFELEVBQVlDLE9BQVosQ0FBTDs7QUFDQSxRQUFJLENBQUMsS0FBS3ZDLE1BQVYsRUFBa0I7QUFBRSxZQUFNLElBQUlOLE1BQU0sQ0FBQ08sS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUEyQzs7QUFDL0QsVUFBTWdDLElBQUksR0FBR0MsZUFBZSxDQUFDQyxPQUFoQixDQUF3QjtBQUFFQyxTQUFHLEVBQUVKLE1BQVA7QUFBZWhDLFlBQU0sRUFBRSxLQUFLQTtBQUE1QixLQUF4QixDQUFiOztBQUVBLFFBQUksQ0FBQ2lDLElBQUwsRUFBVztBQUNQLFlBQU0sSUFBSXZDLE1BQU0sQ0FBQ08sS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUNEdUMsa0JBQWMsQ0FBQ0MsTUFBZixDQUFzQlQsTUFBdEIsRUFBOEI7QUFDMUJVLFVBQUksRUFBRTtBQUNGSjtBQURFO0FBRG9CLEtBQTlCO0FBS0g7O0FBdkRVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJNUMsTUFBSjtBQUFXTixNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNLLFFBQU0sQ0FBQ0osQ0FBRCxFQUFHO0FBQUNJLFVBQU0sR0FBQ0osQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeUIsZUFBSjtBQUFvQjNCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUMwQixpQkFBZSxDQUFDekIsQ0FBRCxFQUFHO0FBQUN5QixtQkFBZSxHQUFDekIsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQTFDLEVBQWtGLENBQWxGO0FBR3BGSSxNQUFNLENBQUNtQixPQUFQLENBQWUsT0FBZixFQUF3QixTQUFTQyxZQUFULEdBQXdCO0FBQzVDLFNBQU9DLGVBQWUsQ0FBQ0osSUFBaEIsQ0FBcUIsRUFBckIsQ0FBUDtBQUNILENBRkQsRTs7Ozs7Ozs7Ozs7QUNIQSxJQUFJakIsTUFBSjtBQUFXTixNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNLLFFBQU0sQ0FBQ0osQ0FBRCxFQUFHO0FBQUNJLFVBQU0sR0FBQ0osQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJcUQsZUFBSjtBQUFvQnZELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNzRCxpQkFBZSxDQUFDckQsQ0FBRCxFQUFHO0FBQUNxRCxtQkFBZSxHQUFDckQsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQWxDLEVBQTBFLENBQTFFO0FBR3BGLE1BQU1zRCxNQUFNLEdBQUcsSUFBSUQsZUFBSixDQUFvQjtBQUMvQkUsZ0JBQWMsRUFBRSxRQURlO0FBRS9CQyxhQUFXLEVBQUUsc0NBRmtCO0FBRy9CQyxpQkFBZSxFQUFFLElBSGM7O0FBR1I7QUFDdkJDLGdCQUFjLENBQUNDLElBQUQsRUFBTztBQUVqQixRQUFJLEtBQUtqRCxNQUFULEVBQWlCO0FBQ2IsWUFBTWtELElBQUksR0FBRyxLQUFLQSxJQUFMLEVBQWIsQ0FEYSxDQUViOztBQUNBLFVBQUlELElBQUksQ0FBQ0UsSUFBTCxJQUFhLFFBQWIsSUFBeUIsZ0JBQWdCQyxJQUFoQixDQUFxQkgsSUFBSSxDQUFDSSxTQUExQixDQUE3QixFQUFtRTtBQUMvRCxlQUFPLElBQVA7QUFDSCxPQUZELE1BR0ssT0FBTyx3REFBUDtBQUNSLEtBUEQsTUFRSztBQUNELGFBQU8sdUJBQVA7QUFDSDtBQUVKLEdBbEI4Qjs7QUFtQi9CQyxnQkFBYyxDQUFDQyxNQUFELEVBQVM7QUFDbkIsVUFBTUMsT0FBTyxHQUFHRCxNQUFNLENBQUMzQyxLQUFQLEVBQWhCOztBQUVBLFFBQUk0QyxPQUFPLElBQUlBLE9BQU8sQ0FBQ0MsTUFBdkIsRUFBK0I7QUFDM0IsVUFBSSxLQUFLekQsTUFBVCxFQUFpQjtBQUNiLGNBQU1rRCxJQUFJLEdBQUcsS0FBS0EsSUFBTCxFQUFiLENBRGEsQ0FFYjtBQUNBOztBQUVBLGFBQUssSUFBSVEsQ0FBQyxHQUFHLENBQVIsRUFBV0MsR0FBRyxHQUFHSCxPQUFPLENBQUNDLE1BQTlCLEVBQXNDQyxDQUFDLEdBQUdDLEdBQTFDLEVBQStDRCxDQUFDLEVBQWhELEVBQW9EO0FBQ2hELGdCQUFNVCxJQUFJLEdBQUdPLE9BQU8sQ0FBQ0UsQ0FBRCxDQUFwQjs7QUFDQSxjQUFHVCxJQUFJLENBQUNqRCxNQUFMLEtBQWdCa0QsSUFBSSxDQUFDZCxHQUF4QixFQUNBO0FBQ0k7QUFDQSxtQkFBTyxLQUFQO0FBQ0g7QUFDSjtBQUNKO0FBQ0o7O0FBRUQsV0FBTyxJQUFQO0FBQ0g7O0FBeEM4QixDQUFwQixDQUFmO0FBSEFoRCxNQUFNLENBQUN3RSxhQUFQLENBNkNlaEIsTUE3Q2Y7O0FBOENBLElBQUlsRCxNQUFNLENBQUNtRSxRQUFYLEVBQXFCO0FBQ2pCbkUsUUFBTSxDQUFDb0UsU0FBUCxDQUFpQixrQkFBakI7QUFDSDs7QUFFRCxJQUFJcEUsTUFBTSxDQUFDcUUsUUFBWCxFQUFxQjtBQUNqQnJFLFFBQU0sQ0FBQ21CLE9BQVAsQ0FBZSxrQkFBZixFQUFtQyxZQUFZO0FBQzNDLFdBQU8rQixNQUFNLENBQUNqQyxJQUFQLEdBQWM0QyxNQUFyQjtBQUNILEdBRkQ7QUFHSCxDOzs7Ozs7Ozs7OztBQ3RERCxJQUFJckUsS0FBSjtBQUFVRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNILE9BQUssQ0FBQ0ksQ0FBRCxFQUFHO0FBQUNKLFNBQUssR0FBQ0ksQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJMEUsUUFBSjtBQUFhNUUsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQzJFLFVBQVEsQ0FBQzFFLENBQUQsRUFBRztBQUFDMEUsWUFBUSxHQUFDMUUsQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUl6RUksTUFBTSxDQUFDQyxPQUFQLENBQWU7QUFDWCxrQkFBZSxVQUFTc0UsSUFBVCxFQUFjO0FBQzNCLFFBQUlDLFlBQVksR0FBRztBQUNqQkMsV0FBSyxFQUFFRixJQUFJLENBQUNFLEtBREs7QUFFakJDLGNBQVEsRUFBRUgsSUFBSSxDQUFDRyxRQUZFO0FBR2pCQyxhQUFPLEVBQUM7QUFDTnRFLFlBQUksRUFBRWtFLElBQUksQ0FBQ2xFLElBREw7QUFFTnVFLGlCQUFTLEVBQUVMLElBQUksQ0FBQ0s7QUFGVjtBQUhTLEtBQW5CO0FBUUEsV0FBT04sUUFBUSxDQUFDTyxVQUFULENBQW9CTCxZQUFwQixDQUFQO0FBQ0Q7QUFYVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkE5RSxNQUFNLENBQUNvRixNQUFQLENBQWM7QUFBQ2pGLHNCQUFvQixFQUFDLE1BQUlBO0FBQTFCLENBQWQ7QUFBK0QsSUFBSWtGLEtBQUo7QUFBVXJGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ29GLE9BQUssQ0FBQ25GLENBQUQsRUFBRztBQUFDbUYsU0FBSyxHQUFDbkYsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUNsRSxNQUFNQyxvQkFBb0IsR0FBRyxJQUFJa0YsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFlBQXJCLENBQTdCLEM7Ozs7Ozs7Ozs7O0FDRFB0RixNQUFNLENBQUNvRixNQUFQLENBQWM7QUFBQ3pELGlCQUFlLEVBQUMsTUFBSUE7QUFBckIsQ0FBZDtBQUFxRCxJQUFJMEQsS0FBSjtBQUFVckYsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDb0YsT0FBSyxDQUFDbkYsQ0FBRCxFQUFHO0FBQUNtRixTQUFLLEdBQUNuRixDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQ3hELE1BQU15QixlQUFlLEdBQUcsSUFBSTBELEtBQUssQ0FBQ0MsVUFBVixDQUFxQixPQUFyQixDQUF4QixDOzs7Ozs7Ozs7OztBQ0RQdEYsTUFBTSxDQUFDb0YsTUFBUCxDQUFjO0FBQUNoQyxnQkFBYyxFQUFDLE1BQUlBO0FBQXBCLENBQWQ7QUFBbUQsSUFBSWlDLEtBQUo7QUFBVXJGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ29GLE9BQUssQ0FBQ25GLENBQUQsRUFBRztBQUFDbUYsU0FBSyxHQUFDbkYsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUN0RCxNQUFNa0QsY0FBYyxHQUFHLElBQUlpQyxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsT0FBckIsQ0FBdkIsQzs7Ozs7Ozs7Ozs7QUNEUCxJQUFJaEYsTUFBSjtBQUFXTixNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNLLFFBQU0sQ0FBQ0osQ0FBRCxFQUFHO0FBQUNJLFVBQU0sR0FBQ0osQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJMEUsUUFBSjtBQUFhNUUsTUFBTSxDQUFDQyxJQUFQLENBQVksc0JBQVosRUFBbUM7QUFBQzJFLFVBQVEsQ0FBQzFFLENBQUQsRUFBRztBQUFDMEUsWUFBUSxHQUFDMUUsQ0FBVDtBQUFXOztBQUF4QixDQUFuQyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJeUIsZUFBSjtBQUFvQjNCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUMwQixpQkFBZSxDQUFDekIsQ0FBRCxFQUFHO0FBQUN5QixtQkFBZSxHQUFDekIsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQTFDLEVBQWtGLENBQWxGO0FBQXFGLElBQUlrRCxjQUFKO0FBQW1CcEQsTUFBTSxDQUFDQyxJQUFQLENBQVksNEJBQVosRUFBeUM7QUFBQ21ELGdCQUFjLENBQUNsRCxDQUFELEVBQUc7QUFBQ2tELGtCQUFjLEdBQUNsRCxDQUFmO0FBQWlCOztBQUFwQyxDQUF6QyxFQUErRSxDQUEvRTtBQUFrRixJQUFJcUYsVUFBSjtBQUFldkYsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDSSxTQUFPLENBQUNILENBQUQsRUFBRztBQUFDcUYsY0FBVSxHQUFDckYsQ0FBWDtBQUFhOztBQUF6QixDQUExQixFQUFxRCxDQUFyRDtBQUF3REYsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVo7QUFBOENELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDJCQUFaO0FBQXlDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSwyQkFBWjtBQUF5Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVo7QUFBd0NELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaO0FBQThDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQ0FBWjtBQVd4bkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUssTUFBTSxDQUFDa0YsT0FBUCxDQUFlLE1BQU07QUFDakJDLFFBQU0sQ0FBQ0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJKLFVBQVUsQ0FBQ0ssVUFBWCxDQUFzQjtBQUFFQyxZQUFRLEVBQUU7QUFBWixHQUF0QixDQUEzQjtBQUNBSixRQUFNLENBQUNDLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCLFFBQTNCLEVBQXFDLENBQUNHLEdBQUQsRUFBTUMsR0FBTixFQUFXQyxJQUFYLEtBQW9CO0FBQ3JEdkYsV0FBTyxDQUFDQyxHQUFSLENBQVlvRixHQUFHLENBQUNHLEtBQWhCO0FBQ0F4RixXQUFPLENBQUNDLEdBQVIsQ0FBWW9GLEdBQUcsQ0FBQ0ksSUFBaEI7QUFDQUgsT0FBRyxDQUFDSSxTQUFKLENBQWMsR0FBZDtBQUNBSixPQUFHLENBQUNLLEdBQUosQ0FBUUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFBQ0MsV0FBSyxFQUFFO0FBQVIsS0FBZixDQUFSO0FBQ0gsR0FMRDtBQU1ILENBUkQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY2hlY2ssIE1hdGNoIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuaW1wb3J0IHsgQ2F0ZWdvcmllc0NvbGxlY3Rpb24gfSBmcm9tICcvaW1wb3J0cy9kYi9DYXRlZ29yaWVzQ29sbGVjdGlvbidcbmltcG9ydCBzbHVnIGZyb20gJ3NsdWcnXG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnY2F0ZWdvcmllcy5pbnNlcnQnKGNhdGVnb3J5KSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCc9PT4nLCBjYXRlZ29yeS5uYW1lKTtcbiAgICAgICAgLy8gY2hlY2sobmFtZSwgU3RyaW5nKTtcbiAgICAgICAgLy8gY2hlY2soY2F0ZWdvcnkua2V5d29yZCwgTWF0Y2guTWF5YmUoU3RyaW5nKSk7XG4gICAgICAgIC8vIGNoZWNrKGNhdGVnb3J5LmRlc2NyaXB0aW9uLCBTdHJpbmcpO1xuICAgICAgICAvLyBjaGVjayhjYXRlZ29yeS5pY29uLCBTdHJpbmcpO1xuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdOb3QgYXV0aG9yaXplZCcpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBDYXRlZ29yaWVzQ29sbGVjdGlvbi5pbnNlcnQoe1xuICAgICAgICAgICAgbmFtZTogY2F0ZWdvcnkubmFtZSxcbiAgICAgICAgICAgIHNsdWc6IHNsdWcoY2F0ZWdvcnkubmFtZSksXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogY2F0ZWdvcnkuZGVzY3JpcHRpb24sXG4gICAgICAgICAgICBpY29uOiBjYXRlZ29yeS5pY29uLFxuICAgICAgICAgICAga2V5d29yZDogY2F0ZWdvcnkua2V5d29yZCxcbiAgICAgICAgICAgIHVzZXJJZDogdGhpcy51c2VySWQsXG4gICAgICAgICAgICBjcmVhdGVBdDogRGF0ZS5ub3coKVxuICAgICAgICB9LCBmdW5jdGlvbiAoZXJyb3IsIHJlc3VsdCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IsIHJlc3VsdClcbiAgICAgICAgICAgIHJldHVybiByZXN1bHRcbiAgICAgICAgfSlcbiAgICB9LFxuICAgICdjYXRlZ29yaWVzLmdldGFsbCcoKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCd2YW8gcm9pJyk7XG4gICAgICAgIHJldHVybiBDYXRlZ29yaWVzQ29sbGVjdGlvbi5maW5kKHt9KS5mZXRjaCgpO1xuICAgIH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBDYXRlZ29yaWVzQ29sbGVjdGlvbiB9IGZyb20gJy9pbXBvcnRzL2RiL0NhdGVnb3JpZXNDb2xsZWN0aW9uJztcblxuTWV0ZW9yLnB1Ymxpc2goJ2NhdGVnb3JpZXMnLCBmdW5jdGlvbiBwdWJsaXNoVGFza3MoKSB7XG4gICAgcmV0dXJuIENhdGVnb3JpZXNDb2xsZWN0aW9uLmZpbmQoe30pXG59KSIsImltcG9ydCB7IGNoZWNrLCBNYXRjaCB9IGZyb20gJ21ldGVvci9jaGVjaydcbmltcG9ydCB7IFBvc3RzQ29sbGVjdGlvbiB9IGZyb20gJy9pbXBvcnRzL2RiL1Bvc3RzQ29sbGVjdGlvbidcblxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ3Bvc3RzLmluc2VydCcocG9zdCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhwb3N0KTtcbiAgICAgICAgY2hlY2socG9zdC5wb3N0X3RpdGxlLCBTdHJpbmcpO1xuICAgICAgICBjaGVjayhwb3N0LnBvc3RfZGVzY3JpcHRpb24sIE1hdGNoLk1heWJlKFN0cmluZykpO1xuICAgICAgICBjaGVjayhwb3N0LnBvc3RfaW1hZ2VzLCBBcnJheSk7XG4gICAgICAgIGNoZWNrKHBvc3QucG9zdF9jYXRlZ29yeSwgQXJyYXkpO1xuICAgICAgICBjaGVjayhwb3N0LnBvc3RfdHlwZSwgU3RyaW5nKTtcbiAgICAgICAgY2hlY2socG9zdC5jb3Zlcl91aWQsIFN0cmluZyk7XG4gICAgICAgIGlmICghdGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ05vdCBhdXRob3JpemVkJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFBvc3RzQ29sbGVjdGlvbi5pbnNlcnQoe1xuICAgICAgICAgICAgdGl0bGU6IHBvc3QucG9zdF90aXRsZSxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBwb3N0LnBvc3RfZGVzY3JpcHRpb24sXG4gICAgICAgICAgICBpbWFnZXM6IHBvc3QucG9zdF9pbWFnZXMsXG4gICAgICAgICAgICBjYXRlZ29yeTogcG9zdC5wb3N0X2NhdGVnb3J5LFxuICAgICAgICAgICAgdHlwZTogcG9zdC5wb3N0X3R5cGUsXG4gICAgICAgICAgICBjb3Zlcl91aWQ6IHBvc3QuY292ZXJfdWlkLFxuICAgICAgICAgICAgdXNlcklkOiB0aGlzLnVzZXJJZCxcbiAgICAgICAgICAgIGxpa2U6IDAsXG4gICAgICAgICAgICBkaXNsaWtlOiAwLFxuICAgICAgICAgICAgc2hhcmU6MCxcbiAgICAgICAgICAgIGNyZWF0ZUF0OiBEYXRlLm5vdygpXG4gICAgICAgIH0sIGZ1bmN0aW9uIChlcnJvciwgcmVzdWx0KSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvciwgcmVzdWx0KVxuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdFxuICAgICAgICB9KVxuICAgIH0sXG4gICAgJ3Rhc2tzLnJlbW92ZScodGFza0lkKSB7XG4gICAgICAgIGNoZWNrKHRhc2tJZCwgU3RyaW5nKTtcbiAgICAgICAgaWYgKCF0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignTm90IGF1dGhvcml6ZWQnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB0YXNrID0gVGFza3NDb2xsZWN0aW9uLmZpbmRPbmUoeyBfaWQ6IHRhc2tJZCwgdXNlcklkOiB0aGlzLnVzZXJJZCB9KTtcbiAgICAgICAgaWYgKCF0YXNrKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdBY2Nlc3MgZGVuaWVkLicpO1xuICAgICAgICB9XG5cbiAgICAgICAgVGFza3NDb2xsZWN0aW9uLnJlbW92ZSh0YXNrSWQpO1xuICAgIH0sXG4gICAgJ3Rhc2tzLnNldElzQ2hlY2tlZCcodGFza0lkLCBpc0NoZWNrZWQpIHtcbiAgICAgICAgY2hlY2sodGFza0lkLCBTdHJpbmcpO1xuICAgICAgICBjaGVjayhpc0NoZWNrZWQsIEJvb2xlYW4pO1xuICAgICAgICBpZiAoIXRoaXMudXNlcklkKSB7IHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ05vdCBhdXRob3JpemVkJyk7IH1cbiAgICAgICAgY29uc3QgdGFzayA9IFRhc2tzQ29sbGVjdGlvbi5maW5kT25lKHsgX2lkOiB0YXNrSWQsIHVzZXJJZDogdGhpcy51c2VySWQgfSk7XG5cbiAgICAgICAgaWYgKCF0YXNrKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdBY2Nlc3MgZGVuaWVkLicpO1xuICAgICAgICB9XG4gICAgICAgIFRhc2tDb2xsZWN0aW9uLnVwZGF0ZSh0YXNrSWQsIHtcbiAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICBpc0NoZWNrZWRcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICB9XG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgUG9zdHNDb2xsZWN0aW9uIH0gZnJvbSAnL2ltcG9ydHMvZGIvUG9zdHNDb2xsZWN0aW9uJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3Bvc3RzJywgZnVuY3Rpb24gcHVibGlzaFRhc2tzKCkge1xuICAgIHJldHVybiBQb3N0c0NvbGxlY3Rpb24uZmluZCh7fSlcbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBGaWxlc0NvbGxlY3Rpb24gfSBmcm9tICdtZXRlb3Ivb3N0cmlvOmZpbGVzJztcblxuY29uc3QgSW1hZ2VzID0gbmV3IEZpbGVzQ29sbGVjdGlvbih7XG4gICAgY29sbGVjdGlvbk5hbWU6ICdJbWFnZXMnLFxuICAgIHN0b3JhZ2VQYXRoOiAnL1VzZXJzL3BoYW1raGEvRGVza3RvcC9NZXRlb3IvaW1hZ2VzJyxcbiAgICBhbGxvd0NsaWVudENvZGU6IHRydWUsIC8vIERpc2FsbG93IHJlbW92ZSBmaWxlcyBmcm9tIENsaWVudFxuICAgIG9uQmVmb3JlVXBsb2FkKGZpbGUpIHtcblxuICAgICAgICBpZiAodGhpcy51c2VySWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHVzZXIgPSB0aGlzLnVzZXIoKTtcbiAgICAgICAgICAgIC8vIEFsbG93IHVwbG9hZCBmaWxlcyB1bmRlciAxME1CLCBhbmQgb25seSBpbiBwbmcvanBnL2pwZWcgZm9ybWF0c1xuICAgICAgICAgICAgaWYgKGZpbGUuc2l6ZSA8PSAxMDQ4NTc2MCAmJiAvcG5nfGpwZ3xqcGVnL2kudGVzdChmaWxlLmV4dGVuc2lvbikpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgcmV0dXJuICdQbGVhc2UgdXBsb2FkIGltYWdlLCB3aXRoIHNpemUgZXF1YWwgb3IgbGVzcyB0aGFuIDEwTUInO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuICdZb3UgYXJlIG5vdCBsb2dnZWQgaW4nO1xuICAgICAgICB9XG5cbiAgICB9LFxuICAgIG9uQmVmb3JlUmVtb3ZlKGN1cnNvcikge1xuICAgICAgICBjb25zdCByZWNvcmRzID0gY3Vyc29yLmZldGNoKCk7XG5cbiAgICAgICAgaWYgKHJlY29yZHMgJiYgcmVjb3Jkcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLnVzZXJJZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHVzZXIgPSB0aGlzLnVzZXIoKTtcbiAgICAgICAgICAgICAgICAvLyBBc3N1bWluZyB1c2VyLnByb2ZpbGUuZG9jcyBpcyBhcnJheVxuICAgICAgICAgICAgICAgIC8vIHdpdGggZmlsZSdzIHJlY29yZHMgX2lkKHMpXG5cbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbGVuID0gcmVjb3Jkcy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWxlID0gcmVjb3Jkc1tpXTtcbiAgICAgICAgICAgICAgICAgICAgaWYoZmlsZS51c2VySWQgIT09IHVzZXIuX2lkKVxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvL2tp4buDbSB0cmEgeGVtIHBo4bqjaSBjaOG7pyBi4bupYyBow6xuaCB4b8OhIGtow7RuZ1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG59KTtcbmV4cG9ydCBkZWZhdWx0IEltYWdlcztcbmlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdmaWxlcy5pbWFnZXMuYWxsJyk7XG59XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICBNZXRlb3IucHVibGlzaCgnZmlsZXMuaW1hZ2VzLmFsbCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIEltYWdlcy5maW5kKCkuY3Vyc29yO1xuICAgIH0pO1xufSIsImltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSdcblxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ3VzZXJzLkluc2VydCc6ZnVuY3Rpb24oZGF0YSl7XG4gICAgICBsZXQgcHJlcGFyZV9kYXRhID0ge1xuICAgICAgICBlbWFpbDogZGF0YS5lbWFpbCxcbiAgICAgICAgcGFzc3dvcmQ6IGRhdGEucGFzc3dvcmQsXG4gICAgICAgIHByb2ZpbGU6e1xuICAgICAgICAgIG5hbWU6IGRhdGEubmFtZSxcbiAgICAgICAgICBhZ3JlZW1lbnQ6IGRhdGEuYWdyZWVtZW50XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBBY2NvdW50cy5jcmVhdGVVc2VyKHByZXBhcmVfZGF0YSk7XG4gICAgfSxcbiAgfSk7IiwiaW1wb3J0IHtNb25nb30gZnJvbSAnbWV0ZW9yL21vbmdvJ1xuZXhwb3J0IGNvbnN0IENhdGVnb3JpZXNDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NhdGVnb3JpZXMnKSIsImltcG9ydCB7TW9uZ299IGZyb20gJ21ldGVvci9tb25nbydcbmV4cG9ydCBjb25zdCBQb3N0c0NvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncG9zdHMnKSIsImltcG9ydCB7TW9uZ299IGZyb20gJ21ldGVvci9tb25nbydcbmV4cG9ydCBjb25zdCBUYXNrQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0YXNrcycpIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcbmltcG9ydCB7IFBvc3RzQ29sbGVjdGlvbiB9IGZyb20gJy9pbXBvcnRzL2RiL1Bvc3RzQ29sbGVjdGlvbidcbmltcG9ydCB7IFRhc2tDb2xsZWN0aW9uIH0gZnJvbSAnL2ltcG9ydHMvZGIvVGFza0NvbGxlY3Rpb24nXG5pbXBvcnQgYm9keVBhcnNlciBmcm9tICdib2R5LXBhcnNlcidcbmltcG9ydCAnL2ltcG9ydHMvYXBpL1Bvc3RzUHVibGljYXRpb25zJztcbmltcG9ydCAnL2ltcG9ydHMvYXBpL1Bvc3RzTWV0aG9kcyc7XG5pbXBvcnQgJy9pbXBvcnRzL2FwaS9Vc2Vyc01ldGhvZHMnO1xuaW1wb3J0ICcvaW1wb3J0cy9hcGkvVXBsb2FkU2hhcmUnO1xuaW1wb3J0ICcvaW1wb3J0cy9hcGkvQ2F0ZWdvcmllc01ldGhvZHMnO1xuaW1wb3J0ICcvaW1wb3J0cy9hcGkvQ2F0ZWdvcmllc1B1YmxpY2F0aW9ucyc7XG4vLyBjb25zdCBpbnNlcnRUYXNrID0gKHRhc2tUZXh0LCB1c2VyKSA9PiB7XG4vLyAgIFRhc2tDb2xsZWN0aW9uLmluc2VydCh7XG4vLyAgICAgdGV4dDogdGFza1RleHQsXG4vLyAgICAgdXNlcklkOiB1c2VyLl9pZCxcbi8vICAgICBjcmVhdGVBdDogbmV3IERhdGUoKSxcbi8vICAgfSlcbi8vIH07XG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgICBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShib2R5UGFyc2VyLnVybGVuY29kZWQoeyBleHRlbmRlZDogdHJ1ZSB9KSlcbiAgICBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL2hlbGxvJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcS5xdWVyeSk7XG4gICAgICAgIGNvbnNvbGUubG9nKHJlcS5ib2R5KTtcbiAgICAgICAgcmVzLndyaXRlSGVhZCgyMDApO1xuICAgICAgICByZXMuZW5kKEpTT04uc3RyaW5naWZ5KHtoZWxsbzogMTIzfSkpO1xuICAgIH0pO1xufSk7XG4iXX0=
